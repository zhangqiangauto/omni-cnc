#pragma once

#include "keniucnc/cam/value_added_toolbox.hpp"

#include <QJsonObject>
#include <QString>

class QWidget;

namespace keniucnc::cam {

struct ValueAddedSystemContext
{
  QString machine_name;
  QString axes_summary;
  QString tooling_summary;
  QString workpiece_summary;
  QString user_summary;
  QString config_summary;
  QJsonObject raw;
};

class IValueAddedHost
{
public:
  virtual ~IValueAddedHost() = default;

  virtual ValueAddedSystemContext system_context() const = 0;
  virtual void show_tool_description(const QString& tool_id) = 0;
  virtual bool ensure_unlocked(const ValueAddedToolDescriptor& tool) = 0;
  virtual void submit_program_load(const QString& saved_path) = 0;
  virtual QString asset_root_path() const = 0;
  virtual void notify_info(const QString& title, const QString& message) = 0;
  virtual void notify_warning(const QString& title, const QString& message) = 0;
};

class IValueAddedModule
{
public:
  virtual ~IValueAddedModule() = default;

  virtual ValueAddedToolDescriptor descriptor() const = 0;
  virtual QWidget* create_widget(IValueAddedHost* host, QWidget* parent) = 0;
};

}  // namespace keniucnc::cam
