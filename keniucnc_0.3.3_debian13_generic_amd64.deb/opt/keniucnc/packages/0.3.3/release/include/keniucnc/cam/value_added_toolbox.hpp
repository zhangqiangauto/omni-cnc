#pragma once

#include <string>

namespace keniucnc::cam {

enum class ValueAddedToolAccess
{
  Free,
  Paid,
  Preview,
};

struct ValueAddedToolDescriptor
{
  std::string id;
  std::string display_name;
  std::string summary;
  std::string icon_resource;
  ValueAddedToolAccess access = ValueAddedToolAccess::Free;
  bool implemented = false;
  std::string author = "KeniuTech";
  std::string version = "1.0.0";
};

}  // namespace keniucnc::cam
