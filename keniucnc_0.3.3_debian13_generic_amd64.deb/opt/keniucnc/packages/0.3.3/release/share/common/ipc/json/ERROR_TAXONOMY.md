# KeniuCNC Error Taxonomy (Architecture-Level)

This taxonomy standardizes cross-process error intent and removes ambiguous placeholder behavior.

## Command Path Errors (`/v1/cmd`)

- `1xxx`: request contract errors
  - envelope/args validation failures
  - unknown/unsupported command
- `2xxx`: state/safety semantic errors
  - mode/state transition not allowed
  - safety gate rejection
  - home flow semantic constraints
- `5xxx`: runtime execution availability errors
  - queue busy
  - planner/runtime capacity issues

## Placeholder/Unimplemented Policy

- Unimplemented paths must return explicit, stable messages (for example `UNIMPLEMENTED_*`), never implicit success.
- Health/diagnostic fields must use explicit states (`BOUND`, `BIND_FAILED`, `NOT_OBSERVED_BY_CORE`) instead of mixed placeholder strings.
- Placeholder diagnostics are allowed only when marked with `placeholder: true` for machine-side filtering.

## Logging Rules

- Normal logs keep operational detail.
- Key interaction commands must also emit structured operation events with command id and result.
- Safety/policy actions from Guardian must be persisted in the Guardian-owned operation event store with trigger reason.
