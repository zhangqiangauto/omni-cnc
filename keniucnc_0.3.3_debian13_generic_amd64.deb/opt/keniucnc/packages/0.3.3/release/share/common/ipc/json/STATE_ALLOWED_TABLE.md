# KeniuCNC v1 Safety Gate (Core)

This is a reading guide, not a client-side admission table. The complete rules
are implemented in `core/app/command/safety/safety_gate.cpp` (`check`,
`is_allowed_in_state`, and `allowed_cmds`); clients render Core-published
permissions and submit intent. Command arguments, mode, lifecycle, drive and
alarm facts can change admission within the same run-state name.

States are `RESET`, `IDLE`, `READY`, `PRIMING`, `RUN`, `WAIT_DATA`,
`COMPLETING`, `ABORTING`, `HOLD`, `FAULT`, and `ESTOP`.

- Mode changes use `core.ctrl.mode.set`.
- An explicit `core.safety.estop(active=true)` is admitted idempotently.
- In `ESTOP`, E-stop release, base diagnostic/read/reset operations and
  program mutations have special admission in `check`; this does not admit
  motion or drive enable. Base operations still pass earlier argument and
  lifecycle restrictions.
- In `FAULT` or with an active alarm, drive disable and
  `core.drives.fault_reset` are recovery intents. Explicit drive enable is
  admitted only when Core's `drive_reset_and_enable_permitted` fact allows
  that transaction. This is not automatic recovery. A standalone reset does
  not carry enable intent.
- AUTO start requires an eligible idle/ready state, AUTO mode, loaded program
  and enabled drives, plus the command owner's program/preflight checks.
- Active AUTO lifecycle state can independently reject mode/program/WCS
  mutation and hold/resume. Stop/reset also have lifecycle-specific admission.
- JOG/MDI/HOME, tool-change confirmation, IO, spindle, override and WCS commands
  have separate mode/state/argument checks; do not reproduce them in HMI.

A successful safety-gate check is only admission to the command owner. It does
not prove that a physical operation has completed. The synchronous HTTP result
and Core-published workflow state retain their documented completion semantics.
