# KeniuCNC Process Topology

This document defines the default process wiring and runtime endpoint configuration.

## Runtime Topology

- `core`
  - HTTP server: control, queries and management routes listed below
  - ZMQ PUB: publishes `state.*`, `event.*`, `diag.*`, `telemetry.axis`
  - SHM writer: RT waveform ring buffer
- `guardian`
  - ZMQ SUB from core PUB endpoint
  - HTTP client to core command endpoint
  - HTTP probes for core/web health
- `hmi_web` (gateway)
  - HTTP/WS server for web clients
  - ZMQ SUB from core PUB endpoint
  - HTTP command forwarder to core
- `intelligence`
  - ZMQ SUB to Core `state.system` facts
  - HTTP server for operator policy, run analysis, processing insights and health
  - HTTP client to Core for capture-pose and explicit control requests
  - Candidate reasoning does not own machine admission or RT control
- `hmi_qt`
  - HTTP client to core
  - ZMQ SUB from core PUB endpoint
  - SHM reader for RT waveform

## Shared Endpoint Configuration

All processes load endpoint defaults from `keniucnc::common::ipc::load_runtime_endpoints()`.

Configuration source:

- Built-in defaults in `RuntimeEndpoints`
- Optional overrides from `data/platforms/<platform>.json` under `endpoints`

Default values:

- `core_http_host`: `127.0.0.1`
- `core_http_port`: `18080`
- `core_zmq_pub_endpoint`: `tcp://127.0.0.1:19010`
- `guardian_bind_host`: `127.0.0.1`
- `guardian_bind_port`: `18081`
- `intelligence_bind_host`: `127.0.0.1`
- `intelligence_bind_port`: `18082`
- `intelligence_http_host`: `127.0.0.1`
- `web_bind_host`: `0.0.0.0`
- `web_bind_port`: `8080`
- `web_http_host`: `127.0.0.1`
- `rt_shm_name`: `/keniucnc_rtbuf`

## Design Rules

- Control commands are sent through core HTTP (`POST /v1/cmd`); management
  intents use their owning HTTP routes below. ZMQ events are observations, not
  reliable command-completion acknowledgements.
- Telemetry and state fan-out use core ZMQ PUB.
- High-rate waveform data is local shared-memory only (core -> qt).
- Guardian must not depend on gateway/ws paths for safety actions.

## Core HTTP route index

The route gate is `core/app/api/api_router.hpp`; dispatch and methods are owned
by `core/app/api/handlers/*`. Query parameters are omitted below.

| Method | Paths | Owner |
| --- | --- | --- |
| GET | `/v1/health`, `/v1/state`, `/v1/rt/channel`, `/v1/machine/overview` | `core_state_http_adapter.cpp` |
| GET | `/v1/catalog/overview`, `/v1/catalog/errors`, `/v1/catalog/commands`, `/v1/catalog/help` | `core_state_http_adapter.cpp` |
| POST | `/v1/cmd` | `core_command_http_adapter.cpp` |
| GET | `/v1/cmd/{id}` | `core_command_http_adapter.cpp`; bounded submission result lookup |
| GET | `/v1/operations/{id}` | `core_http_session_handler.cpp`; retained operation record |
| GET + WebSocket upgrade | `/v1/stream` | `core_http_session_handler.cpp` |
| POST | `/v1/license/status` | `license_http_handlers.cpp`; GET is not handled |
| GET | `/v1/adaptive-machining/status` | `intelligence_http_handlers.cpp` |
| POST | `/v1/intelligence/capture-pose` | `intelligence_http_handlers.cpp` |
| GET | `/v2/program/summary`, `/v2/program/chunk`, `/v2/program/changes` | `program_http_handlers.cpp` |
| POST | `/v2/program/load`, `/v2/program/attach` | `program_http_handlers.cpp` |
| GET, PUT | `/v2/tools/config` | `tooling_http_handlers.cpp` |
| GET | `/v2/tools/summary`, `/v2/tools/issues` | `tooling_http_handlers.cpp` |
| POST | `/v2/tools/maintenance`, `/v2/tools/preflight/check`, `/v2/tools/life/consume` | `tooling_http_handlers.cpp` |
| GET | `/v2/machine-config/catalog`, `/v2/machine-config/item` | `machine_config_http_handlers.cpp` |
| POST | `/v2/machine-config/validate`, `/v2/machine-config/commit` | `machine_config_http_handlers.cpp` |

`GET /v1/health` contains an abbreviated discovery list; it is not the complete
route contract. A constant declared in a shared header is not by itself an
implemented route.

The intelligence process's separate HTTP server (`intelligence/app/operator_policy_http_server.cpp`)
serves `GET /v1/health`, `GET /v1/processing-insights/overview`,
`POST /v1/intelligence/operator-policies`, and
`POST /v1/intelligence/run-analyses` on port 18082 by default.
