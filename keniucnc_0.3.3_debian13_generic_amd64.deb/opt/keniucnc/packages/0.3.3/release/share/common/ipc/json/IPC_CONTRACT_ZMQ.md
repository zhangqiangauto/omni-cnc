# KeniuCNC IPC Contract

## Control Plane

- Protocol: HTTP JSON
- Endpoint: `POST /v1/cmd`
- State query: `GET /v1/state` (read-only; not a command fallback)
- Command result lookup: `GET /v1/cmd/{id}`
- Full route index: [PROCESS_TOPOLOGY.md](PROCESS_TOPOLOGY.md)
- Bind: `127.0.0.1:18080`

## Data Plane

- Protocol: ZeroMQ PUB/SUB
- Core role: `PUB`
- Consumer role: Qt HMI / Gateway / Guardian / Intelligence as `SUB`
- Bind: `tcp://127.0.0.1:19010`

## ZMQ Frame Format

`multipart` with 2 frames:

1. Frame0: `topic` (UTF-8 string)
2. Frame1: JSON envelope

Envelope:

```json
{
  "ver": 1,
  "ts_ms": 1760000000123,
  "topic": "diag.planner",
  "seq": 1234,
  "data": {}
}
```

## Published topics

`topic_contract.v1.json` lists payload fields; `common/include/keniucnc/ipc/topic_id.hpp`
lists the fixed-frame latest-value topics. Payload schema version is independent
of transport envelope version: current fixed-frame `diag.perf` and
`diag.rt_channel` publication uses envelope `ver=1`, with payload schemas
`diag.perf.v2` and `diag.rt_channel.v2` respectively.

- State: `state.system`, `state.io`
- Telemetry: `telemetry.axis`, `telemetry.tcp_pose`
- Diagnostics: `diag.planner`, `diag.buffer`, `diag.constraints`, `diag.perf`,
  `diag.io_profile`, `diag.rt_channel`, `diag.guardian_snapshot`
- Core events: `event.alarm`, `event.safety`, `event.cmd_result`,
  `event.lifecycle`, `event.interp`, `event.operation`

Periodic publication rates are configured by Core's topic-interval gate supplied to `StatePublisher`;
`diag.guardian_snapshot` also has a one-second minimum interval. Do not treat
example rates as a delivery guarantee. PUB/SUB may lose messages. A critical
command's authoritative result is its HTTP response (or correlated result
lookup), not receipt of `event.cmd_result`.

## Process-Level Convention

- Qt HMI: HTTP + ZMQ SUB
- Web HMI: only via Gateway (Gateway SUB from Core, then WS to browser)
- RT threads must not publish JSON/ZMQ directly; publisher thread aggregates and emits.
