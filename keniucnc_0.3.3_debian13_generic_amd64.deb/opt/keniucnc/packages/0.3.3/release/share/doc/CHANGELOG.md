# CHANGELOG

人工整理的阶段记录，包含从 TODO 迁移的历史条目；不是完整 Git 提交日志或版本生成来源。
当前构建版本以 `cmake/KeniuVersion.cmake` 为准，逐提交变更使用 `git log` 查看。

## 2026-10-30 TODO 全项核对与迁移

本次仅整理文档，依据实现与测试源码核对；未运行全仓测试、长稳或实机精度验收。
完整原任务去向见 [核对表](docs/reviews/2026-10-30_todo_reconciliation.md)。

### 从待办移出的已实现范围

- **M7-05 文档分层**：已有 docs/README 架构索引、operations 操作指南、发布安装与开发入口；
  后续文档维护不再以“建立分层”重复立项。
- **TCPU-17/18 位姿几何升级基础实现**：已有 ToolSpaceOrientationQuintic、SO(3)/受限
  姿态流形和姿态加权路径度量；原“仅 XYZ + 欧拉 lerp”的基线描述失效。
  这不是所有模式/机型的全域连续性与误差保证验收，剩余核验保留在 TODO。
- **TCPU-33 专项单测基础建设**：已有姿态插值、纯旋转度量、边界与解身份/分支用例。
  本次确认测试源码存在，未宣称本轮运行通过；缺口矩阵和全链回放继续跟踪。
- **ISSUE-18/19 问题记录与日志反馈**：Guardian 已有 SQLite 事件存储、诊断采集、日志
  脱敏、持久队列和 MQTT PUBACK 确认链路及对应测试。云端订阅/业务归档不在此完成范围。
- **旧波形清理项**：当前使用 RtWavePlot/RtWaveHistory，未检索到旧 WaveformStore 实现，
  不再保留删除旧类的重复任务。

### 删除失效路线、纠正旧事实

- 从当前 TODO 删除此前已放弃的 MID-03..32/M-ID-1..4 全模型在线辨识计划、
  GEO-21..28/30 与 P5-01..03 的 NonToolTipFollow 路线，以及 ISSUE-11 DDD/CQRS 讨论。
  不表示这些能力完成。当前 XYZ 离线辨识、会话、档案与启动应用子集已有实现；
  旧 2026-06-28 的“零实现”仅为当时历史描述，不能继续作当前结论。
- 旧 anchor/boundary_locked/make_path 函数级处方、RTCP Rapid 一律拒绝、所有模式
  必须采用统一位姿弧长、共享几何实现必然错误等不再作为实施要求。
- 合并重复 TCP/IK/测试任务，保留长稳、六轴专项、约束保证范围、发布和故障复现的实际缺口。
- 保留新提出的 G54/3+2 坐标延后绑定为优先未来工作，未以缓存或缩小重建范围替代。

## 2026-10-16 文档核查与修复

- 修复文档索引断链并补全 architecture 一级专题导航。
- 对照当前代码修正 README 后端生命周期和 RS274 能力摘要、版本规则及发布工具边界。
- 将 TODO 后半部原始对话及原 log.md 草稿保留为单独历史资料。
- 契约、模块与架构专题的核查明细见 `docs/reviews/2026-10-16_documentation_audit.md`。
- 本条仅记录文档整理，不追溯宣称未逐项验收的历史任务已经完成。

## 2026-08-08 TODO Completed-Item Migration

- Removed the remaining completed `[x]` entries from TODO: TCPU-10, TCPU-15,
  RE-01/02, RP-01..03, P1-01..04, P2-01..04, and NX-01/02.
- Their completion records remain in the 2026-06-29 cleanup/archive entries below.

## 2026-06-29 TODO Cleanup

### Removed completed `[x]` items (verified in codebase)
- RTCP-18, RTCP-19 — HMI/diagnostics (CHANGELOG 2026-06-11)
- RTCP-21 — RTCP unit/integration test suites (CHANGELOG 2026-06-11)
- R-M1, R-M2, R-M3 — RTCP milestones (CHANGELOG 2026-06-11)
- ISSUE-10 — Multi-language (CHANGELOG 2026-06-11)
- ISSUE-28, ISSUE-29 — Spline/NURBS (CHANGELOG 2026-06-11)
- ISSUE-45 — Crash handler (CHANGELOG 2026-06-11)
- TCPU-10, TCPU-15 — `supports()` aligned with actual implementation
- Kinematics 4-stage plan — All stages verified complete in code

### Marked completed in TODO (verified via code audit)
- RE-01, RE-02 — NonToolTipFollow classification removed; `classify_tracking_mode()` hardcoded to `ToolTipFollow`
- RP-01, RP-02, RP-03 — Priority reset to ToolTipFollow-only family
- P1-01 through P1-04 — Classification repair completed
- P2-01 through P2-04 — NonToolTipFollow removed from critical path
- NX-01, NX-02 — NonToolTipFollow boundary fix + GeometryBuilder withdrawal

### Removed obsolete content
- 视频计划 (video roadmap) — all basic features listed are already implemented (see CHANGELOG Historical Baseline)
- 实机测试 checklist — referenced tasks now tracked in dedicated test plans
- Kinematics 4-stage detailed proposal — implemented, replaced with completion note
- SplicePoint refactoring proposal (the "第一性原理" architecture analysis + 5-step refactoring plan) — all listed classes (LookaheadGuardManager, PreparedPlanQueue, CommitPublisher, CommitValidator, CommitShapeContract) removed; SplicePoint is the single boundary type; error enums consolidated. The proposal served its purpose

## 2026-06-28 TODO Cleanup & Archive Migration

### Implemented & Verified Complete
- `[x]` **SplicePoint/lookahead architecture refactoring** — All proposed removal classes (LookaheadGuardManager, PreparedPlanQueue, CommitPublisher, CommitValidator, CommitShapeContract, PartitionBoundaryContract, RestartBoundaryState, RestartBoundaryKey, RestartLogicalIdentity) were removed. Five error enums (LookaheadScheduleRejectReason, RestartRejectReason, CommitRejectReason, PublishRejectReason, LookaheadGuardRejectReason) were consolidated. SplicePoint became the single boundary truth type. This refactoring implemented the "第一性原理" proposal's spirit without needing it as a separate TODO tracker.
- `[x]` **Kinematics 4-stage upgrade** — `KinematicsModel::jacobian()`, `map_cartesian_derivatives()` with `DerivativeMappingRequest/Result` are full virtual methods; 3-point IK stencil was removed from TCP_UNIFIED; all machine types have analytic derivative mapping; `jacobian_column_norm_condition_metric` utility exists.
- `[x]` **TCPU-10 / TCPU-15** — Fixed `supports()` to no longer claim Spline/Nurbs (only Line/Rapid/Arc/Dwell).
- `[x]` **ISSUE-10** — Multi-language (QTranslator + tr() + ts/qm) already in CHANGELOG.

### Abandoned / Superseded
- `[abandoned]` **Model Identification (MID-03 through MID-32)** — Zero implementation. No `model_calibration` module, no `ModelIdentificationDialog`, no calibration pipeline. Archived as future reference.
- `[abandoned]` **NonToolTipFollow semantics (GEO-21 through GEO-30, RE-01/RE-02, RP-02, P1-01 through P2-04, NX-01/NX-02)** — The `TcpTrackingMode` enum only contains `ToolTipFollow`. NonToolTipFollow was explicitly dropped from scope. `classify_tracking_mode()` hardcoded to return `ToolTipFollow`.
- `[superseded]` **setup_wizard WorkbenchUnit/HardwareLeaseManager abstraction proposal** — Actual implementation took a different architectural direction (module-based instead of workbench-unit-based). The proposal served as design exploration.
- `[superseded]` **G61/G64 8-phase roadmap** — Only scaffolding exists (interpreter accepts G61/G64 with placeholder warnings; `exact_stop`/`blend_tolerance` config fields). The full phased plan was not pursued.
- `[superseded]` **ISSUE-11 DDD+CQRS discussion** — No document produced; architecture direction diverged.

### Design Archives (Planning Discussions That Served Their Purpose)

The following long-form discussions in TODO.md were planning conversations that guided implementation. They are archived here for historical reference:

- **SplicePoint refactoring proposal** — The "第一性原理" analysis diagnosing 4x boundary type duplication, 5x error enum duplication, and 3x continuity check duplication. The resulting simplification eliminated ~50% of types/classes and consolidated error paths.
- **Kinematics 4-stage plan** — Analytic derivative mapping, singularity robustness, and 3-point IK stencil removal. All 4 stages completed.
- **G61/G64 8-phase roadmap** — Data contract, interpreter semantics, planner termination, P tolerance, Q naive-cam, and test matrix. Only Phase 0 (semantic baseline) was partially explored.
- **TCP_UNIFIED completeness remediation** — The TCPU-/GEO-/IKC-/IKR-/IKF-/RE-/RP-/P-/NX- item taxonomy. Some items resolved (TCPU-10), some explicitly dropped (NonToolTipFollow), most remain pending.
- **setup_wizard redesign** — Proposed core/config/units/ui layered architecture with WorkbenchUnit/HardwareLeaseManager abstractions. Implementation diverged to module-based architecture.
- **Interpolation architecture review** — The 7-point critique covering frontier pressure closure, braking reachability, ring buffer RT hardening, stop semantics unification, override ramp constraint binding, splice validation strengthening, and residual legacy data flow patterns.

### Removed completed `[x]` items already in CHANGELOG

- RTCP-21 (RTCP unit/integration test suites) — already in 2026-06-11 entry
- R-M1, R-M2, R-M3 (RTCP milestones) — already in 2026-06-11 entry
- RTCP-18, RTCP-19 (HMI/diagnostics) — already in 2026-06-11 entry
- ISSUE-10 (multi-language) — already in 2026-06-11 entry
- ISSUE-28, ISSUE-29 (Spline/NURBS) — already in 2026-06-11 entry
- ISSUE-45 (crash handler) — already in 2026-06-11 entry

## 2026-06-11 Code Audit Migration (Status Verification)

Confirmed completed by codebase audit. These items were marked `[ ]` in TODO.md but are implemented in source.

### RTCP Phase R5: Diagnostics + HMI
- `[x]` RTCP-18 Qt/Web 已实现 RTCP 状态显示与告警呈现（dashboard panel 含 enable/disable/mode/condition metric/tcp error/singularity/degrade；Web 同名 panel + AI skill 集成）。
- `[x]` RTCP-19 已实现操作侧开关（带确认弹窗）与只读参数可视化（当前机型、WCS、刀长）。

### RTCP Phase R6: Validation + Release Gate
- `[x]` RTCP-21 已新增 RTCP 单测分层（gcode_parse_test: G43.4/G49；interp_modal_contract_runner: rtcp_enabled/disabled；tcp_unified_math_runner: 18+ RTCP 断言覆盖 geometry/transition/singularity）。

### RTCP Milestones
- `[x]` R-M1 RTCP parser/executor 契约就绪，单测通过。
- `[x]` R-M2 5轴 RTCP（XYZAC_TABLE）可运行，具备基础保护。
- `[x]` R-M3 5轴 RTCP（XYZBC_HEAD）可运行，完成 HMI/诊断联动。

### Multi-Language (ISSUE-10)
- `[x]` ISSUE-10 多语言方案已落地：QTranslator + `tr()` + ts/qm 管道，en_US/zh_CN 双语言已全量覆盖。

### Spline/NURBS Support (ISSUE-28/29)
- `[x]` ISSUE-28 已实现 Spline/NURBS 标准 G 代码解释器（`core/app/motion/interpolator/algorithms/spline/` 含完整 path/lookahead/timelaw）。
- `[x]` ISSUE-29 已实现样条 S 插补算法模块，注册为 `kInterpolatorAlgorithmSpline`。

### UI Crash Diagnostics (ISSUE-45)
- `[x]` ISSUE-45 已添加全进程崩溃日志与堆栈跟踪（`common/diagnostics/crash_handler` 覆盖 core/guardian/hmi_qt/hmi_web，捕获 SIGSEGV/SIGABRT/SIGBUS/SIGILL/SIGFPE 并输出 backtrace）。

## 2026-05-20 Completed Items Migration
- `[x] RA-03` 已支持 `G43.4/G43.5/G49` RTCP 模态契约与状态透传。
- `[x] RA-04` 已接入 baseline `work->machine` RTCP tool-length 变换。
- `[x] RA-06` 已补解释器/planner/adapter RTCP 单测。
- `[x] RTCP-01` 已支持 `G43.4/G43.5/G49` 语义与模态保持。
- `[x] RTCP-03` 已在 `coordinate_context` 增加 RTCP 上下文。
- `[x] RTCP-04` 已新增模态切换/非法组合单测。
- `[x] RTCP-05` 已有 baseline 变换路径。
- `[x] RTCP-06` motion canonical 目标机床坐标已走变换逻辑。
- `[x] RTCP-07` 已形成初版约定（machine_from_work 标识）。
- `[x] RTCP-08` 已有 `RTCP OFF` 等价与 ON 基础回归。
- `[x] RTCP-10` 已在 5轴模型链路可运行。
- `[x] RTCP-11` 已接入 hint + 旋转轴展开连续化。
- `[x] RTCP-12` 已新增接口层数值测试。
- `[x] RTCP-13` planner 已接入 RTCP 分支（IK hint/约束/插补链路）。
- `[x] RTCP-14` 已接入 A/B/C 展开与抗跳变机制并补回归用例。
- `[x] RTCP-15` 已接入 condition metric 驱动的降速/停靠退化。
- `[x] RTCP-16` 已保持模式隔离并通过现有模式回归。
- `[x] RTCP-17` 已在 planner 诊断补充 RTCP 字段（enabled/mode/condition/singularity/degrade/tcp_error）。
- `[x] RTCP-20` 已补程序行/RTCP态/降级与误差日志。

## 2026-04-24 Completed Items Migration (RTCP & Testing)
- `[x]` M7-02 Integration tests: Core-Guardian-Qt-Web command+telemetry loop.
- `[x] RA-03` 已支持 `G43.4/G43.5/G49` RTCP 模态契约与状态透传。
- `[x] RA-04` 已接入 baseline `work->machine` RTCP tool-length 变换。
- `[x] RA-06` 已补解释器/planner/adapter RTCP 单测。
- `[x] RTCP-01` 已支持 `G43.4/G43.5/G49` 语义与模态保持。
- `[x] RTCP-03` 已在 `coordinate_context` 增加 RTCP 上下文。
- `[x] RTCP-04` 已新增模态切换/非法组合单测。
- `[x] RTCP-05` 已有 baseline 变换路径（work->machine）。
- `[x] RTCP-06` motion canonical 目标机床坐标已走变换逻辑。
- `[x] RTCP-07` 已形成初版约定（machine_from_work 标识）。
- `[x] RTCP-08` 已有 RTCP OFF 等价与 ON 基础回归。
- `[x] RTCP-10` 已在 5轴模型链路可运行。
- `[x] RTCP-11` 已接入 hint + 旋转轴展开连续化。
- `[x] RTCP-12` 已新增接口层数值测试。
- `[x] RTCP-15` 已接入 condition metric 驱动的降速/停靠退化。
- `[x] RTCP-16` 已保持模式隔离并通过现有模式回归。
- `[x] RTCP-20` 已补程序行/RTCP态/降级与误差日志。

## Historical Project Baseline & Design Context (Archived from TODO.md)
### Implemented Baseline Features (Video Roadmap)
- `[x]` 平滑 JOG & HOME 逻辑落地。
- `[x]` 空间包围盒及越界检测安全栅栏。
- `[x]` CAM 工具小程序框架（`cam/` 模块）。
- `[x]` Web UI 网关与前端基础链路（`hmi_web`）。
- `[x]` 多语言配置（`tr()` 管道 + `ts/qm` 自动化）。
- `[x]` 配置工具（`MID-02` 运行时参数加载与持久化）。
- `[x]` RTCP 功能展示（5轴机型基础闭环）。
- `[x]` 3+2 模式支持（模态切换与坐标变换）。
- `[x]` 旋转轴最短路与无限旋转（Unwrap 机制）。
- `[x]` 奇异点降速处理（Condition Metric 驱动）。

### Historical Design Discussions
- **Interpolation & Lookahead Architecture**: Discussed transition from point-based to unit-based ringbuffer, rolling lookahead guard lifecycle, and `OverrideRamp` for smooth scaling.
- **RTCP Semantic Convergence**: Defined 4-phase plan for kinematics upgrade, analytic derivative mapping, and `TCP_UNIFIED` link switching.
- **Path Control (G61/G64)**: Defined 8-phase roadmap for exact path/blend mode, tolerance-driven corner capping, and naive-CAM implementation.
- **Data Integrity**: Enforced rejection of "ad-hoc fallback" code (e.g., `std::max(0.0, v)`) to expose underlying logic errors instead of masking them.
- **HMI Evolution**: Confirmed Web Gateway parity with Qt UI command confirmation patterns; planned file management and centering (manual/vision) UI tabs.

### Interpolation & Lookahead Architecture Roadmap
- Target execution chain: `Motion Source -> Preprocess/Corner/Constraint/Partition -> Partition Lookahead S Planning -> PreparedPlan -> Commit Validation -> CommittedSegmentBuffer -> Realtime OverrideRamp/StopPolicy/Sampler -> Servo Output`.
- Core principles: plan lookahead at ideal speed, consume only committed segments in realtime, handle pause/resume/override/insufficient-lookahead through runtime scaling or hold policy, splice rolling lookahead only at safe boundaries, and keep failed commits from mutating execution state.
- Phase 1: complete `PartitionBoundaryContract` and require replannable partition or exact-stop boundaries for replace windows.
- Phase 2: strengthen `CommitValidator` for source continuity, non-overlap, geometry continuity, velocity/acceleration continuity, IK branch continuity, exact-stop semantics, and atomic failure behavior.
- Phase 3: add `LookaheadGuard` lifecycle so acquire/build/ready/commit/release or abort/release are explicit and protected.
- Phase 4: add `OverrideRamp` for smooth operator override, feed hold, resume, and lookahead-pressure slowdown up to the 120% cap.
- Phase 5: unify `FeedHold`, `M00/M01`, `ProgramEnd`, `Abort`, and `Reset` through `StopPolicy` and `AutoRunExecutionState`.
- Phase 6: close the rolling lookahead loop with `LookaheadScheduler`, `PreparedPlanQueue`, and `CommitPublisher`, keeping lookahead and realtime responsibilities separated.
- Phase 7: unify `AUTO / MDI / JOG / Handwheel / Home` under `SegmentProducer` with channel-specific commit policies.
- Phase 8: keep servo output shallow, with current-cycle and optional next-cycle staging only.
- Phase 9: add continuity, guard pressure, override smoothing, stop behavior, manual/system flush, and 120% cap tests before larger replacement work.

## 2026-04-12 RTCP/TCP_UNIFIED Kinematics Closure
- `[x]` RA-05 完成运动学接口升级闭环：`inverse_with_hint / jacobian / condition_metric / map_cartesian_derivatives` 已在机型层落地，不再依赖旧的 Jacobian 数值导数映射回退路径。
- `[x]` RTCP-09 完成接口扩展收敛：`KinematicsModel` 导数映射协议已切换为机型显式实现，基础类仅保留 fail-fast `Unsupported`。
- `[x]` 完成 `XYZ/XYZA/XYZAC_*/XYZBC_*/ARM6R` 的机型级 `map_cartesian_derivatives` 实现并通过现有回归套件验证。
- `[x]` 完成 `XYZ/XYZA/ARM6R` 的机型级 `jacobian` 解析实现，消除对基类有限差分 Jacobian 的运行时依赖。
- `[x]` 修复 `CalibratedKinematics` 导数映射透传缺失问题，导数请求按校准矩阵逆变换后正确下发至内层机型。

## 2026-04-12 TODO Explicit-Completion Migration
- `[x]` RA-01 已具备 5轴/6轴运动学插件框架（`XYZAC_*`, `XYZBC_*`, `ARM6R`）与运行时机型切换能力。
- `[x]` RA-02 已具备 canonical->planner->interpolator 主链路，支持 MDI/AUTO 轨迹执行与诊断输出。
- `[x]` RTCP-02 已在 canonical 输出 RTCP 状态字段（mode_code/rtcp_enabled/apply_state）。
- `[x]` RTCP-13 planner 已接入 RTCP 分支（IK hint/约束/插补链路）。
- `[x]` RTCP-14 已接入 A/B/C 展开与抗跳变机制并补回归用例。
- `[x]` RTCP-17 已在 planner 诊断补充 RTCP 字段（enabled/mode/condition/singularity/degrade/tcp_error）。
- `[x]` TCPU-01 `TCP_UNIFIED` 已注册并作为当前默认插补算法启用（`planner.auto_algo/mdi_algo` 默认即 `TCP_UNIFIED`）。
- `[x]` TCPU-02 已具备 block 扩展、几何预处理、corner transition、速度规划、7段 S 曲线时间律主链路。
- `[x]` TCPU-03 已具备基于 IK anchor 的笛卡尔路径重建能力，能在 RTCP 模式下运行基础直线/圆弧段。
- `[x]` MID-01 已具备运动学/动力学模型工厂与机型参数注入路径，可作为辨识与补偿的承载层。
- `[x]` MID-02 已具备 runtime 配置加载与参数持久化链路，可承载 tuning 参数集管理与回滚。

## Development North Star
## 0. Current Baseline (Already Landed)
- `[x]` Core/Guardian/Qt/Web main communication paths connected (HTTP + ZMQ topics).
- `[x]` Shared memory RT channel basic ring established and exposed via `/v1/rt/channel` + `diag.rt_channel`.
- `[x]` Qt RT SHM reader integrated, with batch catch-up, torn-frame check, drop counting, placeholder logs.
- `[x]` Dynamic RT downsample command wired (`core.rt.channel.config`) and synced into runtime/SHM header.
- `[x]` Critical logging path unified for key control commands.
- `[x]` Icons path unified to `icons/`.
## 1. Delivery Roadmap (Execution Order)
## M1. Interface Contract Freeze (System Integration Foundation)
Goal: stop interface drift and make all processes evolve safely.
- `[x]` M1-01 Freeze command contract (`cmd`, args schema, error codes, placeholder policy).
- `[x]` M1-02 Freeze topic contract (`state.*`, `event.*`, `diag.*`, `guardian.heartbeat`).
- `[x]` M1-03 Freeze SHM contract (header/sample layout, seq semantics, versioning).
- `[x]` M1-04 Add protocol compatibility notes in README (`added/changed/deprecated` rules).
## M2. Core Runtime Reliability (Before Algorithm Expansion)
Goal: stabilize state machine, safety gates, and process behavior under fault.
- `[x]` M2-01 Keep centralized state transitions (`IDLE/READY/RUN/HOLD/FAULT/ESTOP/RESET/HOME`).
- `[x]` M2-02 Harden transition matrix with negative-path checks (invalid mode/state commands).
- `[x]` M2-03 Expand Guardian policy from placeholder HOLD to threshold-based actions.
- `[x]` M2-04 Implement Guardian process-watch restart strategy (backoff/max retry/restart reason).
- `[x]` M2-05 Add crash/recovery event chain (`event.lifecycle`) and persistent restart counters.
## M3. Real-Time Data Plane Completion (SHM First-Class)
Goal: make RT data channel production-grade for research diagnostics.
- `[x]` M3-01 SHM ring + reader pipeline connected end-to-end.
- `[x]` M3-02 Keep `downsample` runtime reconfiguration stable under load.
- `[x]` M3-03 Replace placeholder telemetry in SHM sample (`qdot`, `err`, `s`, `sdot`, `sddot`, `jitter`, `overrun`).
- `[x]` M3-04 Add Qt waveform renderer (30fps UI, decoupled from SHM read thread).
- `[x]` M3-05 Add recorder/replay for SHM stream (research workflow baseline).
- `[x]` M3-06 Expose RT control/visibility in Web (downsample + writer_hz + channel health).
## M4. Motion Kernel And Constraints (Algorithm Core)
Goal: replace diagnostics placeholders with real motion/planning outputs.
- `[x]` M4-01 Keep planner/interp command flow stable and observable.
- `[x]` M4-02 Implement baseline interpolation outputs (line/arc/spline minimum viable set).
- `[x]` M4-03 Implement constraint outputs (velocity/acceleration/jerk saturation).
- `[x]` M4-04 Wire real metrics into `diag.planner`, `diag.constraints`, `diag.perf`.
- `[x]` M4-05 Align command behavior (`run/hold/resume/stop/reset/seek`) with real planner state.
## M5. G-Code Interpreter Program (RS274 Track)
Goal: deliver deterministic, testable interpreter pipeline integrated with planner.
### M5.1 Parser/Syntax
- `[x]` M5-01 Define supported subset and exclusions (G/M matrix).
- `[x]` M5-02 Build lexer/parser with deterministic error reporting (line parser skeleton landed; line/column pending).
- `[x]` M5-03 Support comments, whitespace, line numbers; checksum as explicit placeholder.
- `[x]` M5-04 Add parser fixture tests (fixture harness landed; corpus/tests pending).
### M5.2 Semantic/Modal Engine
- `[x]` M5-05 Implement modal state machine (motion, distance, plane, units, feed mode).
- `[x]` M5-06 Implement coordinate/work-offset interpretation contract.
- `[x]` M5-07 Validate illegal modal combinations with stable error codes.
- `[x]` M5-08 Add semantic regression tests by line snapshot.
### M5.3 Canonical Command Output
- `[x]` M5-09 Convert blocks to canonical planner commands with deterministic rounding.
- `[x]` M5-10 Attach execution metadata (`program_line`, source span, modal snapshot id).
- `[x]` M5-11 Add canonical output fixture comparison tests.
### M5.4 Runtime Integration
- `[x]` M5-12 Integrate interpreter with ProgramManager queue and seek/restart semantics.
- `[x]` M5-13 Route MDI through same interpreter core (single semantics source).
- `[x]` M5-14 Add end-to-end tests (`load->run->hold->resume->stop->seek->restart`).
### M5.5 Diagnostics And Expansion
- `[x]` M5-15 Publish interpreter diagnostics (`parse_error`, `modal_state`, `line_exec`).
- `[x]` M5-16 Add feature flags and compatibility table in README (supported/unsupported codes).
- `[x]` M5-17 Stage expansion plan: canned cycles/tool length/cutter comp.
## M6. HMI Completion (Qt/Web)
Goal: finish placeholder UI behavior and align Qt/Web semantics.
- `[x]` M6-01 Qt major control surface wired.
- `[x]` M6-02 Remove remaining placeholder-only actions or mark them explicitly in UI.
- `[x]` M6-03 Build Qt/Web parity matrix for command coverage and diagnostics visibility.
- `[x]` M6-04 Add operator-focused fault and recovery guidance in UI state text.
## M7. Testing, Tooling, Release Gate
Goal: enforce quality bar before larger feature rollout.
- `[x]` M7-01 Unit tests: validator/dispatcher/safety gate/SHM reader-writer.
## M8. READ_BEFORE_CODE Compliance Remediation (Audit Scope: exclude `refer/`, `refer1/`)
Goal: align existing code with architecture-first, single-responsibility, reuse-first principles.
### M8.1 File Responsibility And Architecture Boundaries
- `[x]` M8-01 Split oversized mixed-responsibility UI file: `hmi_qt/app/ui/main_window.cpp` (1027 lines) into view/layout/command-binding/topic-handling modules.
- `[x]` M8-02 Split mixed transport+http+asset+ws logic in `hmi_web/gateway/web_gateway_app.cpp` (651 lines) into http router, ws hub, cmd forwarder, and zmq ingest modules.
- `[x]` M8-03 Split guardian policy/network/process-watch concerns in `guardian/app/guardian_app.cpp` (517 lines) into policy engine, probes, and supervisor modules.
- `[x]` M8-04 Continue shrinking `core/app/core_app.cpp` (688 lines): isolate publish/state snapshot/event-drain into dedicated runtime services.
- `[x]` M8-05 Remove now-orphan includes/usings and dead helpers after refactors (e.g. local unused helpers in recently split modules).
### M8.2 Contract Reuse And Single Source Of Truth
- `[x]` M8-06 Eliminate command-contract drift risk: add machine-checkable contract sync (`scripts/check_command_contract.sh`) across dispatcher/validator/schema/envelope.
- `[x]` M8-07 Fill schema gaps for active commands currently missing in `common/ipc/json/schema/cmd/`:
  `core.home.start`, `core.home.axis`, `core.home.abort`, `core.rt.channel.config`.
- `[x]` M8-08 Add CI check to diff command sets across dispatcher/validator/schema and fail on mismatch (`check-command-contract` target).
### M8.3 Architecture-First Endpoint/Config Management
- `[x]` M8-09 Centralize endpoint defaults (`127.0.0.1:18080`, `tcp://127.0.0.1:19010`, `/keniucnc_rtbuf`) into shared config instead of repeating in Core/Guardian/Qt/Web.
- `[x]` M8-10 Replace per-connection detached threads (`std::thread(...).detach()`) in Core/Web gateway with managed session execution model.
- `[x]` M8-11 Add explicit process topology config doc + runtime config loader for Core/Guardian/Gateway/Qt consistency.
### M8.4 Placeholder Debt (Architecture-Driven Replacement Plan)
- `[x]` M8-12 Replace placeholder diagnostics flows in core runtime:
  `diag.planner`, `diag.constraints`, remaining placeholder payload fields in `diag.rt_channel`.
- `[x]` M8-13 Replace placeholder task handlers in `core_app.cpp` (`HOME`, `AUTO_LOAD`, `JOG`) with explicit task service interfaces and implementations.
- `[x]` M8-14 Replace RS274 executor placeholder path (`core/app/interp/executor/executor.hpp`) with architecture-defined modal execution contract.
- `[x]` M8-15 Replace dynamics placeholders (`core/app/motion/dynamics/*`) with model-backed computations per machine class.
- `[x]` M8-16 Replace kinematics placeholder branches (`core/app/motion/kinematics/common_models.cpp`) with validated FK/IK strategies.
- `[x]` M8-17 Replace interpolator placeholders (`core/app/motion/interpolator/*`) with algorithm-specific strategy modules and deterministic constraints.
- `[x]` M8-18 Replace EtherCAT placeholder control loop (`core/app/hal/ethercat/ethercat_hal.cpp`) with concrete lifecycle/state exchange service.
### M8.5 Deterministic Design (Avoid Ad-hoc Fallback Sprawl)
- `[x]` M8-20 Review and reduce ambiguous fallback/status wording (`UP_OR_PLACEHOLDER`, `PLACEHOLDER_OR_EXTERNAL`) by introducing explicit state enums.
- `[x]` M8-21 Add architecture-level error taxonomy for placeholder/unimplemented paths and remove implicit behavior.
- `[x]` M8-22 Add compliance check document that maps each active module to its architecture owner and boundary.
## M9. Execution Backend Mode (SIM/LIVE)
Goal: make simulation/live execution backend a first-class, safe, observable runtime capability.
- `[x]` M9-01 Freeze execution backend configuration (`data/active.json`, `state.system`).
- `[x]` M9-02 Add Core backend switch request path (`command -> rt mailbox -> servo thread`).
- `[x]` M9-03 Implement HAL backend factory and `SIM/LIVE` switch application semantics.
- `[x]` M9-04 Add Qt/Web backend controls + visibility + operator-facing guidance.
- `[x]` M9-05 Add integration tests for backend switch apply/reject and lifecycle event chain.
## 2. Active Sprint (Now)
## Sprint-S0 (Current Focus)
- `[x]` S0-01 Implement real `diag.perf` (`jitter`, `overrun`, `cpu_load`) and feed SHM fields.
- `[x]` S0-02 Add Web controls for `core.rt.channel.config` and channel health display.
- `[x]` S0-03 Start G-code parser skeleton + fixture harness + error code enum.
- `[x]` S0-04 Add first unit tests for `core.rt.channel.config` (validator/safety gate/dispatcher).
## Sprint-S1 (Next)
- `[x]` S1-01 Replace SHM placeholder kinematic fields with real values.
- `[x]` S1-02 Qt waveform panel (30fps) with axis/signal/time-window selectors.
- `[x]` S1-03 Guardian threshold policies with deterministic action matrix.
- `[x]` S1-04 Parser+semantic first supported G-code subset operational.
## 3. Engineering Constraints (Must Follow)

## 2026-02-28 Completed Migration From TODO
- `[x]` Config persistence architecture refactor: unified machine config source to `machine_model` in `data/config/runtime_config.json`, removed duplicated top-level blocks on save.
- `[x]` Config stability fix: `Save Config` crash fixed (invalid iterator lifetime issue in IO mapping traversal).
- `[x]` i18n pipeline landed: Qt `tr()` + `ts/qm` build + runtime language switching via config (`ui.language`, restart effective).
- `[x]` i18n data fix: corrected translation context mismatch (`MainWindow` vs namespaced `MainWindow`) and completed zh_CN translations.
- `[x]` Coordinate system support delivered: `G53/G54` config, runtime apply commands, state/telemetry exposure, and Qt controls.
- `[x]` Axis UI enhancement delivered: default XYZ display + Aux axis selector/jog path.
- `[x]` Restart-required Config tab delivered and modularized (machine model, interpolation, kinematics, servo, IO, WCS, language).
- `[x]` Servo axis config expanded: absolute mode, gear ratio, travel limits, v/a/j, max follow error persisted and applied by Core.
- `[x]` Process constraints added under `machine_model.process_constraints` (feed/acc/jerk/contour error), with Qt edit + Core apply.
- `[x]` Config tab layout optimized: compact multi-column sections, process constraints two-column form, servo and IO reordered per latest UX requests.
- `[x]` Jog panel relocated under MDI; unified jog speed with max single-move distance cap (10 mm/deg).
- `[x]` E-stop button text updated to stateful Chinese labels ("急停按下" / "急停弹出").
- `[x]` CS-01 在 runtime config 定义 `coordinate_systems` 段：`active_wcs`、`g54_offsets`（x/y/z/a/b/c/u/v/w）。
- `[x]` CS-02 Core 启动加载坐标系配置并映射参数键（`wcs.*`）。
- `[x]` CS-03 状态快照补充 `machine_pos`、`work_pos`、`active_wcs`、`wcs_offsets` 字段（契约同步）。
- `[x]` CS-04 将当前 machine==work 基线改为可插拔坐标变换（首版仅 offset）。
- `[x]` CS-05 新增坐标系命令（建议：`core.wcs.set_active`、`core.wcs.set_offset`），并定义即时生效/重启生效策略。
- `[x]` AX-01 主界面 Position 固定显示 XYZ（大数字），扩展轴移入 `Aux Axis` 选择器显示区。
- `[x]` AX-02 Jog 区域保留 XYZ 快捷按钮，新增 “Selected Axis +/-” 按钮控制选择轴。
- `[x]` AX-03 轴可见性由机床模型派生（3轴仅 XYZ，5轴显示 A/B/C 选项，机器人显示 J1..）。
- `[x]` AX-04 在 `Config` Tab 新增 “Coordinate Systems” 区块（G53/G54 切换 + G54 偏置编辑）。
- `[x]` AX-06 联动状态栏/路径栏：明确展示当前坐标系（避免操作歧义）。
- `[x]` CSAX-01 更新 `data/config/runtime_config.json` 模板，加入 `coordinate_systems` 默认值。
- `[x]` CSAX-02 Core `runtime_config` 解析逻辑加入 `coordinate_systems` 处理。
- `[x]` CSAX-03 `core_state_snapshot` 输出 `machine_pos/work_pos/active_wcs`。
- `[x]` CSAX-04 Qt `Config` Tab 增加坐标系编辑器（含输入校验与保存提示）。
- `[x]` CSAX-05 Qt 主界面新增 `Aux Axis` 选择器和对应 Jog 控件。
- `[x]` TP-01 Define preview contract schema (`segments`, `bounds`, `gcode_properties`, `errors`, line mapping).
- `[x]` TP-02 Implement Core preview parse endpoint with deterministic line mapping.
- `[x]` TP-03 Add `Toolpath3DWidget` to Qt Path tab and replace placeholder canvas hint-only state.
- `[x]` TP-04 Upgrade G-code pane to syntax-highlighted editor with line-number margin and programmatic marker API.
- `[x]` TP-05 Implement bi-directional line linking (text <-> 3D) with anti-loop guard.
- `[x]` TP-06 Unify runtime line tracking (`event.interp`, `state.system.program.current_line`) and fallback strategy.

## 2026-03-07 Large G-code Incremental Architecture (M1-M4 Complete)

Completed items migrated from `docs/large_gcode_incremental_architecture_plan.md`:

### M1 Session + Snapshot Contracts ✅ COMPLETE
- `[x]` Finalize session/run state machines (`IDLE -> INDEXING -> PARTIAL_READY -> READY -> FAILED/CANCELLED`).
- `[x]` Enforce `run.start` binding (`session_id + version + snapshot_id`).
- `[x]` Add `WAIT_DATA` executor state transition (`RUN -> WAIT_DATA -> RUN`).

### M2 ChunkStore ✅ COMPLETE (In-Memory)
- `[x]` `ChunkStore` class with `ChunkKind`, `ChunkManifestEntry`, `ChunkPayload`.
- `[x]` Chunk target size: 2048 segments.
- `[x]` `ProgramManager::rebuild_chunk_store_locked()` builds chunks from entries.

### M3 Delta Protocol ✅ COMPLETE
- `[x]` `/v2/program/changes` returns `events[]`, `added_segment_chunks[]`, `added_line_map_chunks[]`, `version`.
- `[x]` `/v2/program/attach` accepts/returns chunk IDs for delta reconciliation.
- `[x]` Qt client implements chunk-level delta apply.

### M4 Viewport + LOD ✅ COMPLETE
- `[x]` `/v2/program/segments/range?start=&count=&lod=` endpoint.
- `[x]` Qt `Toolpath3DWidget` uses LOD range requests.
- `[x]` Adaptive LOD policy: `compute_lod_stride()`, `should_draw_segment()`.

### API v2 Endpoints ✅ COMPLETE
- `[x]` `POST /v2/program/load`
- `[x]` `GET /v2/program/summary`
- `[x]` `GET /v2/program/segments`
- `[x]` `GET /v2/program/segments/range` (LOD)
- `[x]` `GET /v2/program/line-map`
- `[x]` `GET /v2/program/changes`
- `[x]` `POST /v2/program/attach`

### Remaining Work (M5 Pending)
- `[ ]` True chunk-store ownership (migrate from full `program_entries_` vector to chunk-only storage).
- `[ ]` Disk-backed chunk persistence.
- `[ ]` Memory/disk budget and LRU eviction controls.
- `[ ]` Startup attach from local persistent cache.

## 2026-03-15 Git History Sync Update (2026-03-08 ~ 2026-03-15)

### Program/Chunk Pipeline (M5 Follow-up Landed)
- `[x]` Chunk-only ownership path landed: runtime path no longer depends on full `program_entries_` vector.
- `[x]` Added disk-backed chunk persistence and local chunk ID directory.
- `[x]` Added cache budget controls, stats, and stronger cache validation/cleanup.
- `[x]` Attach/load fallback path improved to recover from attach failures more reliably.

### Motion/Interpreter/Kinematics
- `[x]` Added support for `G40/G61/G64/G91.1/M2` and fixed startup segment index calculation.
- `[x]` Added segmented lookahead budget and tail append/replan support in interpolation path.
- `[x]` Extended kinematics config with calibration and joint/axis offset parameters for multi-axis machines.
- `[x]` Added custom `M` code support and simulation device config loading.

### Tool Management And Runtime Operations
- `[x]` Added tool-management API set (tool config, life consumption, issue query) and migrated tool operations to a dedicated tab.
- `[x]` Added tool config validation/migration and config file management.
- `[x]` Added timeout/retry behavior for tool test steps and pre-run check state in Tools panel.
- `[x]` Refactored tool service into query/command split with improved error handling.
- `[x]` Added operation confirmation and auto-load program support.

### Qt/HMI And Rendering
- `[x]` Migrated toolpath rendering to Qt scene graph, with LOD chunk/cache optimization and pick performance improvements.
- `[x]` Added tool pose rendering and fixed small runtime tracking rollback jitter.
- `[x]` Introduced QtQuick rendering runtime path with adaptive degrade/retry handling and overlay interaction fixes.
- `[x]` Refactored major UI panels (About/IO/BusDiag/Tools) into independent components and simplified MainWindow member layout.
- `[x]` Added feed/spindle override sliders, dynamic/adaptive feed behavior, and MPG guide-mode direct speed override.
- `[x]` Added startup maximize-window behavior and improved ZMQ reconnect handling.

### IO/EtherCAT/Platform
- `[x]` Added async command handling for drive and IO outputs.
- `[x]` Added EtherCAT stale-input detection with degrade protection and alias binding between slaves and axes.
- `[x]` Added analog output control, compact pin syntax, generic DOUT action support, and `io_profile.json` axis input mapping.
- `[x]` Added Orange Pi 5 Plus startup/realtime scripts, IRQ/systemd optimization, cyclictest stress tooling, and scheduler config updates.
- `[x]` Added configurable HTTP server loop parameters and tightened scheduling failure behavior (fail-fast on critical setup errors).

### Setup Wizard And Tooling
- `[x]` Added standalone `setup_wizard` tool with Qt GUI flow and config generation pipeline.
- `[x]` Split wizard steps/modules, added runtime validation/diagnostics, and improved machine config path resolution.
- `[x]` Added bus-slave detail scan/merge and richer EtherCAT/DC configuration fields in wizard.
- `[x]` Added wizard build/run scripts and supporting docs.

### Internationalization/Docs/Tests
- `[x]` Added i18n coverage for tool/IO/program-load logs and fixed incomplete translation entries.
- `[x]` Updated license/versioning docs and module docs (including ToolsPanel notes).
- `[x]` Expanded test lanes/framework, added test run scripts, and refreshed related test architecture docs.
