# Third-Party Licenses

Place all third-party license texts and attribution notices in this directory.

Suggested naming:

- `<component>-LICENSE.txt`
- `<component>-NOTICE.txt`

This directory should cover all runtime, build-time, and vendored dependencies that require attribution.

QCustomPlot-derived `RtWavePlot` (current Qt waveform renderer): see
`qcustomplot-NOTICE.txt` and `qcustomplot-LICENSE.txt`.
