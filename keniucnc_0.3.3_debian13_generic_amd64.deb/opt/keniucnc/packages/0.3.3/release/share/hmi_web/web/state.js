import { t } from "./i18n.js";
const state = {
  httpReady: false,
  wsConnected: false,
  coreLinkHealthy: false,
  stateSynchronized: false,
  eventContinuity: "UNKNOWN",
  controlAccess: null,
  activePage: "control",
  topics: new Map(),
  operationEvents: [],
  operatorNotice: null,
  commandFeedback: null,
  pendingOperationQueries: new Map(),
  programBinding: {
    available: false,
    run_start_permitted: null,
    session_id: "",
    version: 0,
    status: "",
    loaded_path: "",
    fetched_at_ms: 0
  },
  runStartInflight: false,
  guardianWarning: "",
  guardianWarningUntilMs: 0,
  rt: {
    lastRxMs: 0,
    lastSeq: null,
    lastSeqChangeMs: 0
  },
  listeners: new Set()
};
function notify() {
  for (const listener of state.listeners) listener(state);
}

export const store = {
  setControlAccess(controlAccess) {
    state.controlAccess = controlAccess;
    notify();
  },
  get snapshot() { return state; },
  subscribe(listener) {
    state.listeners.add(listener);
    return () => state.listeners.delete(listener);
  },
  setCommandFeedback(text, level, payload, command = "") {
    const id = payload?.id || payload?.request_id || "";
    state.commandFeedback = { text, level, payload, command, id, operationId: payload?.data?.operation_id || "" };
    if (id && (payload?.data?.completion === "ACCEPTED" || payload?.status === "UNCERTAIN")) {
      if (state.pendingOperationQueries.size >= 256 && !state.pendingOperationQueries.has(id)) {
        state.commandFeedback.text += t("；结果查询容量已满，请查看事件中心");
        state.commandFeedback.level = "warn";
      } else {
        state.pendingOperationQueries.set(id, { command, operationId: payload?.data?.operation_id || "",
          createdAt: Date.now(), nextQueryAt: Date.now() + 1000 });
      }
    }
    // Core's terminal event may reach the browser before the HTTP ACK. Reuse
    // the bounded received-event history; never infer completion from telemetry.
    if (state.pendingOperationQueries.has(id)) {
      for (let index = state.operationEvents.length - 1; index >= 0; --index) {
        const event = state.operationEvents[index];
        if (event.topic === "event.operation" && event.data?.command_id === id) this.setOperationResult(event.data);
        if (!state.pendingOperationQueries.has(id)) break;
      }
    }
    if (payload?.data?.operation_phase === "TERMINAL") {
      this.setOperationResult({ command_id: id, kind: command, operation_id: payload.data.operation_id,
        phase: payload.data.operation_phase, outcome: payload.data.operation_outcome,
        message: payload.data.operation_message });
    }
    notify();
  },
  expireOperationQueries(now = Date.now()) {
    let changed = false;
    for (const [id, pending] of state.pendingOperationQueries) {
      if (now - pending.createdAt <= 300000) continue;
      state.pendingOperationQueries.delete(id);
      if (state.commandFeedback?.id === id) {
        state.commandFeedback = { ...state.commandFeedback, text: t("结果尚未确认；请查看事件中心"), level: "warn" };
      }
      changed = true;
    }
    if (changed) notify();
  },
  setOperationResult(data) {
    // Polling expiry releases capacity, but the visible feedback keeps its identity
    // so a later authoritative event can still replace the unconfirmed message.
    const pending = state.pendingOperationQueries.get(data?.command_id) ||
      (state.commandFeedback?.id === data?.command_id && state.commandFeedback.payload?.status !== "SUBMITTING"
        ? state.commandFeedback : null);
    if (!pending || data.kind !== pending.command || (pending.operationId && data.operation_id !== pending.operationId)) return;
    if (data.phase !== "TERMINAL" || !["COMPLETED", "NO_CHANGE", "REJECTED", "FAILED", "PARTIAL", "CANCELLED", "SUPERSEDED"].includes(data.outcome)) return;
    state.pendingOperationQueries.delete(data.command_id);
    if (state.commandFeedback?.id === data.command_id) {
      state.commandFeedback = { ...state.commandFeedback, operationId: data.operation_id, text: data.message || data.outcome,
        level: ["COMPLETED", "NO_CHANGE"].includes(data.outcome) ? "ok" : "bad", payload: data };
    }
    notify();
  },
  setConnection(patch) {
    Object.assign(state, patch);
    notify();
  },
  setStateSynchronized(stateSynchronized) {
    state.stateSynchronized = stateSynchronized;
    notify();
  },
  setActivePage(activePage) {
    state.activePage = activePage;
    notify();
  },
  setProgramBinding(programBinding) {
    state.programBinding = { ...state.programBinding, ...programBinding };
    notify();
  },
  setRunStartInflight(value) {
    state.runStartInflight = value;
    notify();
  },
  setTopic(message) {
    state.topics.set(message.topic, message);
    if (message.topic === "event.operation") this.setOperationResult(message.data);
    if (String(message.topic || "").startsWith("event.") && (message.data?.popup === true || message.data?.notice === true)) {
      state.operatorNotice = { title: String(message.data.title || t("操作提示")),
        message: String(message.data.message || ""), severity: String(message.data.severity || "info") };
    }
    if (String(message.topic || "").startsWith("event.")) {
      state.operationEvents.push(message);
      if (state.operationEvents.length > 1000) state.operationEvents.splice(0, state.operationEvents.length - 1000);
    }
    if (message.topic === "gateway.link") {
      state.coreLinkHealthy = message.data?.state === "HEALTHY";
    }
    if (message.topic === "diag.rt_channel") {
      const now = Date.now();
      const sequence = message.data?.ring?.write_seq ?? null;
      state.rt.lastRxMs = now;
      if (sequence !== state.rt.lastSeq) {
        state.rt.lastSeq = sequence;
        state.rt.lastSeqChangeMs = now;
      }
    }
    if (message.topic === "event.lifecycle" && message.data?.kind === "guardian_policy_hold") {
      state.guardianWarning =
        t("HINT: Guardian 自动 HOLD，原因：{0}（status={1}）。", message.data.reason || "UNKNOWN", message.data.status || "UNKNOWN");
      state.guardianWarningUntilMs = Date.now() + 15000;
    }
    notify();
  },
  dismissOperatorNotice() {
    state.operatorNotice = null;
    notify();
  },
  setOperationHistory(messages) {
    // Read-only history may finish after a live event arrives. Merge display
    // rows without dispatching historical alarms, notices or command results.
    const rows = new Map();
    for (const message of [...(Array.isArray(messages) ? messages.slice(0, 1000) : []), ...state.operationEvents]) {
      const data = message.data;
      const key = data?.event_epoch && Number.isSafeInteger(data.event_sequence)
        ? `${data.event_epoch}:${data.event_sequence}` : JSON.stringify(message);
      rows.set(key, message);
    }
    state.operationEvents = Array.from(rows.values()).sort((a, b) =>
      a.data?.event_epoch && a.data.event_epoch === b.data?.event_epoch
        ? a.data.event_sequence - b.data.event_sequence : (a.ts_ms || 0) - (b.ts_ms || 0)).slice(-1000);
    notify();
  }
};
