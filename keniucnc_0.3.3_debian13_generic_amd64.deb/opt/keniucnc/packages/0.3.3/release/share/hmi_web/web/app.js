import { validatePage } from "./page-contract.js";
import { t, localizeDocument } from "./i18n.js";
import { api } from "./api.js";
import { initializeNotifications } from "./notifications.js";
import { initializeControlSession } from "./control-session.js";
import { commandLabel, commandResponseFeedback } from "./command-presentation.js";
import { bindControls } from "./controls.js";
import { initializeButtonIcons } from "./icons.js";
import { iconTheme } from "./icon-map.js";
import { refreshProgramBinding } from "./program-binding.js";
import { initializeProgramPreview } from "./program-preview.js";
import { initializeProgramFiles } from "./program-files.js";
import { initializePreparation } from "./preparation.js";
import { initializeResponsiveLayout } from "./responsive-layout.js";
import { render, initializeDiagnostics } from "./render.js";
import { initializeRouter } from "./router.js";
import { initializeSkills, setSkillsCoreAvailable } from "./skills.js";
import { store } from "./state.js";
import { resynchronizeAuthoritativeState } from "./state-sync.js";
import { createEventRecovery } from "./event-stream.js";
import { connectTopicStream } from "./ws.js";

// Validate before sessions, event handlers, timers or streams are initialized.
try { validatePage(document); }
catch (error) {
  const notice = document.getElementById("startupInitializationOverlay");
  if (notice) notice.textContent = `Web UI initialization failed: ${error.message}`;
  throw error;
}
localizeDocument(document);

let renderScheduled = false;
function scheduleRender() {
  if (renderScheduled) return;
  renderScheduled = true;
  requestAnimationFrame(() => {
    renderScheduled = false;
    render(store.snapshot);
  });
}

store.subscribe((state) => {
  scheduleRender();
  setSkillsCoreAvailable(state.httpReady && state.wsConnected && state.coreLinkHealthy);
});

initializeButtonIcons();
initializeNotifications();
initializeResponsiveLayout();
const productLogo = document.getElementById("productLogo");
if (productLogo) productLogo.src = `/icons/${iconTheme()}/logo.svg`;
initializeDiagnostics();
document.getElementById("dismissOperatorNotice")?.addEventListener("click", () => store.dismissOperatorNotice());
initializeRouter((route) => store.setActivePage(route));
bindControls({
  store,
  onResult(text, level, payload, command) {
    store.setCommandFeedback(text, level, payload, command);
  }
});
initializeSkills();
initializeControlSession(store);
initializeProgramPreview(store);
initializeProgramFiles(store);
initializePreparation(store);

let recoveryRunning = false;
const eventRecovery = createEventRecovery({
  api,
  onEvent: (message) => store.setTopic(message),
  onDiscontinuity: (detail) => {
    store.setConnection({ eventContinuity: detail.status });
  }
});
let historyRunning = false;
async function readVisibleHistory() {
  if (historyRunning || store.snapshot.activePage !== "events" || !store.snapshot.httpReady) return;
  historyRunning = true;
  try { store.setOperationHistory(await eventRecovery.loadHistory(200)); }
  catch { store.setConnection({ eventContinuity: "HISTORY_UNAVAILABLE" }); }
  finally { historyRunning = false; }
}
let historyVisible = false;
store.subscribe((state) => {
  const visible = state.activePage === "events" && state.httpReady;
  if (visible && !historyVisible) readVisibleHistory();
  historyVisible = visible;
});
setInterval(readVisibleHistory, 5000);
async function recoverCommunicationState() {
  if (recoveryRunning) return;
  recoveryRunning = true;
  store.setStateSynchronized(false);
  try {
    await Promise.all([resynchronizeAuthoritativeState(api, store), eventRecovery.recover()]);
    store.setStateSynchronized(true);
    await api.recoverPendingCommands((result) => {
      const feedback = result.status === "RECOVERED" ? commandResponseFeedback(result.cmd, result.result)
        : { text: t("{0}结果尚未确认：{1}。请核对机床状态，勿盲目重复。", commandLabel(result.cmd), result.reason), level: "warn" };
      store.setCommandFeedback(feedback.text, feedback.level, result.result || { id: result.id }, result.cmd);
    });
  } catch {
    store.setStateSynchronized(false);
  } finally {
    recoveryRunning = false;
  }
}

connectTopicStream({
  onOpen: () => {
    store.setConnection({ wsConnected: true });
    recoverCommunicationState();
  },
  onClose: () => {
    store.setStateSynchronized(false);
    store.setConnection({ wsConnected: false, coreLinkHealthy: false });
  },
  onMessage: (message) => {
    if (String(message.topic || "").startsWith("event.")) {
      if (!eventRecovery.accept(message)) eventRecovery.recover();
      return;
    }
    store.setTopic(message);
  }
});

async function pollLiveness() {
  try {
    await api.live();
    store.setConnection({ httpReady: true });
  } catch {
    store.setConnection({ httpReady: false });
  }
}

async function pollCoreHealth() {
  try {
    await api.health();
  } catch {
    store.setConnection({ coreLinkHealthy: false });
  }
}

pollLiveness();
refreshProgramBinding(store);
setInterval(pollLiveness, 1500);
setInterval(pollCoreHealth, 1500);
setInterval(() => eventRecovery.recover().catch(() => store.setStateSynchronized(false)), 2000);
setInterval(() => refreshProgramBinding(store), 2000);
// Periodic refresh only advances time-derived presentation such as stale-age
// labels. Topic bursts are coalesced to one DOM update per animation frame.
setInterval(scheduleRender, 1000);
scheduleRender();

// Read-only reconciliation of Core results; this never submits machine intent.
let operationQueriesRunning = false;
async function reconcileOperationResults() {
  if (operationQueriesRunning) return;
  operationQueriesRunning = true;
  try {
    store.expireOperationQueries();
    let budget = 8;
    for (const [id, pending] of store.snapshot.pendingOperationQueries) {
      const now = Date.now();
      if (pending.nextQueryAt > now) continue;
      if (budget-- === 0) break;
      pending.nextQueryAt = now + 1000;
      try {
        const result = await api.operation(pending.operationId || id);
        if (result?.ok) store.setOperationResult(result.data);
      } catch { /* Keep the outcome unknown until a Core result arrives. */ }
    }
  } finally { operationQueriesRunning = false; }
}
setInterval(reconcileOperationResults, 1000);
