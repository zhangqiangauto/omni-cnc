const CURSOR_KEY = "keniucnc.web.event-cursor.v1";
const MAX_BUFFERED_LIVE_EVENTS = 512;

function writeCursor(cursor, storage = null) {
  let target = storage;
  try { target ||= globalThis.localStorage; } catch { target = null; }
  if (!target) return false;
  try { target.setItem(CURSOR_KEY, JSON.stringify(cursor)); return true; } catch { return false; }
}

function normalizedEvent(message) {
  const sequence = Number(message?.data?.event_sequence);
  const epoch = String(message?.data?.event_epoch || "");
  if (!Number.isSafeInteger(sequence) || sequence <= 0 || !epoch) return null;
  return { message, sequence, epoch };
}

// Establishes a fresh Guardian boundary for each page lifetime. Durable history
// is never replayed through the live presentation path; events observed while
// the boundary request is in flight are buffered and delivered only when they
// are newer than that boundary.
export function createEventRecovery({ api, onEvent, onDiscontinuity = () => {}, storage = null }) {
  let cursor = { epoch: "", sequence: 0 };
  let state = "EstablishingBaseline";
  let recovering = null;
  const buffered = new Map();

  function persist() { writeCursor(cursor, storage); }

  function resetForBaseline(detail = null) {
    if (detail) onDiscontinuity(detail);
    cursor = { epoch: "", sequence: 0 };
    state = "EstablishingBaseline";
    persist();
  }

  function buffer(event) {
    if (buffered.size >= MAX_BUFFERED_LIVE_EVENTS && !buffered.has(event.sequence)) {
      buffered.clear();
      resetForBaseline({ status: "LIVE_BUFFER_OVERFLOW" });
      return false;
    }
    buffered.set(event.sequence, event);
    return true;
  }

  function deliver(event) {
    if (event.epoch !== cursor.epoch) return false;
    if (event.sequence <= cursor.sequence) return true;
    if (event.sequence !== cursor.sequence + 1) return false;
    onEvent(event.message, { origin: "Live" });
    cursor = { epoch: event.epoch, sequence: event.sequence };
    persist();
    return true;
  }

  function accept(message) {
    const event = normalizedEvent(message);
    if (!event) return false;
    if (state !== "Live") return buffer(event);
    if (event.epoch !== cursor.epoch) {
      const previous = cursor;
      buffered.clear();
      buffer(event);
      resetForBaseline({ status: "EPOCH_CHANGED", previous,
        current: { epoch: event.epoch, sequence: event.sequence } });
      return false;
    }
    if (event.sequence <= cursor.sequence) return true;
    if (event.sequence !== cursor.sequence + 1) {
      buffer(event);
      state = "CatchingUp";
      return false;
    }
    return deliver(event);
  }

  function ingestRecord(record) {
    const event = normalizedEvent({
      ver: 1, type: "push", topic: record.topic, ts_ms: record.ts_ms, data: record.data
    });
    return event !== null && deliver(event);
  }

  function drainBuffered() {
    for (;;) {
      const event = buffered.get(cursor.sequence + 1);
      if (!event) break;
      buffered.delete(event.sequence);
      if (!deliver(event)) return false;
    }
    return true;
  }

  async function establishBaseline() {
    const page = await api.eventsAfter(0, 1);
    const epoch = String(page?.event_epoch || "");
    const latest = Number(page?.latest_sequence || 0);
    if (!epoch || !Number.isSafeInteger(latest) || latest < 0) {
      throw new Error("INVALID_EVENT_BASELINE");
    }
    cursor = { epoch, sequence: latest };
    persist();
    for (const [sequence, event] of buffered) {
      if (event.epoch !== epoch || sequence <= latest) buffered.delete(sequence);
    }
    state = "CatchingUp";
  }

  async function catchUp() {
    for (;;) {
      const page = await api.eventsAfter(cursor.sequence, 256);
      if (String(page?.event_epoch || "") !== cursor.epoch) {
        const previous = cursor;
        resetForBaseline({ status: "EPOCH_CHANGED", previous,
          current: { epoch: String(page?.event_epoch || ""), sequence: 0 } });
        return false;
      }
      if (page.status === "CURSOR_EXPIRED") {
        resetForBaseline({ status: "CURSOR_EXPIRED", oldestSequence: page.oldest_sequence });
        return false;
      }
      for (const record of page.events || []) {
        if (!ingestRecord(record)) throw new Error("NON_CONTIGUOUS_EVENT_RECOVERY");
      }
      drainBuffered();
      if (cursor.sequence >= Number(page.latest_sequence || 0) && buffered.size === 0) return true;
      if (!(page.events || []).length && !buffered.has(cursor.sequence + 1)) {
        throw new Error("EVENT_RECOVERY_STALLED");
      }
    }
  }

  async function recover() {
    if (recovering) return recovering;
    recovering = (async () => {
      for (;;) {
        if (state === "EstablishingBaseline") await establishBaseline();
        if (await catchUp()) {
          state = "Live";
          drainBuffered();
          return cursor;
        }
      }
    })().finally(() => { recovering = null; });
    return recovering;
  }

  async function loadHistory(limit = 200) {
    const count = Math.max(1, limit);
    const page = await api.eventsBefore(0, count);
    return (page.events || []).map((record) => ({
      ver: 1, type: "push", topic: record.topic, ts_ms: record.ts_ms,
      data: record.data, delivery_origin: "StartupHistory"
    }));
  }

  return {
    accept, recover, loadHistory,
    get cursor() { return { ...cursor }; },
    get state() { return state; }
  };
}

export const eventCursorStorageKey = CURSOR_KEY;
