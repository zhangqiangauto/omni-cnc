const ROUTES = new Set(["control", "program", "preparation", "diagnostics", "events", "mcp", "about"]);

function routeFromHash() {
  const route = location.hash.replace(/^#/, "");
  return ROUTES.has(route) ? route : "control";
}

export function initializeRouter(onRoute) {
  const apply = () => {
    const route = routeFromHash();
    if (location.hash !== `#${route}`) history.replaceState(null, "", `#${route}`);
    document.querySelectorAll("[data-page]").forEach((page) => { page.hidden = page.dataset.page !== route; });
    document.querySelectorAll("[data-route]").forEach((link) => {
      const active = link.dataset.route === route;
      link.classList.toggle("active", active);
      link.setAttribute("aria-current", active ? "page" : "false");
    });
    const more = document.querySelector('[data-ui="secondary-navigation"]');
    if (more) more.classList.toggle("active", Boolean(more.querySelector('[aria-current="page"]')));
    onRoute(route);
  };
  addEventListener("hashchange", apply);
  apply();
}
