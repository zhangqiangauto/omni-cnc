import { t } from "./i18n.js";
// Presentation only. This disclosure never changes a command, a permission,
// input draft, or machine state when screen size/orientation changes.
export function initializeResponsiveLayout() {
  const compact = matchMedia("(max-width: 800px), (max-height: 500px)");
  const dock = document.querySelector('[data-ui="operation-dock"]');
  const toggle = document.getElementById("dockExpandButton");
  const machineActions = dock.querySelector('[data-ui="machine-actions"]');
  let expanded = false;
  const render = () => {
    dock.classList.toggle("dock-expanded", expanded || !compact.matches);
    const visible = machineActions ? expanded : expanded || !compact.matches;
    if (machineActions) document.getElementById("dockActions").hidden = !visible;
    toggle.setAttribute("aria-expanded", String(visible));
    toggle.textContent = expanded ? t("收起附加操作") : t("驱动 / 复位 / 起始行");
  };
  toggle.addEventListener("click", () => {
    expanded = !expanded;
    render();
  });
  document.getElementById("closeControlPanel").addEventListener("click", () => {
    const panel = document.querySelector('[data-ui="control-access"]');
    panel.open = false;
    panel.querySelector("summary").focus();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      expanded = false; render();
      document.querySelector('[data-ui="control-access"]').open = false;
      if (!navigation.classList.contains("nav-expanded")) more.open = false;
    }
  });
  document.querySelectorAll('[data-ui="secondary-navigation"] a').forEach((link) => {
    link.addEventListener("click", () => { if (!navigation.classList.contains("nav-expanded")) more.open = false; });
  });
  const navigation = document.querySelector('[data-ui="navigation"]');
  const more = document.querySelector('[data-ui="secondary-navigation"]');
  const mainTabs = navigation.querySelector('[data-ui="primary-navigation"]');
  const fitNavigation = () => {
    const wasExpanded = navigation.classList.contains("nav-expanded");
    const wasOpen = more.open;
    more.open = true;
    navigation.classList.add("nav-expanded");
    const mainWidth = Array.from(mainTabs.children).reduce((sum, link) => sum + link.getBoundingClientRect().width + 4, 0);
    const required = mainWidth + more.querySelector('[data-ui="secondary-links"]').scrollWidth + 8;
    const fits = required <= navigation.clientWidth;
    navigation.classList.toggle("nav-expanded", fits);
    more.open = fits || (!wasExpanded && wasOpen);
  };
  new ResizeObserver(fitNavigation).observe(navigation);
  document.fonts.ready.then(fitNavigation);
  new ResizeObserver(() => {
    document.documentElement.style.setProperty("--operation-dock-height", `${dock.getBoundingClientRect().height}px`);
  }).observe(dock);
  compact.addEventListener("change", render);
  render();
}
