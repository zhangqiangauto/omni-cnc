export function rtChannelView(message, rtState, now = Date.now()) {
  if (!message?.data) {
    return { label: "NO_DATA", level: "warn", detail: "waiting for diag.rt_channel", values: {} };
  }
  const channel = message.data.channel || {};
  const ring = message.data.ring || {};
  const ageMs = rtState.lastRxMs > 0 ? now - rtState.lastRxMs : -1;
  const frozenMs = rtState.lastSeqChangeMs > 0 ? now - rtState.lastSeqChangeMs : -1;
  let label = "HEALTHY";
  let level = "ok";
  if (!channel.enabled || channel.status !== "UP") ({ label, level } = { label: "DOWN", level: "warn" });
  else if (ageMs > 3000) ({ label, level } = { label: "STALE", level: "warn" });
  else if (frozenMs > 5000) ({ label, level } = { label: "SEQ_FROZEN", level: "warn" });
  return {
    label,
    level,
    detail: `enabled=${Boolean(channel.enabled)} status=${channel.status || "-"} age=${ageMs}ms`,
    values: {
      status: `${channel.status ?? "-"} / enabled=${Boolean(channel.enabled)}`,
      downsample: channel.downsample ?? "-",
      writerHz: channel.writer_hz ?? "-",
      writeSeq: ring.write_seq ?? "-",
      ageMs: ageMs >= 0 ? ageMs : "-",
      seqProgress: frozenMs < 0 ? "-" : (frozenMs < 300 ? "ADVANCING" : frozenMs <= 5000 ? `STEADY (${frozenMs}ms)` : `STALLED (${frozenMs}ms)`),
      frame: ring.frame ?? "-",
      seqGuard: typeof ring.seq_guard === "object" ? JSON.stringify(ring.seq_guard) : String(ring.seq_guard ?? "-")
    }
  };
}

export function rtcpView(message) {
  const rtcp = message?.data?.rtcp;
  const valid = typeof rtcp?.enabled === "boolean";
  if (!valid) return { label: "UNKNOWN", level: "warn", valid: false, enabled: false, values: {} };
  const modeCode = Number(rtcp.mode_code);
  const mode = modeCode === 434 ? "G43.4" : modeCode === 435 ? "G43.5" : modeCode === 43 ? "G43" : "G49";
  const condition = Number(rtcp.condition_metric);
  const tcpError = Number(rtcp.tcp_error);
  const degrade = String(rtcp.degrade_reason || "NONE");
  let level = rtcp.enabled ? "ok" : "";
  if (rtcp.singularity_near || degrade !== "NONE") level = "warn";
  if (!Number.isFinite(condition) || degrade === "RTCP_SINGULARITY_STOP") level = "bad";
  return {
    label: `${rtcp.enabled ? "ON" : "OFF"} ${mode}`,
    level,
    valid: true,
    enabled: Boolean(rtcp.enabled),
    values: {
      mode,
      condition: Number.isFinite(condition) ? condition.toFixed(3) : "INF",
      error: Number.isFinite(tcpError) ? tcpError.toFixed(4) : "INF",
      singularity: rtcp.singularity_near ? "NEAR" : "CLEAR",
      degrade
    }
  };
}
