import { t, currentLocale } from "./i18n.js";
import { TOPICS } from "./config.js";
import { controlPolicy } from "./control-policy.js";
import { setButtonContent, topicIcon } from "./icons.js";
import { operatorHint, safetyHint } from "./operator-hints.js";
import { rtChannelView, rtcpView } from "./rt-diagnostics.js";
import {
  alarmView,
  axisDescriptors,
  formatNumber,
  formatObservedBoolean,
  formatTimestamp,
  programView,
  taskView
} from "./selectors.js";
import { renderControls, renderRtInput } from "./controls.js";
import { renderProgramDetails } from "./program-details.js";

let activeTopic = "gateway.link";
let latestState = null;

function element(id) { return document.getElementById(id); }
function setText(id, value) { const target = element(id); if (target) target.textContent = String(value ?? "-"); }
function setBadge(id, text, level = "") {
  const target = element(id);
  target.textContent = text;
  for (const state of ["ok", "warn", "bad"]) target.classList.toggle(state, state === level);
}
function renderTopBar(state, system, alarm, rt, rtcp) {
  const access = state.controlAccess;
  setBadge("controlOwnerBadge", access?.can_operate === true ? t("本终端控制") : access?.phase === "DRAINING" ? t("只读 · 交接处理中") : t("只读终端"),
    access?.can_operate === true ? "ok" : "warn");
  setText("controlOwnerLabel", access?.owner_label ? `${access.owner_label} (#${access.owner_session || t("未知")})` : t("无控制终端 / 未知"));
  setText("controlAccessState", !access ? t("等待 Core 控制权状态。")
    : !access.configured ? t("Web 控制连接尚未就绪，本终端保持只读。")
    : access.can_operate ? t("本终端持有控制权")
    : access.phase === "DRAINING" ? t("Core 正在确认交接条件：{0}", access.reason_code || t("等待状态"))
    : t("本终端只读"));
  setText("qtControlOwnerLabel", access?.qt_owner_label || t("现场终端身份未就绪 / 未知"));
  setText("qtControlPhase", access?.qt_phase === "LOCAL" ? t("本地操作，无需申请控制权") : access?.qt_phase === "AVAILABLE" ? t("未配置本地身份") : t("未知"));
  element("acquireControlButton").disabled = access?.can_acquire !== true;
  element("acquireControlButton").hidden = access?.can_release === true;
  element("releaseControlButton").disabled = access?.can_release !== true;
  element("releaseControlButton").hidden = access?.can_release !== true;
  element("logoutControlButton").disabled = access?.authenticated !== true;
  element("authenticateControlButton").disabled = access?.configured !== true || access?.authenticated === true;
  setBadge("wsBadge", state.wsConnected ? t("状态流已连接") : t("状态流未连接"), state.wsConnected ? "ok" : "bad");
  setBadge("httpBadge", state.httpReady ? t("命令通道已连接") : t("命令通道未连接"), state.httpReady ? "ok" : "bad");
  setBadge("linkBadge", state.coreLinkHealthy ? t("Core 链路正常") : t("Core 状态未就绪"), state.coreLinkHealthy ? "ok" : "bad");
  setBadge("modeBadge", t("模式 {0}", system.mode ?? t("未知")));
  setBadge("stateBadge", t("状态 {0}", system.state ?? t("未知")));
  const backend = String(system.execution_backend ?? "-");
  setBadge("backendBadge", `BACKEND ${backend}`,
    backend === "LIVE" ? "warn" : (backend === "SIM" ? "ok" : ""));
  const algorithm = system.algo ?? system.algorithm ?? system.planner?.interpolator?.auto ?? "-";
  setBadge("algorithmBadge", `ALGO ${algorithm}`);
  const p99 = state.topics.get("diag.perf")?.data?.rt_perf?.jitter_us?.p99;
  setBadge("jitterBadge", `JITTER ${p99 ?? "-"}us`);
  setBadge("rtBadge", `RT ${rt.label}${rt.values.writerHz ? ` ${rt.values.writerHz}Hz` : ""}`, rt.level);
  setBadge("rtcpBadge", `RTCP ${rtcp.label}`, rtcp.level);
  setBadge("alarmBadge", alarm.valid ? t("报警 {0}", alarm.count) : t("报警状态未知"),
    alarm.valid ? (alarm.active ? "warn" : "ok") : "");
  setText("stateTime", t("状态时间 {0}", formatTimestamp(state.topics.get("state.system")?.ts_ms)));
  const hint = operatorHint(state);
  setBadge("operatorHint", hint.text, hint.level);
}

function renderAxes(system) {
  const body = element("axisTable");
  body.replaceChildren();
  const axes = axisDescriptors(system);
  if (!axes.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 3;
    cell.textContent = t("Core 尚未发布轴定义");
    row.appendChild(cell);
    body.appendChild(row);
  }
  for (const axis of axes) {
    const row = document.createElement("tr");
    const coordinates = body.dataset?.coordinateOrder === "work-machine"
      ? [axis.work, axis.machine] : [axis.machine, axis.work];
    for (const value of [axis.display, ...coordinates.map((value) => formatNumber(value))]) {
      const cell = document.createElement("td");
      cell.textContent = value;
      row.appendChild(cell);
    }
    body.appendChild(row);
  }
}

function renderProgramBinding(binding) {
  setText("programBindingInfo", binding.session_id
    ? t("版本 {0} · {1}{2}", binding.version, binding.status || t("状态未知"), binding.available === false ? t(" · 数据未同步") : "")
    : t("未装载程序"));
}

function renderHints(state, policy) {
  setText("safetyHint", safetyHint(state));
  setText("cycleHint", policy.runStart.enabled
    ? t("Core 已允许提交启动请求。")
    : t("启动不可用：{0}", policy.runStart.reason || t("等待 Core 权限")));
  setText("backendInfo", t("执行后端：{0}", policy.system.execution_backend ?? t("未知")));

  const ready = policy.authoritative;
  setText("controlGuard", ready ? "" :
    (state.httpReady ? t("控制受限：Core 权威状态链路未就绪。") : t("控制已禁用：HTTP 命令通道不可用。")));
  element("controlGuard").classList.toggle("ok", ready);
  element("controlGuard").classList.toggle("bad", !ready);
}

function renderOverview(state, system, alarm) {
  setText("runState", system.state ?? "-");
  setText("runMode", system.mode ?? "-");
  setText("backend", system.execution_backend ?? "-");
  const drives = typeof system.drives_enable_actual === "boolean"
    ? { valid: true, value: system.drives_enable_actual }
    : typeof system.drives_enabled === "boolean"
      ? { valid: true, value: system.drives_enabled }
      : { valid: false, value: false };
  setText("drives", formatObservedBoolean(drives, t("已使能"), t("未使能"), t("未知")));
  renderAxes(system);

  const coordinates = system.coordinate_systems || {};
  // Optional presentation slots. Read only published values; no readiness or
  // motion conclusion is derived for the layout. Missing data stays unknown.
  const current = state.httpReady && state.wsConnected && state.coreLinkHealthy && state.stateSynchronized === true;
  setText("activeWcsDisplay", current ? coordinates.active_wcs ?? "—" : "—");
  setText("spindleRpmDisplay", current && system.spindle?.rpm_valid === true ? formatNumber(system.spindle.rpm, 0) : "—");
  setText("actualFeedDisplay", current ? formatNumber(system.actual_feed_rate, 1) : "—");
  setText("feedOverrideDisplay", current && typeof system.feed_override === "number" && Number.isFinite(system.feed_override)
    ? formatNumber(system.feed_override * 100, 0) : "—");
  const program = programView(system, state.programBinding);
  setText("wcsInfo", t("工件坐标系：{0} | 程序装载：{1}", coordinates.active_wcs ?? t("未知"), formatObservedBoolean(
    { valid: program.loadedValid, value: program.loaded }, t("已装载"), t("未装载"), t("未知"))));
  const task = taskView(system);
  setText("programName", program.name);
  setText("currentLine", program.currentLine);
  setText("programBuffer", program.buffer);
  setText("programEstimated", program.estimated);
  setText("programElapsed", program.elapsed);
  setText("programRemaining", program.remaining);
  setText("taskStatus", task.task);
  setText("homeStatus", task.home);

  setText("alarmActive", alarm.valid ? (alarm.active ? t("有") : t("无")) : t("未知"));
  setText("alarmCode", alarm.code);
  setText("alarmTime", formatTimestamp(alarm.timestamp));
  const list = element("alarmList");
  list.replaceChildren();
  for (const message of alarm.messages.length ? alarm.messages.slice(0, 3) : [!alarm.valid ? t("报警状态未知") : alarm.active ? t("存在活动报警，详细信息尚未发布") : t("无活动报警")]) {
    const item = document.createElement("li");
    item.textContent = message;
    list.appendChild(item);
  }

  setText("machineModel", system.tcp_pose?.kinematics_model || t("未知"));
  setText("referenceWcs", coordinates.active_wcs ?? "-");
  const toolLength = system.tool?.length ?? system.tool_length;
  const toolLengthValid = typeof toolLength === "number" && Number.isFinite(toolLength);
  setText("toolLength", toolLengthValid ? formatNumber(toolLength, 4) : "-");
  setText("toolLengthHint", toolLengthValid
    ? ""
    : t("刀具长度未知"));
}

function renderRtPanels(rt, rtcp) {
  setText("rtInfo", `${rt.label}: ${rt.detail} | frame=${rt.values.frame ?? "-"} | seq_guard=${rt.values.seqGuard ?? "-"}`);
  setText("rtStatus", rt.values.status ?? "-");
  setText("rtDownsampleValue", rt.values.downsample ?? "-");
  setText("rtWriterHz", rt.values.writerHz ?? "-");
  setText("rtWriteSeq", rt.values.writeSeq ?? "-");
  setText("rtAge", rt.values.ageMs ?? "-");
  setText("rtSeqProgress", rt.values.seqProgress ?? "-");
  renderRtInput(rt.values.downsample);

  setText("rtcpMode", rtcp.values.mode ?? "-");
  setText("rtcpEnabled", rtcp.valid ? (rtcp.enabled ? "ON" : "OFF") : "UNKNOWN");
  setText("rtcpCondition", rtcp.values.condition ?? "-");
  setText("rtcpError", rtcp.values.error ?? "-");
  setText("rtcpSingularity", rtcp.values.singularity ?? "-");
  setText("rtcpDegrade", rtcp.values.degrade ?? "-");
  setText("rtcpHint", !rtcp.valid
    ? "RTCP state unavailable."
    : rtcp.enabled
    ? `RTCP active (${rtcp.values.mode}), cond=${rtcp.values.condition}, tcp_error=${rtcp.values.error}, degrade=${rtcp.values.degrade}`
    : "RTCP disabled or unavailable.");
}

function renderDiagnostics(state) {
  const message = state.topics.get(activeTopic);
  document.querySelectorAll("#topicTabs button").forEach((button) =>
    button.classList.toggle("active", button.dataset.topic === activeTopic));
  setText("diagnosticMeta", message
    ? `${activeTopic} | ts=${formatTimestamp(message.ts_ms)}`
    : t("{0} 暂无数据", activeTopic));
  setText("diagnosticView", JSON.stringify(message || {}, null, 2));
}

export function initializeDiagnostics() {
  const tabs = element("topicTabs");
  tabs.replaceChildren(...TOPICS.map((topic) => {
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.topic = topic;
    const image = document.createElement("img");
    image.src = topicIcon(topic);
    image.alt = "";
    const label = document.createElement("span");
    label.textContent = topic;
    button.append(image, label);
    button.classList.add("with-icon");
    button.addEventListener("click", () => {
      activeTopic = topic;
      renderDiagnostics(latestState);
    });
    return button;
  }));
}

export function formatEventCenterEntry(event) {
  const data = event.data || {};
  if (event.topic !== "event.operation") return `${event.topic}: ${JSON.stringify(data, null, 2)}`;
  return t("{0} [{1}/{2}] {3}\n{4}{5}\n操作 {6}", new Date(data.occurred_at_ms).toLocaleString(currentLocale()), data.phase, data.outcome, data.title, data.message, data.operator_hint ? "；" + data.operator_hint : "", data.operation_id);
}

export function render(state) {
  const startupOverlay = element("startupInitializationOverlay");
  if (startupOverlay) startupOverlay.hidden = state.stateSynchronized === true;
  if (state.activePage === "events") {
    const operationEvents = Array.isArray(state.operationEvents) ? state.operationEvents : [];
    setText("eventCenterMeta", t("Guardian 操作记录：{0} 条（本页最多保留 1000 条）", operationEvents.length));
    setText("eventCenterView", operationEvents.slice(-200).reverse().map(formatEventCenterEntry).join("\n\n"));
  }
  setText("commandSummary", state.commandFeedback?.text || t("尚未发送命令。"));
  for (const level of ["ok", "warn", "bad"]) element("commandSummary").classList.toggle(level, state.commandFeedback?.level === level);
  if (state.commandFeedback) {
    const target = element("commandResult");
    if (target) {
      for (const level of ["ok", "warn", "bad"]) target.classList.toggle(level, state.commandFeedback.level === level);
      target.textContent = state.commandFeedback.text + (state.commandFeedback.payload ? "\n" + JSON.stringify(state.commandFeedback.payload, null, 2) : "");
    }
  }
  latestState = state;
  const system = state.topics.get("state.system")?.data || {};
  const alarm = alarmView(system, state.topics.get("event.alarm"));
  const rt = rtChannelView(state.topics.get("diag.rt_channel"), state.rt);
  const rtcp = rtcpView(state.topics.get("diag.planner"));
  const policy = controlPolicy(state);

  const notice = element("operatorNotice");
  notice.hidden = !state.operatorNotice;
  if (state.operatorNotice) {
    element("operatorNoticeTitle").textContent = state.operatorNotice.title;
    element("operatorNoticeMessage").textContent = state.operatorNotice.message;
    notice.classList.toggle("bad", state.operatorNotice.severity === "error" || state.operatorNotice.severity === "critical");
  }
  renderTopBar(state, system, alarm, rt, rtcp);
  renderControls(state);
  // Render existing policy explanations for touch users; do not recompute admission.
  const reasons = [...document.querySelectorAll("[data-control-reasons] button[disabled][title]")]
    .filter((button) => button.title)
    .map((button) => `${button.textContent.trim()}：${button.title}`);
  element("controlReasons").replaceChildren(...(reasons.length ? reasons : [t("当前没有禁用操作。")])
    .map((text) => { const item = document.createElement("li"); item.textContent = text; return item; }));
  renderHints(state, policy);
  renderProgramBinding(state.programBinding);
  if (state.activePage === "program") renderProgramDetails(state.programBinding);
  renderOverview(state, system, alarm);
  if (state.activePage === "diagnostics") {
    renderRtPanels(rt, rtcp);
    renderDiagnostics(state);
  }
}
