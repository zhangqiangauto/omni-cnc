import { t } from "./i18n.js";
import { api } from "./api.js";

export function decodeControlStatus(payload) {
  const data = payload?.data;
  const booleans = ["configured", "authenticated", "can_acquire", "can_release", "can_renew", "can_operate", "can_assert_estop"];
  if (payload?.ok !== true || !data || data.scope !== "web" || !["AVAILABLE", "OWNED", "DRAINING"].includes(data.phase) ||
      booleans.some((key) => typeof data[key] !== "boolean")) return null;
  return data;
}

export function initializeControlSession(store) {
  const element = (id) => document.getElementById(id);
  let statusRunning = false;
  let renewalRunning = false;
  let actionRunning = false;
  let requestRevision = 0;
  const setUnknown = () => store.setControlAccess(null);
  const refresh = async () => {
    if (statusRunning || actionRunning) return;
    const revision = requestRevision;
    statusRunning = true;
    try {
      const status = decodeControlStatus(await api.controlStatus());
      if (revision === requestRevision) store.setControlAccess(status);
    }
    catch { if (revision === requestRevision) setUnknown(); }
    finally { statusRunning = false; }
  };
  const action = (work) => async () => {
    if (actionRunning) return;
    actionRunning = true;
    ++requestRevision;
    setUnknown();
    element("controlAccessMessage").textContent = t("连接中…");
    try {
      await work();
      element("controlAccessMessage").textContent = "";
    } catch (error) {
      element("controlAccessMessage").textContent = t("控制权请求未确认：{0}", error.message);
    } finally {
      actionRunning = false;
      await refresh();
    }
  };
  const connect = action(async () => {
    const label = element("controlTerminalLabel");
    if (!label.reportValidity()) return;
    await api.openControlSession(label.value);
  });
  element("authenticateControlButton").addEventListener("click", connect);
  element("acquireControlButton").addEventListener("click", action(() => api.acquireControl()));
  element("releaseControlButton").addEventListener("click", action(() => api.releaseControl()));
  element("logoutControlButton").addEventListener("click", action(() => api.closeControlSession()));
  // Renewal preserves an existing transport identity only. It never acquires,
  // resumes machine motion, retries an intent or reconstructs lease deadlines.
  setInterval(async () => {
    if (renewalRunning || actionRunning) return;
    renewalRunning = true;
    try { await api.renewControl(); }
    catch { setUnknown(); }
    finally { renewalRunning = false; }
  }, 1000);
  setInterval(refresh, 1000);
  // Establish a page-local session once; acquisition remains explicit.
  connect();
}
