import { t } from "./i18n.js";
import { api } from "./api.js";
import { commandResponseFeedback } from "./command-presentation.js";
import { formatObservedBoolean, observedBoolean } from "./selectors.js";

export function initializePreparation(store) {
  const el = (id) => document.getElementById(id);
  let actions = null, tools = null, change = null, polling = false, busy = false, revision = 0;
  // A draft borrows the immutable response used to populate its fields. Polls
  // replace tools, never advance the draft's Core revision behind the operator.
  let toolDraftBase = null;
  const message = (text) => { el("preparationMessage").textContent = text; };
  const owner = () => store.snapshot.controlAccess?.can_operate === true && store.snapshot.httpReady && store.snapshot.wsConnected && store.snapshot.coreLinkHealthy && store.snapshot.stateSynchronized;
  const permitted = (command) => owner() && !busy && actions?.[command]?.permitted === true;
  const bindCommand = (id, command, args) => el(id).addEventListener("click", () => submit(command,args()));
  const numeric = (id) => {
    const input = el(id);
    if (!input.reportValidity() || input.value.trim() === "" || !Number.isFinite(input.valueAsNumber)) throw new Error(t("请输入有效数字"));
    return input.valueAsNumber;
  };
  const refreshPermissions = () => {
    for (const [id,command] of [["prepareHomeMode","core.ctrl.mode.set"],["prepareHomeStart","core.home.start"],["prepareHomeAbort","core.home.abort"],
      ["prepareWcsActive","core.wcs.set_active"],["prepareWcsOffset","core.wcs.set_offset"],["prepareWcsOrigin","core.wcs.set_origin"],["prepareWcsConfirm","core.wcs.confirm_origin"]]) {
      el(id).disabled = !permitted(command);
      el(id).title = actions?.[command]?.reason || t("等待 Core 权限或本终端控制权");
    }
    for (const [id,action] of [["toolConfirmUnloaded","confirm_unloaded"],["toolConfirmLoaded","confirm_loaded"],["toolConfirmIdentity","confirm_identity"],["toolAbort","abort"]])
      el(id).disabled = !owner() || busy || change?.operator_actions?.[action] !== true;
    el("toolMeasurementSave").disabled = !owner() || busy || tools?.management?.actions?.edit_measurement !== true;
    el("toolGeometrySave").disabled = !owner() || busy || tools?.management?.actions?.edit_config !== true;
    el("prepareToolSelect").disabled = busy;
    el("prepareToolReload").disabled = busy || !tools || !el("prepareToolSelect").value;
    el("prepareToolPreflight").disabled = !owner() || busy || store.snapshot.programBinding.available !== true ||
      store.snapshot.topics.get("state.system")?.data?.control_capabilities?.run_preflight?.permitted !== true;
  };
  const refresh = async () => {
    if (polling || busy || store.snapshot.activePage !== "preparation" || !store.snapshot.httpReady) return;
    polling = true;
    const serial = revision;
    try {
      const [view, config, status] = await Promise.all([api.preparation(),api.tooling(),api.command("core.tool_change.status",{})]);
      if (serial !== revision) return;
      actions = view?.ok === true ? view.data?.actions : null;
      tools = config?.ok === true ? config.data : null;
      change = status?.ok === true ? status.data : null;
      const select = el("prepareToolSelect"), selected = select.value;
      const options = [new Option(t("选择刀具"), ""), ...(tools?.tools || []).map((tool) => new Option(`T${tool.tool_no} · ${tool.name} · H${tool.h_no} / D${tool.d_no}`,tool.tool_id))];
      if (select.options.length !== options.length || options.some((option,index) => option.value !== select.options[index].value || option.text !== select.options[index].text))
        select.replaceChildren(...options);
      select.value = selected;
      if (!select.value) { toolDraftBase = null; el("prepareToolDraftIdentity").textContent = t("请选择刀具"); }
      el("toolChangeState").textContent = change ? t("请求 {0} · 阶段 {1} · 已安装 T{2} → 目标 T{3} · {4}", change.request_id, change.state ?? t("未知"), change.installed_tool_no ?? t("未知"), change.target_tool_no ?? t("未知"), change.failure_reason || "") : t("换刀状态未知");
      const body = el("prepareToolRows");
      body.replaceChildren(...(tools?.tools || []).map((tool) => {
        const offset = tools.offsets?.find((entry) => entry.tool_id === tool.tool_id);
        const row = document.createElement("tr");
        for (const value of [tool.tool_no,tool.name,tool.h_no,tool.d_no,tool.diameter_mm,offset?.length_offset_mm,offset?.measurement_state,tool.status]) {
          const cell = document.createElement("td"); cell.textContent = value ?? t("未知"); row.appendChild(cell);
        }
        return row;
      }));
    } catch (error) { if (serial === revision) { actions = null; tools = null; change = null; message(t("准备状态不可用：{0}", error.message)); } }
    finally { polling = false; refreshPermissions(); }
  };
  const work = async (operation) => {
    if (busy) return;
    busy = true; ++revision; refreshPermissions();
    message(t("正在提交请求…"));
    try { await operation(); }
    catch (error) { message(t("操作未确认：{0}", error.message)); }
    finally { busy = false; refreshPermissions(); refresh(); }
  };
  const submit = (command,args) => work(async () => {
    const response = await api.command(command,args);
    const feedback = commandResponseFeedback(command,response);
    message(feedback.text); store.setCommandFeedback(feedback.text,feedback.level,response,command);
  });
  const wcs = () => el("prepareWcs").value;
  bindCommand("prepareHomeMode","core.ctrl.mode.set",() => ({ mode: "HOME" }));
  bindCommand("prepareHomeStart","core.home.start",() => ({}));
  bindCommand("prepareHomeAbort","core.home.abort",() => ({}));
  bindCommand("prepareWcsActive","core.wcs.set_active",() => ({ active_wcs:wcs() }));
  // Numeric syntax is collected here. Range, coordinate and workflow admission
  // remain in Core; no offsets are computed from telemetry in this view.
  el("prepareWcsOffset").addEventListener("click",() => work(async () => {
    const response = await api.command("core.wcs.set_offset",{ wcs:wcs(),axis:el("prepareOffsetAxis").value,value:numeric("prepareOffsetValue") });
    const feedback = commandResponseFeedback("core.wcs.set_offset",response);
    message(feedback.text); store.setCommandFeedback(feedback.text,feedback.level,response,"core.wcs.set_offset");
  }));
  bindCommand("prepareWcsOrigin","core.wcs.set_origin",() => ({ wcs:wcs() }));
  bindCommand("prepareWcsConfirm","core.wcs.confirm_origin",() => ({ wcs:wcs(),confirmed:true,source:"web.operator" }));
  for (const [id,command] of [["toolConfirmUnloaded","core.tool_change.confirm_unloaded"],["toolConfirmLoaded","core.tool_change.confirm_loaded"],
    ["toolConfirmIdentity","core.tool_change.confirm_identity"],["toolAbort","core.tool_change.abort"]]) {
    el(id).addEventListener("click",() => work(async () => {
      const args = { request_id:change?.request_id };
      if (command.endsWith("confirm_loaded") || command.endsWith("confirm_identity")) args.observed_tool_no = numeric("observedToolNumber");
      const response = await api.command(command,args);
      const feedback = commandResponseFeedback(command,response);
      message(feedback.text); store.setCommandFeedback(feedback.text,feedback.level,response,command);
    }));
  }
  const readToolDraft = () => {
    toolDraftBase = null;
    const tool = tools?.tools?.find((entry) => entry.tool_id === el("prepareToolSelect").value);
    if (!tool) { el("prepareToolDraftIdentity").textContent = t("所选刀具不可用"); refreshPermissions(); return; }
    toolDraftBase = tools;
    el("prepareToolH").value = tool.h_no; el("prepareToolD").value = tool.d_no; el("prepareToolDiameter").value = tool.diameter_mm;
    const offset = tools.offsets?.find((entry) => entry.tool_id === tool.tool_id);
    el("prepareToolLength").value = offset?.length_offset_mm ?? "";
    el("prepareToolDraftIdentity").textContent = t("T{0} · 输入版本 {1}", tool.tool_no, toolDraftBase.revision);
    refreshPermissions();
  };
  el("prepareToolSelect").addEventListener("change",readToolDraft);
  el("prepareToolReload").addEventListener("click",readToolDraft);
  el("toolMeasurementSave").addEventListener("click",() => work(async () => {
    if (!toolDraftBase || !el("prepareToolSelect").value) throw new Error(t("请选择刀具并重新读取输入值"));
    const response = await api.maintainTool({ revision:toolDraftBase.revision,tool_id:el("prepareToolSelect").value,action:"SET_MEASUREMENT",length_offset_mm:numeric("prepareToolLength") });
    message(response?.ok ? t("Core 已返回刀长保存结果，请核对刀具表。") : response?.msg || t("刀长保存未确认"));
  }));
  el("toolGeometrySave").addEventListener("click",() => work(async () => {
    if (!toolDraftBase) throw new Error(t("请选择刀具并重新读取输入值"));
    const config = structuredClone(toolDraftBase);
    delete config.management;
    const tool = config.tools.find((entry) => entry.tool_id === el("prepareToolSelect").value);
    if (!tool) throw new Error(t("请选择刀具"));
    tool.h_no=numeric("prepareToolH"); tool.d_no=numeric("prepareToolD"); tool.diameter_mm=numeric("prepareToolDiameter");
    const response=await api.updateTools(toolDraftBase.revision,config);
    message(response?.ok ? t("Core 已返回刀具配置保存结果，请核对刀具表。") : response?.msg || t("保存未确认"));
  }));
  el("prepareToolPreflight").addEventListener("click",() => work(async () => {
    const binding = store.snapshot.programBinding;
    const response = await api.toolingPreflight({ machine_id:el("prepareMachineId").value,session_id:binding.session_id,version:binding.version });
    const data=response?.data;
    message(response?.ok ? t("Core 刀具检查：{0}；{1}", data?.result ?? t("未知"), (data?.issues || []).map((issue) => issue.message || issue.reason || issue.code).join("；")) : response?.msg || t("检查结果未确认"));
  }));
  let wasVisible = false;
  store.subscribe((state) => {
    const system=state.topics.get("state.system")?.data || {};
    el("prepareHomeReadiness").textContent=t("Core 回参考点确认：{0}；{1}", formatObservedBoolean(observedBoolean(system.home_readiness?.machine_confirmed),t("已确认"),t("未确认"),t("未知")), system.home_readiness?.blocking_reason ?? t("未提供原因"));
    el("prepareWcsCurrent").textContent=t("当前工件坐标系：{0}", system.coordinate_systems?.active_wcs ?? t("未知"));
    if (!state.httpReady || !state.wsConnected || !state.coreLinkHealthy || !state.stateSynchronized || state.activePage !== "preparation") { ++revision; actions=null; change=null; }
    const visible = state.activePage === "preparation" && state.httpReady;
    if (visible && !wasVisible) refresh();
    wasVisible = visible;
    refreshPermissions();
  });
  refreshPermissions(); refresh(); setInterval(refresh,2000);
}
