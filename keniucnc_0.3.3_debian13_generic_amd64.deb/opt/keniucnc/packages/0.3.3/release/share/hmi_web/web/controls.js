import { t } from "./i18n.js";
import { api } from "./api.js";
import { makeRequestId } from "./command-client.js";
import { controlPolicy, humanAutoReason } from "./control-policy.js";
import { setButtonContent } from "./icons.js";
import { InputDraft } from "./input-draft.js";
import { commandLabel, commandResponseFeedback } from "./command-presentation.js";
import { axisDescriptors } from "./selectors.js";

let currentState = null;
let sendResult = () => {};
const jogPressedAt = new Map();
let jogSessionSequence = 0;
let activeVelocityJog = null;
let jogKeepaliveTimer = null;
const overrideFields = [
  { id: "feedOverride", kind: "FEED", source: "feed_override", button: "applyFeedOverride" },
  { id: "spindleOverride", kind: "SPINDLE", source: "spindle_override", button: "applySpindleOverride" },
  { id: "rapidOverride", kind: "RAPID", source: "rapid_override", button: "applyRapidOverride" }
];
const inputDrafts = new Map();

function element(id) { return document.getElementById(id); }

function setEnabled(target, policy) {
  if (!target) return;
  target.disabled = !policy.enabled;
  target.title = policy.enabled ? "" : policy.reason;
  target.setAttribute("aria-disabled", String(!policy.enabled));
}
async function send(command, args, { quiet = false } = {}) {
  if (!currentState?.httpReady) {
    sendResult(t("{0}未提交：HTTP 命令通道不可用", commandLabel(command)), "bad");
    return null;
  }
  const requestId = makeRequestId();
  if (!quiet) sendResult(t("{0}正在提交…", commandLabel(command)), "warn", { id: requestId, status: "SUBMITTING" }, command);
  try {
    const response = await api.command(command, args, { requestId });
    const feedback = commandResponseFeedback(command, response);
    if (!quiet || response?.ok !== true) sendResult(feedback.text, feedback.level, response, command);
    return response;
  } catch (error) {
    const uncertain = error?.state === "UNCERTAIN";
    sendResult(uncertain
      ? t("{0}结果待核实；请核对权威状态，勿盲目重复操作（请求 {1}）", commandLabel(command), error.requestId)
      : t("{0}失败：{1}", commandLabel(command), error.message), uncertain ? "warn" : "bad", error.payload || { id: error.requestId }, command);
    return error.payload || null;
  }
}

function readNumber(id) {
  const input = element(id);
  if (!input || !input.reportValidity() || input.value.trim() === "" || !Number.isFinite(input.valueAsNumber)) {
    sendResult(t("未提交：请输入有效数字，输入值不会被自动替换或截断。"), "warn");
    return null;
  }
  return input.valueAsNumber;
}

function nextJogSessionId() {
  const timeSeed = Date.now() * 1000;
  jogSessionSequence = Math.max(jogSessionSequence, timeSeed) + 1;
  return jogSessionSequence;
}

function jogArgs(direction, sessionId = 0, axis = Number(element("jogAxis").value), mode = element("jogMode").value) {
  if (!element("jogAxis").value || !Number.isInteger(axis)) {
    sendResult(t("未提交：Core 尚未发布有效的轴映射。"), "warn");
    return null;
  }
  const velocity = readNumber("jogVelocity");
  const distance = mode === "DIST" ? readNumber("jogDistance") : null;
  if (velocity === null || (mode === "DIST" && distance === null)) return null;
  const args = {
    axis,
    mode,
    vel: velocity,
    dir: direction
  };
  if (sessionId > 0) args.jog_session_id = sessionId;
  if (mode === "DIST") args.distance = distance;
  return args;
}

function stopActiveVelocityJog(event = null) {
  if (activeVelocityJog === null) return;
  if (event?.pointerId !== undefined && event.pointerId !== activeVelocityJog.pointerId) return;
  const stopped = activeVelocityJog;
  activeVelocityJog = null;
  if (jogKeepaliveTimer !== null) {
    window.clearInterval(jogKeepaliveTimer);
    jogKeepaliveTimer = null;
  }
  send("core.motion.jog.stop", {
    axis: stopped.axis,
    stop_style: "NORMAL",
    jog_session_id: stopped.sessionId
  });
}

function bindJog(button, direction) {
  const key = () => `${element("jogAxis").value}:${direction}`;
  button.addEventListener("pointerdown", (event) => {
    if (button.disabled || (event.pointerType === "mouse" && event.button !== 0)) return;
    if (element("jogMode").value !== "VEL") return;
    if (activeVelocityJog !== null) return;
    event.preventDefault();
    const sessionId = nextJogSessionId();
    const args = jogArgs(direction, sessionId);
    if (!args) return;
    button.setPointerCapture?.(event.pointerId);
    activeVelocityJog = {
      axis: Number(element("jogAxis").value),
      direction,
      pointerId: event.pointerId,
      sessionId
    };
    activeVelocityJog.args = args;
    jogPressedAt.set(key(), Date.now());
    send("core.motion.jog.start", args);
    if (jogKeepaliveTimer === null) {
      jogKeepaliveTimer = window.setInterval(() => {
        if (activeVelocityJog === null) return;
        send("core.motion.jog.keepalive", activeVelocityJog.args, { quiet: true });
      }, 200);
    }
  });
  for (const eventName of ["pointerup", "pointercancel", "pointerleave", "lostpointercapture"]) {
    button.addEventListener(eventName, stopActiveVelocityJog);
  }
  button.addEventListener("click", () => {
    if (element("jogMode").value === "VEL" && Date.now() - Number(jogPressedAt.get(key()) || 0) < 250) return;
    if (element("jogMode").value === "DIST") {
      const args = jogArgs(direction, nextJogSessionId());
      if (args) send("core.motion.jog.start", args);
    }
  });
}

export function bindControls({ store, onResult }) {
  sendResult = onResult;
  for (const id of [...overrideFields.map((field) => field.id), "rtDownsample"]) {
    const input = element(id);
    const draft = new InputDraft(input.value);
    inputDrafts.set(id, draft);
    input.addEventListener("input", () => draft.edit(input.value));
  }
  document.querySelectorAll("[data-command]").forEach((button) => {
    button.addEventListener("click", () => {
      let args = {};
      try { args = JSON.parse(button.dataset.args || "{}"); } catch {}
      send(button.dataset.command, args);
    });
  });

  element("estopButton").addEventListener("click", async () => {
    const system = currentState.topics.get("state.system")?.data || {};
    if (controlPolicy(currentState).operatorStatus.estop) {
      await send("core.safety.estop", { active: false });
    } else {
      await send("core.safety.estop", { active: true });
    }
  });
  element("drivesButton").addEventListener("click", () => {
    const policy = controlPolicy(currentState);
    if (policy.drives.enabled && policy.driveControl.valid) {
      send("core.drives.enable", { enable: policy.driveControl.enable });
    }
  });
  element("modeSelect").addEventListener("change", () =>
    send("core.ctrl.mode.set", { mode: element("modeSelect").value }));
  element("mdiButton").addEventListener("click", () => {
    const input = element("mdiInput");
    if (input.reportValidity()) send("core.motion.mdi", { line: input.value });
  });
  element("loadProgramButton").addEventListener("click", () => {
    const input = element("programPath");
    if (!input.reportValidity() || !input.value.trim()) return;
    send("core.program.load", { path: input.value });
  });

  element("runButton").addEventListener("click", async () => {
    const policy = controlPolicy(store.snapshot);
    if (!policy.runStart.enabled) {
      onResult(t("启动未提交： {0}", policy.runStart.reason.split("；").map(humanAutoReason).join("；")), "warn");
      return;
    }
    const startLine = readNumber("runStartLine");
    if (startLine === null) return;
    // Bind the explicit intent to the program currently displayed. Do not
    // refresh and silently substitute a different session at click time.
    const binding = store.snapshot.programBinding;
    store.setRunStartInflight(true);
    try {
      await send("core.run.start", {
        start_line: startLine,
        dry_run: false,
        session_id: binding.session_id,
        version: binding.version
      });
    } finally {
      // This flag describes the HTTP request only, not machine execution.
      store.setRunStartInflight(false);
    }
  });
  element("holdResumeButton").addEventListener("click", () => {
    const policy = controlPolicy(currentState);
    if (policy.holdResume.enabled) send(policy.operatorStatus.held ? "core.run.resume" : "core.run.hold", {});
  });
  element("stopButton").addEventListener("click", () => {
    const system = currentState.topics.get("state.system")?.data || {};
    const command = system.auto_control_command;
    if (system.auto_control_action_enabled !== true) return;
    if (command === "core.run.stop") send(command, { stop_mode: "SMOOTH" });
    else if (command === "core.run.reset") send(command, {});
  });

  bindJog(element("jogMinus"), "-");
  bindJog(element("jogPlus"), "+");
  window.addEventListener("blur", () => stopActiveVelocityJog());
  window.addEventListener("pagehide", () => stopActiveVelocityJog());
  window.addEventListener("hashchange", () => stopActiveVelocityJog());
  element("jogAxis").addEventListener("change", () => stopActiveVelocityJog());
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) stopActiveVelocityJog();
  });
  element("jogStop").addEventListener("click", () => {
    if (activeVelocityJog !== null) {
      stopActiveVelocityJog();
      return;
    }
    send("core.motion.jog.stop", { axis: -1, stop_style: "NORMAL" });
  });
  element("jogHome").addEventListener("click", () => {
    const velocity = readNumber("jogVelocity");
    if (velocity !== null) send("core.motion.jog.zero.start", { vel: velocity });
  });

  for (const [id, mode] of [["spindleCw", "CW"], ["spindleCcw", "CCW"]]) {
    element(id).addEventListener("click", () => {
      const rpm = readNumber("manualSpindleRpm");
      if (rpm !== null) send("core.spindle.set", { mode, rpm });
    });
  }
  element("spindleStop").addEventListener("click", () => send("core.spindle.set", { mode: "STOP" }));
  for (const field of overrideFields) {
    element(field.button).addEventListener("click", () => {
      const input = element(field.id);
      if (!input.reportValidity() || input.value.trim() === "") return;
      send("core.override.set", { kind: field.kind, value: input.valueAsNumber });
    });
  }
  element("discardOverrideDrafts").addEventListener("click", () => {
    const policy = controlPolicy(store.snapshot);
    for (const field of overrideFields) {
      const value = policy.authoritative ? policy.system[field.source] : null;
      inputDrafts.get(field.id).discard(typeof value === "number" && Number.isFinite(value) ? String(value) : "");
    }
    renderControls(store.snapshot);
  });
  element("rtDownsampleButton").addEventListener("click", () => {
    const downsample = readNumber("rtDownsample");
    if (downsample !== null) send("core.rt.channel.config", { downsample });
  });
  element("discardRtDraft").addEventListener("click", () => {
    const text = element("rtDownsampleValue").textContent;
    element("rtDownsample").value = inputDrafts.get("rtDownsample").discard(text === "-" ? "" : text);
  });
  element("rtcpButton").addEventListener("click", () => {
    if (!controlPolicy(currentState).rtcp.enabled) return;
    const enabled = currentState.topics.get("diag.planner")?.data?.rtcp?.enabled === true;
    send("core.rtcp.set", { enabled: !enabled, mode_code: enabled ? 49 : 434 });
  });
  element("jogMode").addEventListener("change", () => {
    stopActiveVelocityJog();
    renderControls(currentState);
  });
}

function syncJogAxes(system) {
  const select = element("jogAxis");
  const previous = select.value;
  const axes = axisDescriptors(system).filter((axis) => axis.joint !== null);
  if (select.options.length === axes.length && axes.every((axis, index) =>
    select.options[index].value === String(axis.joint) && select.options[index].textContent === axis.display)) return;
  select.replaceChildren(...axes.map((axis) => {
    const option = document.createElement("option");
    option.value = String(axis.joint);
    option.textContent = axis.display;
    return option;
  }));
  if (axes.some((axis) => String(axis.joint) === previous)) select.value = previous;
}

export function renderControls(state) {
  currentState = state;
  const policy = controlPolicy(state);
  const system = policy.system;
  if (activeVelocityJog !== null && !policy.jog.enabled) stopActiveVelocityJog();
  syncJogAxes(system);

  setEnabled(element("estopButton"), policy.estop);
  setEnabled(element("resetButton"), policy.reset);
  setEnabled(element("drivesButton"), policy.drives);
  setEnabled(element("runButton"), policy.runStart);
  setEnabled(element("runStartLine"), policy.runLine);
  setEnabled(element("holdResumeButton"), policy.holdResume);
  setEnabled(element("stopButton"), policy.stop);
  setButtonContent(element("stopButton"), policy.system.auto_control_action === "RESET" ? t("复位") : t("停止"),
    policy.system.auto_control_action === "RESET" ? "reset" : "stop", "system");
  setEnabled(element("modeSelect"), policy.modeSelect);
  for (const id of ["mdiInput", "mdiButton"]) setEnabled(element(id), policy.mdi);
  for (const id of ["programPath", "loadProgramButton"]) setEnabled(element(id), policy.programMutation);
  element("programMutationReason").textContent = policy.programMutation.enabled
    ? t("Core 已允许程序装载；装载与启动是独立操作。") : policy.programMutation.reason;
  for (const id of ["jogMode", "jogAxis", "jogVelocity", "jogMinus", "jogPlus", "jogHome", "jogStop"]) {
    setEnabled(element(id), policy.jog);
  }
  setEnabled(element("jogDistance"), {
    enabled: policy.jog.enabled && element("jogMode").value === "DIST",
    reason: element("jogMode").value === "DIST" ? policy.jog.reason : t("连续点动不使用距离")
  });
  const spindle = system.spindle ?? {};
  for (const id of ["manualSpindleRpm", "spindleCw", "spindleCcw"]) {
    setEnabled(element(id), policy.spindleStart);
  }
  setEnabled(element("spindleStop"), policy.spindleStop);
  element("spindleState").textContent = !policy.authoritative ? t("主轴状态未知（权威状态未就绪）")
    : spindle.waiting_for_speed === true
      ? spindle.readiness_mode === "STARTUP_DELAY" ? t("等待主轴启动") : t("等待主轴到速")
      : typeof spindle.rpm === "number" && spindle.rpm_valid === true
          ? `${spindle.rpm} rpm` : t("主轴转速未知");
  for (const id of overrideFields.flatMap((field) => [field.id, field.button])) {
    setEnabled(element(id), policy.override);
  }
  for (const id of ["rtDownsample", "rtDownsampleButton"]) setEnabled(element(id), policy.rtConfig);
  setEnabled(element("rtcpButton"), policy.rtcp);

  if (element("modeSelect").value !== policy.mode) element("modeSelect").value = policy.mode;
  setButtonContent(element("estopButton"), policy.operatorStatus.estop ? t("解除急停") : t("急停请求"), "estop", "system");
  setButtonContent(element("drivesButton"), policy.driveControl.label, policy.driveControl.icon, "system");
  setButtonContent(element("holdResumeButton"), policy.operatorStatus.held ? t("继续加工") : t("暂停加工"),
    policy.operatorStatus.held ? "cycle-start" : "feed-hold", "system");
  const rtcpEnabled = state.topics.get("diag.planner")?.data?.rtcp?.enabled;
  setButtonContent(element("rtcpButton"), typeof rtcpEnabled !== "boolean" ? t("RTCP 状态未知") : rtcpEnabled ? t("关闭 RTCP") : t("启用 RTCP"), "tcp", "advanced");

  for (const field of overrideFields) {
    const value = policy.authoritative ? system[field.source] : null;
    const text = typeof value === "number" && Number.isFinite(value) ? String(value) : "";
    const draft = inputDrafts.get(field.id);
    element(`${field.id}Actual`).textContent = text ? t("当前生效：{0}", text) : t("当前生效：未知");
    if (draft) {
      const draftText = draft.receive(text);
      if (document.activeElement !== element(field.id)) element(field.id).value = draftText;
      element(`${field.id}Draft`).textContent = draft.edited ? t("本地草稿（独立提交）") : t("跟随当前值");
    }
  }
}

export function renderRtInput(value) {
  const input = element("rtDownsample");
  const draft = inputDrafts.get("rtDownsample");
  if (draft) {
    const text = draft.receive(value === "-" ? "" : value);
    if (document.activeElement !== input) input.value = text;
  }
}
