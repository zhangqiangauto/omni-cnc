import { decodePreviewChunk } from "./program-projection.js";

// Each request owns one disposable worker and one immutable wire buffer. This
// keeps bounded but potentially large CRC/decoding work off the control UI.
self.onmessage = ({ data }) => {
  try {
    const projection = decodePreviewChunk(data.buffer, data.descriptor);
    // Pixel viewport fitting only; these extents are never machine/program
    // bounds, readiness, collision checks or coordinates submitted to Core.
    const extents = [[Infinity, -Infinity], [Infinity, -Infinity], [Infinity, -Infinity]];
    const include = (points, offset) => {
      for (let axis = 0; axis < 3; ++axis) {
        extents[axis][0] = Math.min(extents[axis][0], points[offset + axis]);
        extents[axis][1] = Math.max(extents[axis][1], points[offset + axis]);
      }
    };
    for (const primitive of projection.primitives) {
      if (primitive.kind < 2) { include(primitive.start, 0); include(primitive.target, 0); }
      else for (let index = primitive.polyline_offset; index < primitive.polyline_offset + primitive.polyline_count; ++index)
        include(projection.points, index * 3);
    }
    projection.viewportExtents = extents;
    self.postMessage({ ok: true, projection }, [projection.points.buffer]);
  } catch (error) { self.postMessage({ ok: false, reason: error.message }); }
};
