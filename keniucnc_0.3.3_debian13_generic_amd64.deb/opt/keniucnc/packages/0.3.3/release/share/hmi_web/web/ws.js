import { TOPICS, WS_URL } from "./config.js";

export function connectTopicStream({ onOpen, onClose, onMessage }) {
  let socket = null;
  let stopped = false;
  let retryMs = 500;

  const connect = () => {
    if (stopped) return;
    socket = new WebSocket(WS_URL);
    socket.addEventListener("open", () => {
      retryMs = 500;
      onOpen();
      socket.send(JSON.stringify({
        ver: 1,
        type: "subscribe",
        id: "web-hmi",
        topics: TOPICS,
        max_hz: 10
      }));
    });
    socket.addEventListener("message", (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message?.topic) onMessage(message);
      } catch {
      }
    });
    socket.addEventListener("close", () => {
      onClose();
      if (!stopped) {
        setTimeout(connect, retryMs);
        retryMs = Math.min(retryMs * 2, 5000);
      }
    });
    socket.addEventListener("error", () => socket.close());
  };

  connect();
  return () => {
    stopped = true;
    socket?.close();
  };
}
