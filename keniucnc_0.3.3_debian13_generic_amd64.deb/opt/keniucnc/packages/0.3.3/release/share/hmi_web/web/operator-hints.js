import { t } from "./i18n.js";
import { publishedOperatorStatus } from "./control-policy.js";

// Display Core conclusions only. Text never grants permission or constructs a
// recovery workflow from raw run-state strings or alarm counts.
const READINESS_LABELS = {
  NOT_READY: t("未就绪"), READY: t("就绪"), BLOCKED: t("受阻"),
  TRANSITION: t("切换中"), DEGRADED: t("降级")
};

export function operatorHint(state) {
  if (!state.httpReady) return { text: t("命令通道不可用，请检查网关连接。"), level: "bad" };
  if (!state.wsConnected) return { text: t("状态流未连接，显示数据可能已过期。"), level: "warn" };
  if (!state.coreLinkHealthy) return { text: t("Core 状态链路未就绪，请核对连接与机床状态。"), level: "bad" };
  if (state.stateSynchronized !== true) return { text: t("正在同步权威状态，操作权限尚未就绪。"), level: "warn" };
  if (state.guardianWarning && Date.now() < state.guardianWarningUntilMs) {
    return { text: state.guardianWarning, level: "warn" };
  }
  const system = state.topics.get("state.system")?.data || {};
  const status = publishedOperatorStatus(system);
  if (!status.valid) return { text: t("Core 尚未发布有效的操作状态。"), level: "warn" };
  if (status.estop) return { text: t("Core 状态：急停生效。请查看报警与现场状态。"), level: "bad" };
  if (status.faultLike) return { text: t("Core 状态：存在控制故障。请查看报警与操作记录。"), level: "bad" };
  if (status.held) return { text: t("Core 状态：加工已暂停。"), level: "warn" };
  if (status.running) return { text: t("Core 状态：加工运行中。"), level: "ok" };
  const summary = system.operator_status.operator_summary;
  return { text: t("Core 操作状态：{0}；具体操作以按钮权限为准。", READINESS_LABELS[summary] || t("未知")), level: "" };
}

export function safetyHint(state) {
  if (!state.httpReady) return t("HTTP 命令通道不可用，无法提交机床操作。");
  if (!state.wsConnected || !state.coreLinkHealthy || state.stateSynchronized !== true) {
    return t("权威状态未就绪；各操作按 Core 权限显示。");
  }
  return t("复位、使能和急停解除是独立操作；结果以 Core 返回为准。");
}
