import { t } from "./i18n.js";
import { formatObservedBoolean, observedBoolean } from "./selectors.js";

function text(id, value) {
  document.getElementById(id).textContent = value ?? t("未知");
}

function integer(value) {
  return Number.isSafeInteger(value) && value >= 0 ? String(value) : t("未知");
}

// Render only the Core-published program summary. In particular, progress,
// warnings, run blocking and readiness are never reconstructed from counts.
export function renderProgramDetails(binding) {
  const summary = binding.details || {};
  const observed = (value) => observedBoolean(binding.available === true ? value : undefined);
  text("programSummaryAvailability", binding.available === true
    ? ""
    : t("程序状态未同步，保留上次数据"));
  text("programDetailPath", summary.path);
  text("programDetailSession", summary.session_id);
  text("programDetailVersion", integer(summary.version));
  text("programDetailStatus", summary.status);
  text("programDetailPhase", summary.load_phase);
  text("programDetailFingerprint", summary.program_fingerprint);
  text("programDetailFrame", summary.frame);
  text("programDetailFrameContext", summary.frame_context_id);
  text("programDetailActive", formatObservedBoolean(observed(summary.active), t("是"), t("否"), t("未知")));
  text("programDetailRunnable", formatObservedBoolean(observed(summary.program_runnable), t("是"), t("否"), t("未知")));
  text("programDetailStart", formatObservedBoolean(observed(summary.run_start_permitted), t("已允许"), t("未允许"), t("未知")));
  text("programDetailBlockReason", summary.run_block_reason || summary.error_reason || "—");
  text("programDetailLines", integer(summary.total_lines));
  text("programDetailSegments", integer(summary.total_segments));
  text("programDetailBlocking", integer(summary.blocking_diagnostics_count));
  text("programDetailWarnings", integer(summary.warning_diagnostics_count));
  const progress = document.getElementById("programLoadProgress");
  if (binding.available === true && typeof summary.overall_progress_pct === "number" &&
      Number.isFinite(summary.overall_progress_pct) && summary.overall_progress_pct >= 0 && summary.overall_progress_pct <= 100) {
    progress.value = summary.overall_progress_pct;
    text("programLoadProgressText", `${summary.overall_progress_pct}%`);
  } else {
    progress.removeAttribute("value");
    text("programLoadProgressText", t("加载进度未知"));
  }

  const diagnostics = Array.isArray(summary.diagnostics_preview) ? summary.diagnostics_preview : [];
  const body = document.getElementById("programDiagnosticRows");
  const rows = diagnostics.filter((item) => item && typeof item === "object").map((diagnostic) => {
    const row = document.createElement("tr");
    for (const value of [diagnostic.severity, diagnostic.program_line, diagnostic.code,
      diagnostic.reason, diagnostic.line_text,
      formatObservedBoolean(observedBoolean(diagnostic.run_blocking), t("是"), t("否"), t("未知"))]) {
      const cell = document.createElement("td");
      cell.textContent = value ?? t("未知");
      row.appendChild(cell);
    }
    return row;
  });
  if (!rows.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 6;
    cell.textContent = t("暂无诊断条目");
    row.appendChild(cell);
    rows.push(row);
  }
  body.replaceChildren(...rows);
}
