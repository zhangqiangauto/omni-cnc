export function normalizeStateSnapshot(payload) {
  const candidate = payload?.data;
  if (candidate?.topic === "state.system" && candidate?.data && typeof candidate.data === "object") {
    return candidate;
  }
  if (candidate && typeof candidate === "object") {
    return {
      ver: 1,
      type: "push",
      topic: "state.system",
      ts_ms: Number(payload?.ts_ms || Date.now()),
      data: candidate
    };
  }
  return null;
}

export async function resynchronizeAuthoritativeState(api, store) {
  const message = normalizeStateSnapshot(await api.stateSnapshot());
  if (!message) throw new Error("INVALID_STATE_SNAPSHOT");
  store.setTopic(message);
  return message;
}
