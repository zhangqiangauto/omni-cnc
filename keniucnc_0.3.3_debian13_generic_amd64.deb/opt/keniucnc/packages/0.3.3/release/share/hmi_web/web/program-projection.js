// Transport decoder for Core KNPW v3. Geometry and arc tessellation are already
// published by Core; the browser only verifies the wire contract and draws it.
export const projectionMediaType = "application/vnd.keniucnc.program-projection-chunk.v3";
export const projectionMaxBytes = 32 * 1024 * 1024 + 14;

export function projectionCrc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; ++bit) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function decodePreviewChunk(buffer, expected) {
  const invalid = () => { throw new Error("INVALID_CORE_PREVIEW_CHUNK"); };
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < 42 || buffer.byteLength > projectionMaxBytes) invalid();
  const wire = new DataView(buffer);
  if (wire.getUint32(0, false) !== 0x4b4e5057 || wire.getUint16(4, true) !== 3 ||
      wire.getUint32(6, true) !== buffer.byteLength - 14 ||
      wire.getUint32(10, true) !== projectionCrc32(new Uint8Array(buffer, 14))) invalid();
  let offset = 14;
  const read = (size, method) => {
    if (offset + size > buffer.byteLength) invalid();
    const value = wire[method](offset, true);
    offset += size;
    return value;
  };
  const i32 = () => read(4, "getInt32");
  const u32 = () => read(4, "getUint32");
  const f32 = () => { const value = read(4, "getFloat32"); if (!Number.isFinite(value)) invalid(); return value; };
  const point = () => [f32(), f32(), f32()];
  const descriptor = { chunk_id: i32(), start: i32(), count: i32(), version: i32(), content_crc32: u32() };
  if (descriptor.chunk_id < 0 || descriptor.start < 0 || descriptor.count < 1 || descriptor.count > 4000 || descriptor.version < 1 ||
      !expected || ["chunk_id", "start", "count", "version", "content_crc32"].some((key) => descriptor[key] !== expected[key])) invalid();
  const count = u32();
  if (count !== descriptor.count || offset + count * 46 + 4 > buffer.byteLength) invalid();
  const primitives = [];
  for (let index = 0; index < count; ++index) {
    const primitive = { start: point(), target: point(), polyline_offset: u32(), polyline_count: u32(),
      feed: f32(), file_line: i32(), program_line: i32(), kind: read(1, "getUint8"), segment_kind: read(1, "getUint8") };
    if (primitive.kind > 3 || primitive.segment_kind > 1) invalid();
    primitives.push(primitive);
  }
  const pointCount = u32();
  if (pointCount > 1024 * 1024 || offset + pointCount * 12 !== buffer.byteLength) invalid();
  for (const primitive of primitives) {
    if (primitive.polyline_offset + primitive.polyline_count > pointCount ||
        (primitive.kind >= 2 ? primitive.polyline_count < 2 : primitive.polyline_count !== 0)) invalid();
  }
  const points = new Float32Array(pointCount * 3);
  for (let index = 0; index < points.length; ++index) points[index] = f32();
  return { descriptor, primitives, points };
}
