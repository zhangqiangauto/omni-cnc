// Binding contract shared by complete Classic and Modern HTML shells.
// IDs identify behavior and native control types, never screen coordinates.
export const PAGE_BINDINGS = Object.freeze({
  button: "notificationEntry acquireControlButton releaseControlButton closeControlPanel authenticateControlButton logoutControlButton dismissOperatorNotice closeNotifications refreshNotifications readAllNotifications readNotification mdiButton jogMinus jogPlus jogHome jogStop spindleCw spindleCcw spindleStop applyFeedOverride applySpindleOverride applyRapidOverride discardOverrideDrafts loadProgramButton programUploadButton programSourcePrevious programSourceNext programPreviewPrevious programPreviewNext programPreviewCancel programPreviewZoomIn programPreviewZoomOut programPreviewFit programPreviewRowsPrevious programPreviewRowsNext prepareHomeMode prepareHomeStart prepareHomeAbort prepareWcsActive prepareWcsOffset prepareWcsOrigin prepareWcsConfirm prepareToolReload toolGeometrySave toolMeasurementSave toolConfirmUnloaded toolConfirmLoaded toolConfirmIdentity toolAbort prepareToolPreflight discardRtDraft rtDownsampleButton rtcpButton skillPlanButton skillExecuteButton drivesButton resetButton runButton holdResumeButton stopButton estopButton dockExpandButton",
  canvas: "programPreviewCanvas",
  dd: "alarmActive alarmCode alarmTime programName currentLine programBuffer programEstimated programElapsed programRemaining taskStatus homeStatus programDetailPath programDetailSession programDetailVersion programDetailFingerprint programDetailActive programDetailFrame programDetailFrameContext programDetailStatus programDetailPhase programDetailRunnable programDetailStart programDetailBlockReason programDetailLines programDetailSegments programDetailBlocking programDetailWarnings rtStatus rtDownsampleValue rtWriterHz rtWriteSeq rtAge rtSeqProgress rtcpMode rtcpEnabled rtcpCondition rtcpError rtcpSingularity rtcpDegrade machineModel referenceWcs toolLength",
  dialog: "userNotifications",
  div: "startupInitializationOverlay operatorNotice notificationList programPreviewPaging skillPlanPanel skillExecutePanel dockActions",
  h1: "coordinatesTitle programTitle controlsTitle",
  h2: "notificationHeading programPreviewTitle",
  h3: "notificationTitle",
  img: "productLogo",
  input: "controlTerminalLabel mdiInput jogVelocity jogDistance manualSpindleRpm feedOverride spindleOverride rapidOverride programPath programUploadFile prepareOffsetValue prepareToolH prepareToolD prepareToolDiameter prepareToolLength observedToolNumber prepareMachineId rtDownsample skillConfirmation runStartLine",
  nav: "topicTabs",
  p: "controlAccessState controlAccessMessage operatorNoticeMessage notificationStatus notificationTime wcsInfo controlGuard programBindingInfo cycleHint backendInfo spindleState programSummaryAvailability programMutationReason programFilesMessage programSourceIdentity programPreviewIdentity programExecutionPosition programPreviewMessage preparationMessage prepareHomeReadiness prepareWcsCurrent prepareToolDraftIdentity toolChangeState rtInfo rtcpHint toolLengthHint diagnosticMeta eventCenterMeta skillDescription skillSummary safetyHint commandSummary",
  pre: "notificationBody programSourceText diagnosticView eventCenterView skillPlanView skillResult commandResult",
  progress: "programLoadProgress",
  select: "modeSelect jogMode jogAxis programFileSelection programPreviewPlane prepareWcs prepareOffsetAxis prepareToolSelect skillSelect",
  small: "feedOverrideDraft spindleOverrideDraft rapidOverrideDraft",
  span: "linkBadge modeBadge stateBadge alarmBadge operatorHint controlOwnerBadge qtControlPhase wsBadge httpBadge stateTime feedOverrideActual spindleOverrideActual rapidOverrideActual programPreviewChunkLabel programPreviewRowsLabel programLoadProgressText backendBadge algorithmBadge jitterBadge rtBadge rtcpBadge",
  strong: "controlOwnerLabel qtControlOwnerLabel operatorNoticeTitle runState runMode backend drives skillRisk skillStatus",
  tbody: "axisTable programPreviewRows programDiagnosticRows prepareToolRows",
  textarea: "skillInput",
  ul: "alarmList controlReasons",
});
export const PAGE_ROLES = Object.freeze({
  navigation: "div", "primary-navigation": "nav", "secondary-navigation": "details",
  "secondary-links": "nav", "control-access": "details", "operation-dock": "footer",
  "program-preview": "section"
});

export function validatePage(document) {
  const ids = new Set();
  for (const node of document.querySelectorAll("[id]")) {
    if (ids.has(node.id)) throw new Error(`Duplicate page binding: ${node.id}`);
    ids.add(node.id);
  }
  for (const [tag, names] of Object.entries(PAGE_BINDINGS)) {
    for (const id of names.split(" ")) {
      const node = document.getElementById(id);
      if (!node || node.tagName.toLowerCase() !== tag) throw new Error(`Required page binding: ${tag}#${id}`);
    }
  }
  const layout = document.documentElement.dataset.webInterface;
  if (!["classic", "modern"].includes(layout)) throw new Error("Unknown Web layout");
  if (layout === "modern") {
    for (const [tag, names] of Object.entries({span: "activeWcsDisplay", strong: "spindleRpmDisplay actualFeedDisplay feedOverrideDisplay"})) {
      for (const id of names.split(" ")) {
        const node = document.getElementById(id);
        if (!node || node.tagName.toLowerCase() !== tag) throw new Error(`Required modern binding: ${tag}#${id}`);
      }
    }
  }
  const pages = new Set();
  for (const page of document.querySelectorAll("[data-page]")) {
    if (pages.has(page.dataset.page)) throw new Error(`Duplicate page: ${page.dataset.page}`);
    pages.add(page.dataset.page);
  }
  for (const name of ["control", "program", "preparation", "diagnostics", "events", "mcp", "about"]) {
    if (!pages.has(name)) throw new Error(`Required page: ${name}`);
  }
  for (const [name, tag] of Object.entries(PAGE_ROLES)) {
    const nodes = document.querySelectorAll(`[data-ui="${name}"]`);
    if (nodes.length !== 1 || nodes[0].tagName.toLowerCase() !== tag) throw new Error(`Required page role: ${name}`);
  }
  if (!document.getElementById("programPreviewCanvas").closest("[data-page]")) throw new Error("Preview must belong to a page");
}
