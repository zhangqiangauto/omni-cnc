export const ICON_CATEGORIES = {
  advanced: ["coordinate-system", "kinematics", "machine-coordinate", "rotary-axis", "tcp", "tool-orientation", "transform", "work-offset"],
  axis: ["axis-override", "feedrate", "jog-step", "jog-x-minus", "jog-x-plus", "jog-y-minus", "jog-y-plus", "jog-z-minus", "jog-z-plus", "rapid", "spindle-ccw", "spindle-cw", "spindle"],
  constraints: ["acceleration-limit", "axis-limit", "buffer", "constraint", "hard-limit", "jerk-limit", "jitter", "saturation", "soft-limit", "velocity-limit"],
  diagnostics: ["alarm", "connection", "cpu-load", "info", "latency", "realtime", "state-fault", "state-hold", "state-idle", "state-ready", "state-run", "warning"],
  interpolation: ["arc-segment", "line-segment", "lookahead", "nurbs", "planner", "spline", "time-scaling", "toolpath-2d", "toolpath-3d", "trajectory"],
  program: ["program-buffer", "program-download", "program-open", "program-restart", "program-run-line", "program-save", "program-step", "program-upload"],
  research: ["curve", "envelope", "experiment", "feasible-region", "graph", "optimization", "parameter", "replay"],
  system: ["check-line", "cycle-start", "disable-drives", "enable-drives", "estop", "feed-hold", "mode-auto", "mode-home", "mode-jog", "mode-mdi", "power", "reset", "stop"]
};

export function iconTheme() {
  return document.documentElement.dataset.iconTheme || "omni";
}

export function iconPath(name, category = "") {
  const resolved = category || Object.keys(ICON_CATEGORIES)
    .find((candidate) => ICON_CATEGORIES[candidate].includes(name));
  return resolved ? `/icons/${iconTheme()}/${resolved}/${name}.svg` : "";
}
