import { currentLocale } from "./i18n.js";
export function formatNumber(value, digits = 3) {
  return typeof value === "number" && Number.isFinite(value) ? value.toFixed(digits) : "-";
}

export function formatTimestamp(value) {
  const timestamp = Number(value);
  if (!Number.isFinite(timestamp) || timestamp <= 0) return "-";
  return new Date(timestamp).toLocaleString(currentLocale());
}

export function formatDurationMs(value) {
  const duration = typeof value === "number" ? value : NaN;
  if (!Number.isFinite(duration) || duration < 0) return "-";
  const seconds = Math.floor(duration / 1000);
  const hh = String(Math.floor(seconds / 3600)).padStart(2, "0");
  const mm = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

export function observedBoolean(value) {
  return typeof value === "boolean"
    ? { valid: true, value }
    : { valid: false, value: false };
}

export function formatObservedBoolean(observed, trueText, falseText, unknownText = "UNKNOWN") {
  return observed?.valid ? (observed.value ? trueText : falseText) : unknownText;
}

export function axisDescriptors(system = {}) {
  const semantics = system.axis_semantics || {};
  const map = semantics.map && typeof semantics.map === "object" ? semantics.map : {};
  const coordinateSystems = system.coordinate_systems || {};
  const machine = coordinateSystems.machine_pos || {};
  const work = coordinateSystems.work_pos || {};
  const axes = Array.isArray(semantics.display_axes) ? semantics.display_axes : [];
  return axes.filter((display) => typeof display === "string" && display.trim()).map((display) => {
    const key = String(display).trim().toLowerCase();
    const mappedJoint = map[key];
    return {
      display: String(display).toUpperCase(),
      key,
      joint: Number.isInteger(mappedJoint) && mappedJoint >= 0 ? mappedJoint : null,
      machine: machine[key],
      work: work[key]
    };
  });
}

export function programView(system = {}, binding = {}) {
  const program = system.program || {};
  const timing = program.timing || {};
  const loaded = observedBoolean(system.program_loaded);
  return {
    loaded: loaded.value,
    loadedValid: loaded.valid,
    name: String(program.name || binding.loaded_path || "-"),
    currentLine: program.current_line ?? "-",
    buffer: program.buffer ?? "-",
    estimated: formatDurationMs(timing.estimated_total_ms),
    elapsed: formatDurationMs(timing.elapsed_ms),
    remaining: formatDurationMs(timing.remaining_ms),
    sessionId: String(binding.session_id || ""),
    version: Number(binding.version || 0),
    bindingStatus: String(binding.status || "")
  };
}

export function taskView(system = {}) {
  const task = system.task || {};
  const home = system.home || {};
  const homeRunning = observedBoolean(home.running);
  return {
    task: `${String(task.active ?? "-")} / ${String(task.phase ?? "-")}`,
    home: formatObservedBoolean(homeRunning, "RUNNING", "IDLE"),
    homeRunning
  };
}

export function alarmView(system = {}, alarmMessage = null) {
  const alarm = alarmMessage?.data || {};
  const messages = [];
  for (const candidate of [alarm.text, alarm.msg, alarm.message, alarm.detail]) {
    const text = String(candidate || "").trim();
    if (text && !messages.includes(text)) messages.push(text);
  }
  const summary = system.alarm_summary || system.alarm || {};
  const systemObserved = observedBoolean(
    typeof summary.active === "boolean" ? summary.active : system.alarm_active);
  const eventObserved = observedBoolean(alarm.active);
  const active = eventObserved.valid ? eventObserved : systemObserved;
  const nestedCount = Number(summary.active_count);
  return {
    active: active.value,
    valid: active.valid,
    count: active.valid ? (Number.isFinite(nestedCount) ? nestedCount : (active.value ? 1 : 0)) : null,
    code: String(alarm.code ?? alarm.alarm_code ?? "-"),
    timestamp: alarm.ts_ms ?? alarmMessage?.ts_ms,
    messages
  };
}

export function normalizeProgramSummary(payload) {
  if (payload?.ok === false) return null;
  const data = payload?.data && typeof payload.data === "object" ? payload.data : payload;
  if (!data || typeof data !== "object" || Array.isArray(data)) return null;
  return {
    available: true,
    session_id: String(data.session_id || ""),
    version: Number.isSafeInteger(data.version) && data.version >= 0 ? data.version : 0,
    status: String(data.status || ""),
    loaded_path: String(data.path || ""),
    run_start_permitted: typeof data.run_start_permitted === "boolean" ? data.run_start_permitted : null,
    run_block_reason: typeof data.run_block_reason === "string" ? data.run_block_reason : "",
    // Borrow the decoded Core DTO for presentation. No derived readiness,
    // diagnostic scoring or program parsing is performed in the browser.
    details: data,
    fetched_at_ms: Date.now()
  };
}

export function bindingReady(binding = {}) {
  return Boolean(binding.session_id) &&
    Number.isSafeInteger(binding.version) && binding.version > 0 &&
    binding.available !== false && binding.run_start_permitted === true;
}
