// View-local text only. Core values remain authoritative; editing or discarding
// a draft never writes a machine parameter and is never persisted.
export class InputDraft {
  constructor(text = "") {
    this.text = String(text);
    this.edited = false;
  }

  edit(text) {
    this.text = String(text);
    this.edited = true;
  }

  receive(text) {
    if (!this.edited) this.text = String(text ?? "");
    return this.text;
  }

  discard(text) {
    this.edited = false;
    return this.receive(text);
  }
}
