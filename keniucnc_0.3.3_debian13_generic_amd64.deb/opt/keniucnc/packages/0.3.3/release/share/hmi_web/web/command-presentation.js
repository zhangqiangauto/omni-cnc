import { t } from "./i18n.js";
// Labels and response formatting only. Completion comes from Core's response,
// never from position, elapsed time, RunState or an inferred workflow.
const COMMAND_LABELS = {
  "core.safety.estop": t("急停请求"),
  "core.drives.enable": t("驱动操作"),
  "core.run.reset": t("复位"),
  "core.run.start": t("启动加工"),
  "core.run.hold": t("暂停加工"),
  "core.run.resume": t("继续加工"),
  "core.run.stop": t("停止加工"),
  "core.program.load": t("装载程序"),
  "core.ctrl.mode.set": t("切换模式"),
  "core.motion.mdi": t("MDI 指令"),
  "core.motion.jog.start": t("点动"),
  "core.motion.jog.keepalive": t("点动保持"),
  "core.motion.jog.stop": t("停止点动"),
  "core.motion.jog.zero.start": t("点动回零位"),
  "core.spindle.set": t("主轴操作"),
  "core.override.set": t("倍率设置"),
  "core.rt.channel.config": t("实时通道设置"),
  "core.rtcp.set": t("RTCP 设置")
};

export function commandLabel(command) {
  return Object.hasOwn(COMMAND_LABELS, command) ? COMMAND_LABELS[command] : String(command || t("操作"));
}

export function commandResponseFeedback(command, response) {
  const label = commandLabel(command);
  if (response?.ok === false) {
    return { text: t("{0}被拒绝：{1}", label, response.msg || response.status || t("原因未提供")), level: "bad" };
  }
  const operation = response?.data;
  if (response?.ok === true && operation?.operation_phase === "TERMINAL" &&
      ["COMPLETED", "NO_CHANGE", "REJECTED", "FAILED", "PARTIAL", "CANCELLED", "SUPERSEDED"].includes(operation.operation_outcome)) {
    return { text: operation.operation_message || `${label}：${operation.operation_outcome}`,
      level: ["COMPLETED", "NO_CHANGE"].includes(operation.operation_outcome) ? "ok" : "bad" };
  }
  if (response?.ok === true && response.data?.completion === "ACCEPTED") {
    return { text: t("{0}已受理，等待 Core 确认执行结果。", label), level: "warn" };
  }
  if (response?.ok === true && response.data?.completion === "COMPLETED") {
    return { text: t("{0}已完成。", label), level: "ok" };
  }
  return { text: t("{0}已返回响应，执行结果尚未确认。", label), level: "warn" };
}
