import { t, currentLocale } from "./i18n.js";
import { api } from "./api.js";

// View-local selection and request lifetimes only. Guardian owns all notice
// validity, expiry, unread counts and persistence; content is always plain text.
export function initializeNotifications() {
  const entry = document.getElementById("notificationEntry");
  const panel = document.getElementById("userNotifications");
  const status = document.getElementById("notificationStatus");
  const list = document.getElementById("notificationList");
  const read = document.getElementById("readNotification");
  const readAll = document.getElementById("readAllNotifications");
  let selected = "";
  let rows = [];
  let revision = null;
  let summaryActive = false;
  let listActive = false;
  let writeActive = false;
  let available = false;
  let writeFeedback = "";

  function selection() {
    const notice = rows.find((row) => row.notification_id === selected);
    document.getElementById("notificationTitle").textContent = notice?.title || t("选择通知查看详情");
    document.getElementById("notificationTime").textContent = notice ? `${new Date(notice.published_at_ms).toLocaleString(currentLocale())} ${notice.version || ""}` : "";
    document.getElementById("notificationBody").textContent = notice?.body || "";
    read.disabled = !available || writeActive || !notice || notice.read;
    for (const button of list.querySelectorAll("button")) button.setAttribute("aria-current", String(button.dataset.id === selected));
  }
  async function refresh(summaryOnly) {
    if ((summaryOnly && summaryActive) || (!summaryOnly && listActive)) return;
    if (summaryOnly) summaryActive = true; else listActive = true;
    try {
      const response = await (summaryOnly ? api.notificationSummary() : api.notifications());
      const data = response?.data;
      if (response?.ok !== true || data?.schema !== "keniucnc.notifications.v1" ||
          !Number.isSafeInteger(data.revision) || !Number.isInteger(data.unread_count) || data.unread_count < 0 || data.unread_count > 64 ||
          (!summaryOnly && (!Array.isArray(data.notifications) || data.notifications.length > 64 ||
            data.notifications.some((row) => typeof row?.notification_id !== "string" || typeof row.title !== "string" || typeof row.body !== "string" || typeof row.read !== "boolean")))) {
        throw new Error(t("通知数据格式无效"));
      }
      entry.querySelector("span").textContent = t("通知 {0}", data.unread_count);
      entry.title = t("{0} 条未读通知", data.unread_count);
      if (summaryOnly) {
        if (panel.open && data.revision !== revision) await refresh(false);
        return;
      }
      available = true;
      rows = data.notifications;
      revision = data.revision;
      if (!rows.some((row) => row.notification_id === selected)) selected = rows[0]?.notification_id || "";
      list.replaceChildren();
      for (const row of rows) {
        const button = document.createElement("button");
        button.type = "button";
        button.dataset.id = row.notification_id;
        button.textContent = `${row.read ? "" : "● "}${row.title}`;
        button.addEventListener("click", () => { selected = row.notification_id; selection(); });
        list.append(button);
      }
      status.textContent = writeFeedback || (rows.length ? t("{0} 条通知 · {1} 条未读", rows.length, data.unread_count) : t("暂无通知"));
      readAll.disabled = writeActive || data.unread_count === 0;
      selection();
    } catch (error) {
      available = false;
      revision = null;
      entry.querySelector("span").textContent = t("通知 ?");
      status.textContent = t("通知通道不可用：{0}", error.message);
      read.disabled = true;
      readAll.disabled = true;
    } finally {
      if (summaryOnly) summaryActive = false; else listActive = false;
    }
  }
  async function markRead(id) {
    if (writeActive || !available) return;
    writeActive = true;
    read.disabled = true; readAll.disabled = true;
    try {
      const result = await api.markNotificationRead(id);
      if (result?.ok !== true) throw new Error(result?.status || t("请求失败"));
      writeFeedback = "";
    } catch (error) { writeFeedback = t("标记失败：{0}", error.message); status.textContent = writeFeedback; }
    finally { writeActive = false; await refresh(false); }
  }
  entry.addEventListener("click", () => { if (!panel.open) panel.show(); refresh(false); });
  document.getElementById("closeNotifications").addEventListener("click", () => panel.close());
  document.getElementById("refreshNotifications").addEventListener("click", () => { writeFeedback = ""; refresh(false); });
  read.addEventListener("click", () => markRead(selected));
  readAll.addEventListener("click", () => markRead("*"));
  setInterval(() => { if (!document.hidden) refresh(true); }, 5000);
  window.addEventListener("focus", () => refresh(true));
  refresh(true);
}
