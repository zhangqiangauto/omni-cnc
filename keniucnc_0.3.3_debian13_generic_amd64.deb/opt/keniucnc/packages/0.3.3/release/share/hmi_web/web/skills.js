import { t } from "./i18n.js";
import { api } from "./api.js";

const elements = {};
let catalog = [];
let pending = null;
let coreAvailable = false;
let busy = false;

function result(text, className = "", payload = null) {
  elements.result.className = `result-box ${className}`.trim();
  elements.result.textContent = payload ? `${text}\n${JSON.stringify(payload, null, 2)}` : text;
}

function selectedSkill() {
  return catalog.find((item) => item.skill_id === elements.select.value);
}

function refreshDescription() {
  const skill = selectedSkill();
  elements.description.textContent = skill ? `${skill.mode}: ${skill.description}` : t("无可用技能");
}

export async function initializeSkills() {
  Object.assign(elements, {
    select: document.querySelector("#skillSelect"),
    description: document.querySelector("#skillDescription"),
    input: document.querySelector("#skillInput"),
    planButton: document.querySelector("#skillPlanButton"),
    panel: document.querySelector("#skillPlanPanel"),
    risk: document.querySelector("#skillRisk"),
    status: document.querySelector("#skillStatus"),
    summary: document.querySelector("#skillSummary"),
    view: document.querySelector("#skillPlanView"),
    executePanel: document.querySelector("#skillExecutePanel"),
    confirmation: document.querySelector("#skillConfirmation"),
    executeButton: document.querySelector("#skillExecuteButton"),
    result: document.querySelector("#skillResult")
  });

  elements.select.addEventListener("change", refreshDescription);
  elements.planButton.addEventListener("click", plan);
  elements.executeButton.addEventListener("click", execute);

  try {
    catalog = (await api.listSkills()).skills || [];
    elements.select.innerHTML = catalog.map((skill) =>
      `<option value="${skill.skill_id}">${skill.title}</option>`).join("");
    refreshDescription();
    result(t("MCP 能力目录已加载。"), "ok");
  } catch (error) {
    result(t("MCP 能力目录加载失败：{0}", error.message), "bad", error.payload);
  }
}

export function setSkillsCoreAvailable(available) {
  const changed = coreAvailable !== available;
  coreAvailable = available;
  if (!elements.planButton) return;
  elements.planButton.disabled = !available || busy;
  if (elements.executeButton) {
    elements.executeButton.disabled = !available || busy;
  }
  if (!available && elements.result) {
    result(t("Core 数据链路未就绪，MCP 计划和执行已禁用。"), "bad");
  } else if (changed && elements.result && !pending) {
    result(t("MCP 能力已就绪。"), "ok");
  }
}

async function plan() {
  if (!coreAvailable) return;
  let input;
  try { input = JSON.parse(elements.input.value || "{}"); }
  catch { result(t("Input 必须是有效 JSON。"), "bad"); return; }
  if (!input || Array.isArray(input) || typeof input !== "object") {
    result(t("Input 必须是 JSON object。"), "bad");
    return;
  }
  busy = true;
  elements.planButton.disabled = true;
  pending = null;
  try {
    const session = await api.createSkillSession(elements.select.value, input);
    const response = await api.planSkill(session.session.id);
    pending = {
      sessionId: session.session.id,
      revision: response.plan_revision,
      token: response.confirmation_token || null
    };
    elements.panel.hidden = false;
    elements.risk.textContent = response.plan.risk;
    elements.status.textContent = response.session.status;
    elements.summary.textContent = response.plan.summary;
    elements.view.textContent = JSON.stringify(response.plan, null, 2);
    elements.executePanel.hidden = !pending.token;
    elements.confirmation.value = "";
    result(t("计划已生成。请逐条核对命令和观测状态。"), response.plan.risk === "HIGH" ? "bad" : "ok");
  } catch (error) {
    result(t("计划失败：{0}", error.message), "bad", error.payload);
  } finally {
    busy = false;
    elements.planButton.disabled = !coreAvailable;
    elements.executeButton.disabled = !coreAvailable;
  }
}

async function execute() {
  if (!coreAvailable || !pending?.token) return;
  if (elements.confirmation.value !== "EXECUTE") {
    result(t("必须准确输入 EXECUTE。"), "bad");
    return;
  }
  busy = true;
  elements.executeButton.disabled = true;
  elements.planButton.disabled = true;
  try {
    const response = await api.executeSkill(pending.sessionId, pending.revision, pending.token);
    elements.status.textContent = response.session.status;
    elements.executePanel.hidden = true;
    pending = null;
    result(t("计划执行完成。"), "ok", response.results);
  } catch (error) {
    const guidance = error.status === 409 || error.status === 410 ? t(" 状态已变化，请重新生成计划。") : "";
    result(t("执行失败：{0}.{1}", error.message, guidance), "bad", error.payload);
    pending = null;
    elements.executePanel.hidden = true;
  } finally {
    busy = false;
    elements.executeButton.disabled = !coreAvailable;
    elements.planButton.disabled = !coreAvailable;
  }
}
