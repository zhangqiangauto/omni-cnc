# Web HMI page layouts

The gateway selects `classic` or `modern` from the active platform's
`ui.web_interface` once before starting HTTP workers. Configure it in Setup
Wizard → Controller → Interface and Display → Appearance → Web interface,
then review and apply. The existing Guardian/setup lifecycle restarts the
runtime stack. Changing browser storage or URL parameters does not select the
root page. This platform-level choice applies to every client of that gateway.

- Classic: `index.html` + `app.css`.
- Modern: `modern/index.html` + shared `app.css` + `modern/app.css`.
- Both load exactly the same `/web/app.js` and shared JavaScript modules.
- Missing field on older deployments means Classic. Wrong type or an unknown
  value rejects configuration. Missing selected entry/style assets reject
  gateway startup; the gateway never silently serves another layout.
- HTML/JS/CSS are served with `Cache-Control: no-store` so a stack update and
  page reload cannot retain an obsolete shell/module mix in the browser cache.

## Presentation contract

`page-contract.js` lists the stable IDs/native element types and semantic
`data-ui` roles required by the single application. The complete shell is
validated before sessions, event handlers, timers, or subscriptions start.
Missing/duplicate bindings produce a visible initialization error; initial
machine controls remain disabled. Never add hidden dummy controls to satisfy
this contract. Update both layouts whenever a common functional control is added.
Normal inactive pages and collapsed sections remain reachable through navigation.

`data-ui` marks layout-independent behavior (navigation, control access, dock
and preview). `data-control-reasons` identifies groups whose disabled button
explanations should be rendered. CSS classes own appearance. Renderers toggle
only their status classes and do not overwrite independently supplied styles.

Each shell has one preview instance. Its canvas belongs to a `[data-page]`
container: Classic uses the program page, Modern the control page. The shared
preview controller uses that host's route for loading, cancellation and redraw;
wire validation, capacity limits, program/frame identity and geometry decoding
are unchanged. Preview success never grants permission to execute a program.

Both layouts retain all seven pages, native input semantics, explicit control
intents and Core/Guardian contracts. Modern restyles the shell and control page;
secondary pages retain existing controls. The Modern layout follows the approved
 dark composition: context above navigation, work-coordinate-first DRO, preview,
 explicit readiness row and message strip. Additional controls are reachable
 through disclosures. Actual spindle/feed and active WCS slots render published
 values only and remain unknown when transport state is unavailable. Preview
 colors are CSS presentation tokens shared with the existing canvas renderer. No machine readiness, permission,
workflow, G-code interpretation or domain computation is owned by a layout.

## Verification

- `page_contract_runner.mjs`: real source HTML bindings/native types, input and
  command parity, and rejection of missing/duplicate/wrong-type bindings.
- Existing operation/preview tests run on the shared modules; preview tests also
  run with `--control-page` to exercise the Modern host route.
- `web_interface_selection.py`: starts only the real gateway in a temporary
  configuration root, checks defaults, both layouts, immutable selection and
  invalid/missing-resource rejection. Never starts Core or commands a machine.
- `web_layout_browser.js`: Playwright CLI `run-code --filename` scenario using
  intercepted service/WebSocket fixtures. Serve the repository locally with
  `/web/` mapped to this directory; open a page at that origin before running.
  It checks both real HTML shells, five axes, binary preview worker, single
  command submission, pointer-release jog stop, offline admission and responsive
  widths. It writes review screenshots under `output/playwright/`.

Browser fixtures verify client wiring, not real-machine safety or execution.
