export class CommandUncertainError extends Error {
  constructor(requestId, cause = null) {
    super(`Command outcome is uncertain (request_id=${requestId})`);
    this.name = "CommandUncertainError";
    this.requestId = requestId;
    this.state = "UNCERTAIN";
    this.cause = cause;
    this.payload = { ok: false, status: this.state, request_id: requestId };
  }
}

export function makeRequestId() {
  if (globalThis.crypto?.randomUUID) return `web-${globalThis.crypto.randomUUID()}`;
  const random = Array.from({ length: 4 }, () =>
    Math.floor(Math.random() * 0x1_0000_0000).toString(16).padStart(8, "0")).join("");
  return `web-${Date.now().toString(36)}-${random}`;
}

export function commandEnvelope(cmd, args = {}, requestId = makeRequestId(), nowMs = Date.now()) {
  if (!requestId || typeof requestId !== "string") throw new TypeError("requestId must be a string");
  if (!args || Array.isArray(args) || typeof args !== "object") throw new TypeError("args must be an object");
  return { ver: 1, id: requestId, ts_ms: nowMs, cmd, args };
}

function retryable(error) {
  return !Number.isInteger(error?.status) || [502, 503, 504].includes(error.status);
}

export async function executeReliableCommand({
  envelope,
  send,
  lookup,
  sendAttempts = 2,
  lookupAttempts = 3,
  wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
}) {
  let lastError = null;
  let submissionUncertain = false;
  for (let attempt = 0; attempt < sendAttempts; ++attempt) {
    try {
      const result = await send(envelope);
      if (result?.status === "IN_FLIGHT") break;
      return result;
    } catch (error) {
      lastError = error;
      if (!retryable(error)) {
        if (!submissionUncertain) throw error;
        break; // A fenced retry does not prove that the earlier request failed.
      }
      submissionUncertain = true;
      if (attempt + 1 < sendAttempts) await wait(150 * (attempt + 1));
    }
  }

  for (let attempt = 0; attempt < lookupAttempts; ++attempt) {
    try {
      const result = await lookup(envelope.id);
      if (result?.status === "COMPLETED") return result;
      if (result?.status === "IN_FLIGHT") {
        await wait(200 * (attempt + 1));
        continue;
      }
    } catch (error) {
      lastError = error;
      if (!retryable(error) && error?.status !== 404) break;
    }
    if (attempt + 1 < lookupAttempts) await wait(200 * (attempt + 1));
  }
  throw new CommandUncertainError(envelope.id, lastError);
}
