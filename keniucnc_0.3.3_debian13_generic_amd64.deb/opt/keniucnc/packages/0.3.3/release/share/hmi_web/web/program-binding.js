import { api } from "./api.js";
import { normalizeProgramSummary } from "./selectors.js";

let nextAttemptAtMs = 0;
let retryDelayMs = 2000;

export async function refreshProgramBinding(store) {
  const now = Date.now();
  if (!store.snapshot.httpReady || now < nextAttemptAtMs) return false;
  try {
    const summary = normalizeProgramSummary(await api.programSummary());
    if (!summary) throw new Error("INVALID_PROGRAM_SUMMARY");
    store.setProgramBinding(summary);
    retryDelayMs = 2000;
    nextAttemptAtMs = now + retryDelayMs;
    return true;
  } catch {
    // Retain identity for read-only display, but never reuse an unavailable
    // summary as command authority. A later successful query replaces it.
    store.setProgramBinding({ available: false, run_start_permitted: null });
    nextAttemptAtMs = now + retryDelayMs;
    retryDelayMs = Math.min(retryDelayMs * 2, 30000);
    return false;
  }
}
