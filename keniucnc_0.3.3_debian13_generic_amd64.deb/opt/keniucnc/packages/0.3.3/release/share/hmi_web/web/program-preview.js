import { t } from "./i18n.js";
import { api } from "./api.js";
import { ProgramPreviewViewport } from "./program-preview-viewport.js";

// All retained state is view-local: selected published chunk, viewport, and
// decoded read-only geometry. No G-code parsing or machine admission lives here.
export function initializeProgramPreview(store) {
  const element = (id) => document.getElementById(id);
  const canvas = element("programPreviewCanvas");
  const context = canvas.getContext("2d");
  const page = canvas.closest("[data-page]");
  const showing = (state) => state.activePage === page.dataset.page;
  let summary = null;
  let identity = "";
  let selected = 0;
  let chunk = null;
  let pending = null;
  const viewport = new ProgramPreviewViewport();
  let requestSerial = 0;
  let lastDetails = null;
  let lastAvailable = false;
  let lastPage = "";
  let animation = 0;
  let rowPage = 0;
  const manifest = () => Array.isArray(summary?.preview_chunk_manifest) ? summary.preview_chunk_manifest : [];
  const descriptor = () => manifest()[selected];
  const message = (value) => { element("programPreviewMessage").textContent = value; };
  const eligibleDescriptor = (value) => value && value.ready === true &&
    ["chunk_id", "start", "count", "version", "content_crc32"].every((key) => Number.isSafeInteger(value[key])) &&
    value.chunk_id >= 0 && value.start >= 0 && value.count > 0 && value.count <= 4000 &&
    value.version === summary?.version && value.content_crc32 >= 0 && value.content_crc32 <= 0xffffffff;
  const controls = () => {
    const entries = manifest();
    const current = descriptor();
    const paging = entries.length > 1 && chunk?.full !== true;
    element("programPreviewPaging").hidden = !paging && pending === null;
    element("programPreviewPrevious").hidden = !paging;
    element("programPreviewNext").hidden = !paging;
    element("programPreviewChunkLabel").hidden = !paging;
    element("programPreviewCancel").hidden = pending === null;
    element("programPreviewPrevious").disabled = selected <= 0 || pending !== null;
    element("programPreviewNext").disabled = selected >= entries.length - 1 || pending !== null;
    element("programPreviewCancel").disabled = pending === null;
    element("programPreviewChunkLabel").textContent = current
      ? t("分块 {0} / {1} · ID {2} · 起始段 {3} · {4} 段 · {5}", selected + 1, entries.length, current.chunk_id, current.start, current.count, current.ready === true ? t("Core 已发布") : t("尚未就绪"))
      : t("Core 未提供预览分块");
    element("programPreviewIdentity").textContent = summary
      ? t("版本 {0} · {1}{2}", summary.version, summary.frame ?? t("坐标系未知"), summary.coordinate_rebuilding === true ? t(" · 正在更新程序坐标") : summary.frame_context_stale === true ? t(" · 坐标上下文已过期") : "")
      : t("没有可用程序摘要");
  };
  const draw = () => {
    cancelAnimationFrame(animation);
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (!width || !height || !context) return;
    const ratio = window.devicePixelRatio || 1;
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    context.clearRect(0, 0, width, height);
    if (!chunk) return;
    message(t("正在绘制…"));
    const project = viewport.fit(chunk.viewportExtents, width, height, element("programPreviewPlane").value);
    context.lineWidth = 1.5;
    const styles = getComputedStyle(canvas);
    const colors = ["--preview-rapid", "--preview-feed", "--preview-transition"].map((name) => styles.getPropertyValue(name).trim());
    const projection = chunk;
    function* strokes() {
      for (const primitive of projection.primitives) {
        context.strokeStyle = primitive.kind === 0 ? colors[0] : primitive.segment_kind === 1 ? colors[2] : colors[1];
        context.setLineDash(primitive.kind === 0 ? [5, 4] : []);
        context.beginPath();
        if (primitive.kind < 2) {
          context.moveTo(...project(...primitive.start));
          context.lineTo(...project(...primitive.target));
          context.stroke();
          yield 2;
        } else {
          for (let point = 0; point < primitive.polyline_count; ++point) {
            const index = (primitive.polyline_offset + point) * 3;
            const [x, y] = project(projection.points[index], projection.points[index + 1], projection.points[index + 2]);
            if (point === 0) context.moveTo(x, y); else context.lineTo(x, y);
            if (point > 0 && point % 2048 === 0) {
              context.stroke();
              yield 2048;
              context.beginPath();
              context.moveTo(x, y);
            }
          }
          context.stroke();
          yield primitive.polyline_count % 2048;
        }
      }
      context.setLineDash([]);
    }
    const drawing = strokes();
    const frame = () => {
      let vertices = 0;
      for (let paths = 0; paths < 256 && vertices < 4096; ++paths) {
        const step = drawing.next();
        if (step.done) {
          message(projection.full ? t("完整刀路") : t("分块预览 {0} / {1}，当前显示部分刀路", selected + 1, manifest().length));
          return;
        }
        vertices += step.value;
      }
      animation = requestAnimationFrame(frame);
    };
    animation = requestAnimationFrame(frame);
  };
  const clear = () => {
    ++requestSerial;
    pending?.abort();
    pending = null;
    chunk = null;
    viewport.reset();
    rowPage = 0;
    element("programPreviewRows").replaceChildren();
    element("programPreviewRowsPrevious").disabled = true;
    element("programPreviewRowsNext").disabled = true;
    element("programPreviewRowsLabel").textContent = t("未读取轨迹段");
    draw();
  };
  const rows = (projection) => {
    const fragment = document.createDocumentFragment();
    const start = rowPage * 100;
    const end = Math.min(start + 100, projection.primitives.length);
    for (let index = start; index < end; ++index) {
      const primitive = projection.primitives[index];
      const row = document.createElement("tr");
      row.dataset.segmentId = String(primitive.segment_id ?? projection.descriptor.start + index);
      for (const value of [primitive.segment_id ?? projection.descriptor.start + index,
        primitive.file_line >= 0 ? primitive.file_line : t("未知"), primitive.program_line >= 0 ? primitive.program_line : t("未知"),
        [t("快速直线"), t("进给直线"), t("顺时针圆弧折线"), t("逆时针圆弧折线")][primitive.kind], primitive.feed]) {
        const cell = document.createElement("td"); cell.textContent = value; row.appendChild(cell);
      }
      fragment.appendChild(row);
    }
    element("programPreviewRows").replaceChildren(fragment);
    element("programPreviewRowsLabel").textContent = t("{0}–{1} / {2} 段", start + 1, end, projection.primitives.length);
    element("programPreviewRowsPrevious").disabled = rowPage === 0;
    element("programPreviewRowsNext").disabled = end === projection.primitives.length;
  };
  element("programPreviewRowsPrevious").addEventListener("click", () => { if (chunk && rowPage > 0) { --rowPage; rows(chunk); } });
  element("programPreviewRowsNext").addEventListener("click", () => { if (chunk && (rowPage + 1) * 100 < chunk.primitives.length) { ++rowPage; rows(chunk); } });
  const loadAll = async () => {
    if (summary?.publication_finalized !== true || summary?.preview_ready !== true || !manifest().length || !manifest().every(eligibleDescriptor)) return;
    const descriptors = manifest();
    if (descriptors.reduce((count,item) => count + item.count,0) > 64000) { message(t("完整预览超过当前视图 64000 段容量，请逐分块检查；不会省略轨迹。")); return; }
    clear();
    const serial = requestSerial;
    const controller = new AbortController(); pending = controller; controls();
    const timer = setTimeout(() => controller.abort(),120000);
    const session = summary.session_id, projections = [];
    let pointValues = 0;
    try {
      for (const entry of descriptors) {
        message(t("正在读取完整预览：{0} / {1} 分块", projections.length + 1, descriptors.length));
        const projection = await api.programPreview(session,entry,controller.signal);
        if (serial !== requestSerial) return;
        if (controller.signal.aborted) throw new DOMException(t("预览请求已取消或超时"), "AbortError");
        pointValues += projection.points.length;
        if (pointValues > 3 * 1024 * 1024) throw new Error(t("完整预览超过 1048576 顶点容量，请逐分块检查；不会省略轨迹"));
        projections.push(projection);
      }
      const points = new Float32Array(pointValues), primitives = [];
      const extents = [[Infinity,-Infinity],[Infinity,-Infinity],[Infinity,-Infinity]];
      let offset = 0;
      for (const projection of projections) {
        points.set(projection.points,offset);
        for (let index = 0; index < projection.primitives.length; ++index) {
          const primitive = projection.primitives[index];
          primitives.push({ ...primitive, polyline_offset:primitive.polyline_offset + offset / 3, segment_id:projection.descriptor.start + index });
        }
        for (let axis=0;axis<3;++axis) { extents[axis][0]=Math.min(extents[axis][0],projection.viewportExtents[axis][0]); extents[axis][1]=Math.max(extents[axis][1],projection.viewportExtents[axis][1]); }
        offset += projection.points.length;
        // Assembly is transport work, not painting. It must keep observing
        // timeout/cancellation even when a hidden tab suspends animation frames.
        await new Promise((resolve) => setTimeout(resolve,0));
        if (serial !== requestSerial) return;
        if (controller.signal.aborted) throw new DOMException(t("预览请求已取消或超时"), "AbortError");
      }
      chunk = { primitives,points,viewportExtents:extents,descriptor:projections[0].descriptor,full:true };
      rows(chunk); controls(); draw();
    } catch (error) { if (serial === requestSerial) message(t("预览读取失败：{0}", error.message)); }
    finally { clearTimeout(timer); if (serial === requestSerial) { pending=null;controls(); } }
  };
  const loadSelected = async () => {
    const entry = descriptor();
    if (!eligibleDescriptor(entry)) return;
    clear();
    const serial = requestSerial;
    const controller = new AbortController();
    pending = controller;
    const timer = setTimeout(() => controller.abort(), 15000);
    controls();
    message(t("正在读取 Core 预览分块…"));
    try {
      const projection = await api.programPreview(summary.session_id, entry, controller.signal);
      if (serial !== requestSerial) return;
      if (controller.signal.aborted) throw new DOMException(t("预览请求已取消或超时"), "AbortError");
      chunk = projection;
      rows(projection);
      draw();
    } catch (error) {
      if (serial === requestSerial) message(t("预览读取失败：{0}", error.name === "AbortError" ? t("请求已取消或超时") : error.message));
    } finally {
      clearTimeout(timer);
      if (serial === requestSerial) { pending = null; controls(); }
    }
  };
  const select = (direction) => {
    const next = selected + direction;
    if (next < 0 || next >= manifest().length) return;
    clear(); selected = next; controls(); loadSelected();
  };
  element("programPreviewCancel").addEventListener("click", () => {
    clear(); controls(); message(t("预览读取已取消"));
  });
  element("programPreviewPrevious").addEventListener("click", () => select(-1));
  element("programPreviewNext").addEventListener("click", () => select(1));
  element("programPreviewPlane").addEventListener("change", draw);
  element("programPreviewZoomIn").addEventListener("click", () => { viewport.magnify(1.5); draw(); });
  element("programPreviewZoomOut").addEventListener("click", () => { viewport.magnify(1 / 1.5); draw(); });
  element("programPreviewFit").addEventListener("click", () => { viewport.reset(); draw(); });
  let drag = null;
  canvas.addEventListener("pointerdown", (event) => {
    if (element("programPreviewPlane").value !== "3D" || !event.isPrimary || event.button !== 0) return;
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener("pointermove", (event) => {
    if (!drag || drag.id !== event.pointerId) return;
    viewport.rotate((event.clientX - drag.x) * .01, (event.clientY - drag.y) * .01);
    drag.x = event.clientX; drag.y = event.clientY; draw();
  });
  for (const type of ["pointerup", "pointercancel", "lostpointercapture"]) canvas.addEventListener(type, () => { drag = null; });
  canvas.addEventListener("wheel", (event) => {
    event.preventDefault(); viewport.magnify(event.deltaY < 0 ? 1.15 : 1 / 1.15); draw();
  }, { passive: false });
  canvas.addEventListener("keydown", (event) => {
    const turns = { ArrowLeft: [-.1, 0], ArrowRight: [.1, 0], ArrowUp: [0, -.1], ArrowDown: [0, .1] };
    if (turns[event.key] && element("programPreviewPlane").value === "3D") viewport.rotate(...turns[event.key]);
    else if (event.key === "Home") viewport.reset();
    else if (event.key === "+" || event.key === "=") viewport.magnify(1.5);
    else if (event.key === "-") viewport.magnify(1 / 1.5);
    else return;
    event.preventDefault(); draw();
  });
  new ResizeObserver(draw).observe(canvas);
  const update = (state) => {
    const available = state.programBinding.available === true && state.httpReady === true && state.coreLinkHealthy === true;
    const details = state.programBinding.details;
    if (details === lastDetails && available === lastAvailable && lastPage === state.activePage) return;
    const entering = showing(state) && lastPage !== page.dataset.page;
    lastDetails = details; lastAvailable = available; lastPage = state.activePage;
    const nextSummary = available ? details : null;
    const nextIdentity = nextSummary ? JSON.stringify([nextSummary.session_id, nextSummary.version,
      nextSummary.frame_context_id, nextSummary.frame_revision, nextSummary.frame_context_stale, nextSummary.coordinate_rebuilding, nextSummary.publication_revision]) : "";
    const oldEntry = descriptor();
    const nextEntry = nextSummary?.preview_chunk_manifest?.[selected];
    const changedChunk = ["chunk_id", "start", "count", "version", "content_crc32", "ready"].some((key) => oldEntry?.[key] !== nextEntry?.[key]);
    const changedProgram = nextIdentity !== identity;
    if (changedProgram || changedChunk || !showing(state)) {
      clear();
      if (changedProgram) selected = 0;
      message(t("等待已发布的刀路…"));
    }
    identity = nextIdentity; summary = nextSummary;
    const position = summary?.execution_position;
    element("programExecutionPosition").textContent = position?.valid === true
      ? t("Core 当前执行行 {0} · 轨迹段 {1} · 会话 {2} / {3}", position.line, position.segment_id, summary.session_id, summary.version)
      : "";
    element("programPreviewRows").querySelectorAll("tr").forEach((row) => {
      row.classList.toggle("current-execution-row", position?.valid === true && row.dataset.segmentId === String(position.segment_id));
    });
    if (selected >= manifest().length) selected = 0;
    controls();
    if (showing(state) && !pending && !chunk && eligibleDescriptor(descriptor()) &&
        (entering || changedProgram || changedChunk)) {
      const complete = summary?.publication_finalized === true && summary?.preview_ready === true &&
        manifest().length > 0 && manifest().every(eligibleDescriptor) && manifest().reduce((count, entry) => count + entry.count, 0) <= 64000;
      if (complete) loadAll(); else loadSelected();
    }
    if (entering) draw();
  };
  store.subscribe(update);
  update(store.snapshot);
}
