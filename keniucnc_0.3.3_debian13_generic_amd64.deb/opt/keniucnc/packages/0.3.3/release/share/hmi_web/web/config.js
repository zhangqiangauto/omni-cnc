const protocol = location.protocol === "https:" ? "wss" : "ws";

export const HTTP_BASE = location.origin;
export const WS_URL = `${protocol}://${location.host}/ws`;
export const TOPICS = [
  "gateway.link",
  "state.system",
  "state.io",
  "telemetry.axis",
  "telemetry.tcp_pose",
  "diag.planner",
  "diag.io_profile",
  "diag.rt_channel",
  "diag.perf",
  "event.alarm",
  "event.safety",
  "event.cmd_result",
  "event.operation",
  "event.lifecycle",
  "event.interp"
];
