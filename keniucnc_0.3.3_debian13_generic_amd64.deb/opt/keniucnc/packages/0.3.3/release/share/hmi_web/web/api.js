import { t } from "./i18n.js";
import { HTTP_BASE } from "./config.js";
import { projectionMediaType, projectionMaxBytes } from "./program-projection.js";
import { commandEnvelope, executeReliableCommand } from "./command-client.js";
import {
  readPendingCommands,
  recoveryDisposition,
  removePendingCommand,
  savePendingCommand
} from "./command-journal.js";

// Per-page transport credentials only. Never persisted or broadcast; a new tab
// must authenticate independently and cannot inherit another tab's lease.
let controlCredentials = { token: "", lease: "", epoch: "" };
function controlHeaders() {
  const headers = {};
  if (controlCredentials.token) headers.authorization = `Bearer ${controlCredentials.token}`;
  if (controlCredentials.lease) {
    headers["X-Keniu-Control-Lease"] = controlCredentials.lease;
    headers["X-Keniu-Control-Epoch"] = controlCredentials.epoch;
  }
  return headers;
}

export class ApiError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.status = status;
    this.payload = payload;
  }
}

async function request(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? 3000);
  try {
    const { timeoutMs: _timeoutMs, acceptedStatuses = [], ...fetchOptions } = options;
    const response = await fetch(`${HTTP_BASE}${path}`, {
      ...fetchOptions,
      headers: { "content-type": "application/json", ...(options.headers || {}) },
      signal: controller.signal
    });
    const text = await response.text();
    let payload = null;
    try { payload = text ? JSON.parse(text) : null; } catch { payload = text; }
    if (!response.ok && !acceptedStatuses.includes(response.status)) {
      throw new ApiError(payload?.msg || payload?.error || `HTTP_${response.status}`, response.status, payload);
    }
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

export const api = {
  notificationSummary: () => request("/api/notifications/summary", { cache: "no-store" }),
  notifications: () => request("/api/notifications", { cache: "no-store" }),
  markNotificationRead: (id) => request("/api/notifications/read", { method: "POST", body: JSON.stringify({ notification_id: id }) }),
  controlStatus: () => request("/api/control", { method: "GET", headers: controlHeaders(), cache: "no-store", timeoutMs: 1500 }),
  openControlSession: async (label) => {
    const result = await request("/api/control/session", { method: "POST", body: JSON.stringify({ label, scope: "web" }) });
    if (result?.ok !== true || !/^[a-f0-9]{64}$/.test(result.data?.session_token || "")) throw new Error("INVALID_CONTROL_SESSION");
    controlCredentials = { token: result.data.session_token, lease: "", epoch: "" };
    return result;
  },
  acquireControl: async () => {
    const token = controlCredentials.token;
    const result = await request("/api/control/acquire", { method: "POST", headers: controlHeaders(), body: "{}" });
    if (result?.ok !== true || !/^[a-f0-9]{64}$/.test(result.data?.lease || "") || !/^[0-9]+$/.test(result.data?.epoch || "")) throw new Error("INVALID_CONTROL_LEASE");
    if (controlCredentials.token === token) controlCredentials = { token, lease: result.data.lease, epoch: String(result.data.epoch) };
    return result;
  },
  renewControl: async () => {
    if (!controlCredentials.lease) return null;
    const identity = controlCredentials;
    try {
      return await request("/api/control/renew", { method: "POST", headers: controlHeaders(), body: "{}", timeoutMs: 1200 });
    } catch (error) {
      if ([401, 409].includes(error.status) && controlCredentials === identity) controlCredentials = { token: identity.token, lease: "", epoch: "" };
      throw error;
    }
  },
  releaseControl: () => {
    const headers = controlHeaders();
    controlCredentials = { token: controlCredentials.token, lease: "", epoch: "" };
    return request("/api/control/release", { method: "POST", headers, body: "{}" });
  },
  closeControlSession: async () => {
    const headers = controlHeaders();
    controlCredentials = { token: "", lease: "", epoch: "" };
    return request("/api/control/session/close", { method: "POST", headers, body: "{}" });
  },
  live: () => request("/api/live", { method: "GET", timeoutMs: 900 }),
  health: () => request("/api/health", { method: "GET", timeoutMs: 900 }),
  stateSnapshot: () => request("/api/state", { method: "GET", timeoutMs: 2500 }),
  eventsAfter: (sequence, limit = 256) => request(`/api/events?after_sequence=${encodeURIComponent(sequence)}&limit=${encodeURIComponent(limit)}`, {
    method: "GET", timeoutMs: 2500, acceptedStatuses: [410]
  }),
  eventsBefore: (sequence = 0, limit = 200) => request(`/api/events/history?before_sequence=${encodeURIComponent(sequence)}&limit=${encodeURIComponent(limit)}`, {
    method: "GET", timeoutMs: 2500
  }),
  operation: (id) => request(`/api/operations/${encodeURIComponent(id)}`, { method: "GET", timeoutMs: 2500 }),
  programSummary: () => request("/api/program/summary", { method: "GET", timeoutMs: 1200 }),
  programFiles: () => request("/api/program/files", { method: "GET", cache: "no-store" }),
  preparation: () => request("/api/preparation", { method: "GET", cache: "no-store" }),
  tooling: () => request("/api/tools/config", { method: "GET", cache: "no-store" }),
  maintainTool: (body) => request("/api/tools/maintenance", { method: "POST", headers: controlHeaders(), body: JSON.stringify(body) }),
  updateTools: (revision, config) => request("/api/tools/config", { method: "PUT", headers: controlHeaders(), body: JSON.stringify({ revision, config }) }),
  toolingPreflight: (context) => request("/api/tools/preflight/check", { method: "POST", headers: controlHeaders(), body: JSON.stringify(context) }),
  programSource: (id, first = 1) => request(`/api/program/files/source?id=${encodeURIComponent(id)}&first=${first}`, { method: "GET", cache: "no-store", timeoutMs: 7000 }),
  uploadProgram: (file) => request("/api/program/files", { method: "POST", headers: { ...controlHeaders(), "content-type": "application/octet-stream", "X-Keniu-Program-Name": file.name }, body: file, timeoutMs: 30000 }),
  programPreview: async (session, descriptor, signal) => {
    const query = new URLSearchParams({ session_id: session, version: String(descriptor.version),
      chunk_id: String(descriptor.chunk_id), kind: "preview" });
    const response = await fetch(`${HTTP_BASE}/api/program/chunk?${query}`, { signal, cache: "no-store" });
    if (response.status !== 200) {
      const payload = await response.json().catch(() => null);
      throw new ApiError(payload?.msg || `HTTP_${response.status}`, response.status, payload);
    }
    if (response.headers.get("content-type")?.split(";")[0] !== projectionMediaType) throw new Error("INVALID_PREVIEW_CONTENT_TYPE");
    // Stream into bounded transport storage; reject before retaining an
    // oversized response even when Content-Length is absent or incorrect.
    const reader = response.body.getReader();
    const bytes = new Uint8Array(projectionMaxBytes);
    let size = 0;
    try {
      while (true) {
        const part = await reader.read();
        if (part.done) break;
        if (size + part.value.byteLength > projectionMaxBytes) throw new Error("PREVIEW_RESPONSE_TOO_LARGE");
        bytes.set(part.value, size);
        size += part.value.byteLength;
      }
    } finally { await reader.cancel(); }
    const buffer = bytes.buffer.slice(0, size);
    return new Promise((resolve, reject) => {
      const worker = new Worker(new URL("./program-projection-worker.js", import.meta.url), { type: "module" });
      const finish = (error, projection) => {
        signal?.removeEventListener("abort", abort);
        worker.terminate();
        if (error) reject(error); else resolve(projection);
      };
      const abort = () => finish(new DOMException(t("预览请求已取消"), "AbortError"));
      if (signal?.aborted) { abort(); return; }
      signal?.addEventListener("abort", abort, { once: true });
      worker.onmessage = ({ data }) => data.ok === true ? finish(null, data.projection) : finish(new Error(data.reason));
      worker.onerror = () => finish(new Error("PREVIEW_DECODER_WORKER_FAILED"));
      worker.postMessage({ buffer, descriptor }, [buffer]);
    });
  },
  command: (cmd, args = {}, options = {}) => {
    const envelope = commandEnvelope(cmd, args, options.requestId);
    // Every retry retains the original identity, even if another lease is
    // acquired while the response is in flight. Credentials are not journaled.
    const headers = controlHeaders();
    savePendingCommand(envelope);
    return executeReliableCommand({
      envelope,
      send: (stableEnvelope) => request("/api/cmd", {
        method: "POST",
        body: JSON.stringify(stableEnvelope),
        headers,
        timeoutMs: options.timeoutMs ?? 7000
      }),
      lookup: (requestId) => request(`/api/cmd/${encodeURIComponent(requestId)}`, {
        method: "GET",
        timeoutMs: 1500,
        acceptedStatuses: [202, 404]
      })
    }).then((result) => {
      removePendingCommand(envelope.id);
      return result;
    }).catch((error) => {
      if (error?.state !== "UNCERTAIN") removePendingCommand(envelope.id);
      throw error;
    });
  },
  recoverPendingCommands: async (onUpdate = () => {}) => {
    const results = [];
    for (const record of readPendingCommands()) {
      const disposition = recoveryDisposition(record);
      if (!disposition.recoverable) {
        const result = { id: record.envelope.id, cmd: record.envelope.cmd, status: "UNRESOLVED", reason: disposition.reason };
        results.push(result);
        onUpdate(result);
        continue;
      }
      try {
        let result = await request(`/api/cmd/${encodeURIComponent(record.envelope.id)}`, {
          method: "GET", timeoutMs: 1500, acceptedStatuses: [202, 404]
        });
        for (let attempt = 0; result?.status === "IN_FLIGHT" && attempt < 3; ++attempt) {
          await new Promise((resolve) => setTimeout(resolve, 250 * (attempt + 1)));
          result = await request(`/api/cmd/${encodeURIComponent(record.envelope.id)}`, {
            method: "GET", timeoutMs: 1500, acceptedStatuses: [202, 404]
          });
        }
        if (result?.status !== "COMPLETED") {
          throw new Error(result?.status === "NOT_FOUND"
            ? "COMMAND_NOT_FOUND_AFTER_RELOAD"
            : `COMMAND_${result?.status || "UNKNOWN"}`);
        }
        removePendingCommand(record.envelope.id);
        const recovered = { id: record.envelope.id, cmd: record.envelope.cmd, status: "RECOVERED", result };
        results.push(recovered);
        onUpdate(recovered);
      } catch (error) {
        const unresolved = { id: record.envelope.id, cmd: record.envelope.cmd, status: "UNRESOLVED", reason: error.message };
        results.push(unresolved);
        onUpdate(unresolved);
      }
    }
    return results;
  },
  listSkills: () => request("/api/skills", { method: "GET" }),
  createSkillSession: (skillId, input) => request("/api/skills/sessions", {
    method: "POST",
    body: JSON.stringify({ skill_id: skillId, input })
  }),
  planSkill: (sessionId) => request(`/api/skills/sessions/${encodeURIComponent(sessionId)}/plan`, {
    method: "POST",
    body: "{}"
  }),
  executeSkill: (sessionId, planRevision, confirmationToken) =>
    request(`/api/skills/sessions/${encodeURIComponent(sessionId)}/execute`, {
      method: "POST",
      body: JSON.stringify({
        plan_revision: planRevision,
        confirmation_token: confirmationToken
      }),
      headers: controlHeaders(),
      timeoutMs: 12000
    })
};
