// View-local orthographic camera. Coordinates are used only for pixels;
// no transformed point is submitted to Core or used as a machine fact.
export class ProgramPreviewViewport {
  constructor() { this.reset(); }
  reset() { this.zoom = 1; this.yaw = -Math.PI / 4; this.pitch = Math.PI / 5; }
  rotate(dx, dy) { this.yaw += dx; this.pitch = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, this.pitch + dy)); }
  magnify(factor) { this.zoom = Math.max(.125, Math.min(32, this.zoom * factor)); }
  fit(extents, width, height, mode) {
    const center = extents.map(([low, high]) => low + (high - low) / 2);
    const cy = Math.cos(this.yaw), sy = Math.sin(this.yaw), cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    const rotate = (x, y, z) => {
      if (mode === "XY") return [x, y];
      if (mode === "XZ") return [x, z];
      if (mode === "YZ") return [y, z];
      return [cy * x - sy * y, cp * z - sp * (sy * x + cy * y)];
    };
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (let corner = 0; corner < 8; ++corner) {
      const [x, y] = rotate(...extents.map((range, axis) => range[(corner >> axis) & 1] - center[axis]));
      minX = Math.min(minX, x); maxX = Math.max(maxX, x);
      minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
    const scale = Math.min(Math.max(1, width - 40) / (maxX - minX || 1), Math.max(1, height - 40) / (maxY - minY || 1)) * this.zoom;
    return (x, y, z) => {
      const pixel = rotate(x - center[0], y - center[1], z - center[2]);
      return [width / 2 + (pixel[0] - (minX + maxX) / 2) * scale,
        height / 2 - (pixel[1] - (minY + maxY) / 2) * scale];
    };
  }
}
