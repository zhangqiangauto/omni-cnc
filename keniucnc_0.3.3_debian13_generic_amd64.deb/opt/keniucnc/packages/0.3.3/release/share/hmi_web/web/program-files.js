import { t } from "./i18n.js";
import { api } from "./api.js";

export function initializeProgramFiles(store) {
  const el = (id) => document.getElementById(id);
  let catalog = null, source = null, selection = "", first = 1, serial = 0;
  let catalogBusy = false, sourceBusy = false, uploading = false;
  const visible = () => store.snapshot.activePage === "program" && store.snapshot.httpReady && store.snapshot.coreLinkHealthy;
  const say = (text) => { el("programFilesMessage").textContent = text; };
  const permission = () => {
    const state = store.snapshot;
    el("programUploadButton").disabled = uploading || !state.httpReady || !state.wsConnected || !state.coreLinkHealthy ||
      !state.stateSynchronized || state.controlAccess?.can_operate !== true || catalog?.can_upload !== true;
    el("programSourcePrevious").disabled = sourceBusy || first <= 1;
    el("programSourceNext").disabled = sourceBusy || !source || first + source.lines.length > source.total_lines;
  };
  const read = async () => {
    if (!selection || !visible()) return;
    const revision = ++serial, id = selection;
    sourceBusy = true; source = null; permission();
    el("programSourceIdentity").textContent = t("读取中…");
    el("programSourceText").textContent = "";
    try {
      const result = await api.programSource(id, first);
      if (revision !== serial) return;
      if (result?.ok !== true || !Array.isArray(result.data?.lines)) throw new Error(result?.msg || "INVALID_SOURCE_PAGE");
      source = result.data;
      el("programSourceText").textContent = source.lines.map((line,index) => `${source.first + index}  ${line}`).join("\n");
      el("programSourceIdentity").textContent = t("{0}–{1} / {2} 行 · {3}", source.first, source.first + source.lines.length - 1, source.total_lines, source.matches_loaded_session === true ? t("匹配已加载程序") : t("非当前已加载程序"));
      el("programSourceIdentity").title = `SHA256 ${source.file.sha256} · ${source.session_id || ""} / ${source.version || ""}`;
    } catch (error) { if (revision === serial) {
      el("programSourceText").textContent = t("源码不可用：{0}", error.message);
      el("programSourceIdentity").textContent = t("源码身份未确认");
      el("programSourceIdentity").title = "";
    } }
    finally { if (revision === serial) { sourceBusy = false; permission(); } }
  };
  const refresh = async () => {
    if (catalogBusy || uploading || !visible()) return;
    catalogBusy = true;
    try {
      const result = await api.programFiles();
      if (!visible()) return;
      if (result?.ok !== true || !Array.isArray(result.data?.files)) throw new Error(result?.msg || "INVALID_FILE_CATALOG");
      catalog = result.data;
      const options = [new Option(t("选择程序"), "")];
      for (const file of catalog.files) options.push(new Option(`${file.name} · ${file.bytes} bytes`, file.id));
      const select = el("programFileSelection");
      if (select.options.length !== options.length || options.some((option, index) =>
        option.value !== select.options[index].value || option.text !== select.options[index].text))
        select.replaceChildren(...options);
      select.value = selection;
      if (select.selectedIndex === -1) select.value = "";
      if (selection && !catalog.files.some((file) => file.id === selection)) {
        ++serial; selection = ""; source = null; sourceBusy = false;
        el("programSourceText").textContent = t("所选程序已不在文件列表中");
        el("programSourceIdentity").textContent = "";
      }
      say(catalog.configured ? "" : t("程序文件库不可用"));
    } catch (error) { catalog = null; say(t("文件列表不可用：{0}", error.message)); }
    finally { catalogBusy = false; permission(); }
  };
  el("programFileSelection").addEventListener("change", () => {
    ++serial; sourceBusy = false; selection = el("programFileSelection").value; source = null; first = 1;
    el("programSourceText").textContent = ""; el("programSourceIdentity").textContent = "";
    const file = catalog?.files.find((item) => item.id === selection);
    if (file) {
      // Selecting a source only updates an input draft and read-only views.
      el("programPath").value = file.path;
      el("programPath").dispatchEvent(new Event("input", { bubbles: true }));
    }
    permission(); return read();
  });
  el("programSourcePrevious").addEventListener("click", () => { first = Math.max(1,first - 200); return read(); });
  el("programSourceNext").addEventListener("click", () => { if (source) { first += source.lines.length; return read(); } });
  el("programUploadButton").addEventListener("click", async () => {
    const file = el("programUploadFile").files[0];
    if (!file || uploading) return;
    uploading = true; permission(); say(t("上传中…"));
    let feedback;
    try {
      const result = await api.uploadProgram(file);
      if (result?.ok !== true) throw new Error(result?.msg || "UPLOAD_NOT_CONFIRMED");
      feedback = t("已上传 {0}", result.data.name);
    } catch (error) { feedback = t("上传结果未确认：{0}", error.message); }
    finally { uploading = false; permission(); await refresh(); say(feedback); }
  });
  let bindingKey = "", wasVisible = false;
  const update = (state) => {
    const next = JSON.stringify([state.programBinding.session_id,state.programBinding.version,state.programBinding.available,
      state.httpReady,state.coreLinkHealthy]);
    const showing = visible(), changed = next !== bindingKey;
    if (changed || (wasVisible && !showing)) {
      bindingKey = next; ++serial; source = null; sourceBusy = false;
      el("programSourceIdentity").textContent = selection ? t("源码身份未确认") : "";
      el("programSourceIdentity").title = "";
      if (!showing) catalog = null;
    }
    if (showing && (!wasVisible || changed)) { refresh(); read(); }
    wasVisible = showing;
    permission();
  };
  store.subscribe(update);
  setInterval(refresh, 5000);
  update(store.snapshot);
}
