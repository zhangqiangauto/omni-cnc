import { t } from "./i18n.js";
import { axisDescriptors, bindingReady } from "./selectors.js";

const REASON_TEXT = {
  OK: "",
  BAD_RUN_STATE: t("当前运行状态不允许该操作"),
  WRONG_MODE: t("当前模式不允许该操作"),
  DRIVES_DISABLED: t("驱动未使能"),
  PROGRAM_UNAVAILABLE: t("程序未加载或数据不完整"),
  ALARM_ACTIVE: t("当前存在活动告警或故障"),
  BACKEND_SWITCH_PENDING: t("执行后端切换中"),
  MOTION_NOT_READY: t("运动域尚未就绪"),
  PROGRAM_NOT_READY: t("程序域尚未就绪"),
  CAPABILITY_UNAVAILABLE: t("Core 未发布控制能力"),
  STATE_LINK_UNAVAILABLE: t("Core 权威状态链路不可用"),
  COMMAND_CHANNEL_UNAVAILABLE: t("HTTP 命令通道不可用"),
  PROGRAM_BINDING_NOT_READY: t("程序会话未就绪"),
  REQUEST_INFLIGHT: t("上一个请求仍在处理中"),
  HOME_NOT_CONFIRMED: t("Core 尚未确认机床回参考点"),
  WORK_COORDINATE_NOT_READY: t("Core 尚未确认工件坐标"),
  LIFECYCLE_STOP_PREPARED: t("系统正在执行停止流程"),
  SOFT_INHIBIT_ACTIVE: t("Core 已禁止驱动使能")
};

// Decode the published boolean, preserving explicit denial when a legacy
// enabled alias is also present. Malformed primary fields remain unknown.
function permittedValue(published) {
  if (Object.hasOwn(published, "permitted")) return typeof published.permitted === "boolean" ? published.permitted : null;
  return typeof published.enabled === "boolean" ? published.enabled : null;
}

function capability(system, name, authoritative, commandChannel) {
  const published = system.control_capabilities?.[name];
  if (!published) return { enabled: false, visible: true, reason: REASON_TEXT.CAPABILITY_UNAVAILABLE, reasonCode: "CAPABILITY_UNAVAILABLE" };
  const permission = permittedValue(published);
  const reasonCode = permission === null ? "CAPABILITY_UNAVAILABLE" : String(published.reason_code || "OK");
  if (!commandChannel) return { enabled: false, visible: published.visible !== false, reason: REASON_TEXT.COMMAND_CHANNEL_UNAVAILABLE, reasonCode: "COMMAND_CHANNEL_UNAVAILABLE" };
  if (!authoritative) return { enabled: false, visible: published.visible !== false, reason: REASON_TEXT.STATE_LINK_UNAVAILABLE, reasonCode: "STATE_LINK_UNAVAILABLE" };
  const permitted = permission === true;
  return {
    enabled: permitted,
    visible: published.visible !== false,
    reason: permitted ? "" : reasonCode === "OK" ? t("Core 未允许该操作") : (REASON_TEXT[reasonCode] || reasonCode),
    reasonCode
  };
}

export function autoStartDecision(system = {}, binding = {}, startInflight = false) {
  const published = system.control_capabilities?.run_start;
  if (!published) return { allowed: false, reasons: ["CAPABILITY_UNAVAILABLE"] };
  const reasons = [];
  if (!permittedValue(published)) reasons.push(String(published.reason_code || "BAD_RUN_STATE"));
  if (!bindingReady(binding) || binding.run_start_permitted === false) reasons.push("PROGRAM_BINDING_NOT_READY");
  if (startInflight) reasons.push("REQUEST_INFLIGHT");
  return { allowed: reasons.length === 0, reasons };
}

export function publishedOperatorStatus(system = {}) {
  const value = system.operator_status;
  const valid = value?.valid === true &&
    ["running", "held", "estop", "fault_like"].every((key) => typeof value[key] === "boolean");
  return { valid, running: valid && value.running, held: valid && value.held,
    estop: valid && value.estop, faultLike: valid && value.fault_like };
}

export function publishedDriveControl(system = {}) {
  const actions = {
    ENABLE: { enable: true, label: t("伺服使能"), icon: "enable-drives" },
    DISABLE: { enable: false, label: t("伺服下电"), icon: "disable-drives" },
    RESET_AND_ENABLE: { enable: true, label: t("复位并使能"), icon: "enable-drives" }
  };
  const name = system.drives_control_action;
  const action = Object.hasOwn(actions, name) ? actions[name] : null;
  if (!action || system.drives_control_target_enable !== action.enable) {
    return { valid: false, label: t("驱动操作未知"), icon: "enable-drives" };
  }
  return { valid: true, ...action };
}

export function controlPolicy(state) {
  const system = state.topics.get("state.system")?.data || {};
  const runState = String(system.state || "UNKNOWN");
  const mode = String(system.mode || "UNKNOWN");
  const operatorStatus = publishedOperatorStatus(system);
  const commandChannel = state.httpReady;
  const hasCapabilities = Boolean(system.control_capabilities);
  const authoritative = commandChannel && state.wsConnected && state.coreLinkHealthy &&
    state.stateSynchronized === true && hasCapabilities;
  const canOperate = authoritative && state.controlAccess?.can_operate === true;
  const get = (name) => {
    const decision = capability(system, name, authoritative, commandChannel);
    if (decision.enabled && !canOperate) {
      Object.assign(decision, { enabled: false, reason: t("当前终端没有 Core 操作控制权"), reasonCode: "CONTROL_LEASE_REQUIRED" });
    }
    return decision;
  };
  const estop = capability(system, "estop", authoritative, commandChannel);
  const emergencyPermission = operatorStatus.valid && operatorStatus.estop
    ? state.controlAccess?.can_operate : state.controlAccess?.can_assert_estop;
  if (estop.enabled && emergencyPermission !== true) {
    Object.assign(estop, { enabled: false, reason: t("Core 未授权本终端执行此急停操作") });
  }
  const runStart = get("run_start");
  const driveControl = publishedDriveControl(system);
  const drives = get("drives");
  if (drives.enabled && !driveControl.valid) {
    Object.assign(drives, { enabled: false, reason: t("Core 未发布有效的驱动操作"), reasonCode: "CAPABILITY_UNAVAILABLE" });
  }
  if (runStart.enabled && (!bindingReady(state.programBinding) || state.programBinding.run_start_permitted === false)) {
    Object.assign(runStart, { enabled: false, reason: REASON_TEXT.PROGRAM_BINDING_NOT_READY, reasonCode: "PROGRAM_BINDING_NOT_READY" });
  } else if (runStart.enabled && state.runStartInflight) {
    Object.assign(runStart, { enabled: false, reason: REASON_TEXT.REQUEST_INFLIGHT, reasonCode: "REQUEST_INFLIGHT" });
  }
  const holdResume = get(operatorStatus.held ? "resume" : "hold");
  if (holdResume.enabled && !operatorStatus.valid) {
    Object.assign(holdResume, { enabled: false, reason: t("Core 尚未发布有效的暂停/继续状态") });
  }
  const stop = get("stop");
  const validStopAction = (system.auto_control_action === "STOP" && system.auto_control_command === "core.run.stop") ||
    (system.auto_control_action === "RESET" && system.auto_control_command === "core.run.reset");
  if (stop.enabled && (!validStopAction || system.auto_control_action_enabled !== true)) {
    Object.assign(stop, { enabled: false, reason: validStopAction ? t("Core 当前未允许停止/复位") : t("Core 未发布有效的停止/复位操作") });
  }
  const rtcp = get("rtcp");
  if (rtcp.enabled && typeof state.topics.get("diag.planner")?.data?.rtcp?.enabled !== "boolean") {
    Object.assign(rtcp, { enabled: false, reason: t("Core 尚未发布有效的 RTCP 启用状态") });
  }
  const jog = get("jog");
  const axes = axisDescriptors(system);
  if (jog.enabled && (!axes.length || axes.some((axis) => axis.joint === null))) {
    Object.assign(jog, { enabled: false, reason: t("Core 尚未发布有效的轴定义与映射") });
  }

  return {
    system,
    runState,
    operatorStatus,
    driveControl,
    mode,
    commandChannel,
    authoritative,
    estop,
    reset: get("reset"),
    drives,
    runStart,
    runLine: get("run_line"),
    holdResume,
    stop,
    modeSelect: get("mode_select"),
    backend: get("backend"),
    mdi: get("mdi"),
    programMutation: get("program_mutation"),
    jog,
    // These permissions are published in the spindle projection rather than
    // control_capabilities. Apply the same transport validity to both sources.
    spindleStart: {
      enabled: canOperate && system.spindle?.can_start === true,
      reason: !commandChannel ? REASON_TEXT.COMMAND_CHANNEL_UNAVAILABLE
        : !authoritative ? REASON_TEXT.STATE_LINK_UNAVAILABLE : !canOperate ? t("当前终端没有 Core 操作控制权") : t("Core 尚未允许主轴启动")
    },
    spindleStop: {
      enabled: canOperate && system.spindle?.can_stop === true,
      reason: !commandChannel ? REASON_TEXT.COMMAND_CHANNEL_UNAVAILABLE
        : !authoritative ? REASON_TEXT.STATE_LINK_UNAVAILABLE : !canOperate ? t("当前终端没有 Core 操作控制权") : t("Core 尚未允许主轴停止")
    },
    override: get("override"),
    rtConfig: get("rt_config"),
    rtcp
  };
}

export function humanAutoReason(reason) {
  return REASON_TEXT[reason] || reason;
}
