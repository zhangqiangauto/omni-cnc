const STORAGE_KEY = "keniucnc.web.pending-commands.v1";
const MAX_RECORDS = 64;
// Core currently retains completed command results for 30 seconds. Recovery may
// resend only inside a shorter window; older records remain visible but are
// never replayed because their deduplication proof may have expired.
export const SAFE_RECOVERY_WINDOW_MS = 25_000;

function storageOrNull(storage) {
  if (storage) return storage;
  try { return globalThis.localStorage || null; } catch { return null; }
}

export function readPendingCommands(storage = null) {
  const target = storageOrNull(storage);
  if (!target) return [];
  try {
    const parsed = JSON.parse(target.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(parsed) ? parsed.filter((item) =>
      item?.envelope?.id && item?.envelope?.cmd && Number.isFinite(item?.saved_at_ms)) : [];
  } catch {
    return [];
  }
}

function write(records, storage = null) {
  const target = storageOrNull(storage);
  if (!target) return false;
  try {
    target.setItem(STORAGE_KEY, JSON.stringify(records.slice(-MAX_RECORDS)));
    return true;
  } catch {
    return false;
  }
}

export function savePendingCommand(envelope, storage = null, nowMs = Date.now()) {
  const records = readPendingCommands(storage).filter((item) => item.envelope.id !== envelope.id);
  records.push({ envelope, saved_at_ms: nowMs });
  return write(records, storage);
}

export function removePendingCommand(requestId, storage = null) {
  return write(readPendingCommands(storage).filter((item) => item.envelope.id !== requestId), storage);
}

export function recoveryDisposition(record, nowMs = Date.now()) {
  const ageMs = Math.max(0, nowMs - Number(record?.saved_at_ms || 0));
  return ageMs <= SAFE_RECOVERY_WINDOW_MS
    ? { recoverable: true, ageMs, reason: "WITHIN_DEDUP_WINDOW" }
    : { recoverable: false, ageMs, reason: "DEDUP_WINDOW_EXPIRED" };
}

export const commandJournalStorageKey = STORAGE_KEY;
