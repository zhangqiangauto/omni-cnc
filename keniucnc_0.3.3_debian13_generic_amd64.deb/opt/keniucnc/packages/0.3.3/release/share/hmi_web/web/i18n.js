import english from "./locales/en_US.js";

export const supportedLanguages = Object.freeze(["en_US", "zh_CN"]);
// Non-browser consumers use the source language. Browser initialization finishes
// before dependent modules evaluate their presentation labels.
let language = "zh_CN";

export function currentLanguage() { return language; }
export function currentLocale() { return language.replace("_", "-"); }

export function t(message, ...values) {
  const text = language === "en_US" && Object.hasOwn(english, message) ? english[message] : message;
  // Substitute once so braces in user text, paths or service messages stay literal.
  return text.replace(/\{(\d+)\}/g, (token, index) => Number(index) < values.length ? String(values[Number(index)]) : token);
}

export function localizeDocument(root) {
  root.documentElement.lang = language.replace("_", "-");
  const walker = root.createTreeWalker(root.body, 4 /* SHOW_TEXT */);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (["SCRIPT", "STYLE"].includes(node.parentElement?.tagName)) continue;
    const source = node.textContent.trim();
    if (Object.hasOwn(english, source)) node.textContent = node.textContent.replace(source, t(source));
  }
  for (const element of root.querySelectorAll("[title], [aria-label], [placeholder], input[value]")) {
    for (const attribute of ["title", "aria-label", "placeholder", "value"]) {
      const source = element.getAttribute(attribute);
      if (source && Object.hasOwn(english, source)) element.setAttribute(attribute, t(source));
    }
  }
}

if (typeof window !== "undefined" && typeof document !== "undefined") {
  language = "en_US";
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3000);
  try {
    const response = await fetch("/api/ui-language", { cache: "no-store", signal: controller.signal });
    if (response.ok) {
      const config = await response.json();
      if (supportedLanguages.includes(config.language)) language = config.language;
    }
  } catch { /* Keep the English presentation default if configuration is unavailable. */ }
  finally { clearTimeout(timer); }
}
