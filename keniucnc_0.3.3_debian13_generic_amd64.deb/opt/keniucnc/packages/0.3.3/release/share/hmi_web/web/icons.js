import { iconPath } from "./icon-map.js";

const ICONS = {
  "gateway.link": ["connection", "diagnostics"],
  "state.system": ["state-ready", "diagnostics"],
  "state.io": ["connection", "diagnostics"],
  "telemetry.axis": ["axis-override", "axis"],
  "telemetry.tcp_pose": ["tcp", "advanced"],
  "diag.planner": ["planner", "interpolation"],
  "diag.io_profile": ["cpu-load", "diagnostics"],
  "diag.rt_channel": ["realtime", "diagnostics"],
  "diag.perf": ["jitter", "constraints"],
  "event.alarm": ["alarm", "diagnostics"],
  "event.lifecycle": ["info", "diagnostics"]
};

export function topicIcon(topic) {
  const [name, category] = ICONS[topic] || ["info", "diagnostics"];
  return iconPath(name, category);
}

export function setButtonContent(button, label, iconName = button?.dataset.icon, category = button?.dataset.category) {
  if (!button) return;
  button.dataset.icon = iconName || "";
  button.dataset.category = category || "";
  const src = iconPath(iconName, category);
  const existingImage = button.querySelector("img");
  if (button.textContent === label && (src ? existingImage?.getAttribute("src") === src : !existingImage)) return;
  button.replaceChildren();
  if (src) {
    const image = document.createElement("img");
    image.src = src;
    image.alt = "";
    image.loading = "lazy";
    button.appendChild(image);
  }
  const text = document.createElement("span");
  text.textContent = label;
  button.appendChild(text);
  button.classList.toggle("with-icon", Boolean(src));
}

export function initializeButtonIcons(root = document) {
  root.querySelectorAll("button[data-icon]").forEach((button) => {
    setButtonContent(button, button.textContent.trim(), button.dataset.icon, button.dataset.category);
  });
}
