# KeniuCNC Icons v1.0

This package contains 80 SVG icons for KeniuCNC Research Edition.

Available themes:

- `keniu/` — optional blue industrial theme.
- `xiaobai/` — light, friendly theme.
- `omni/` — default OMNI-CNC teal brand artwork on the existing industrial theme; see `omni/manifest.json` for palette and inventory.

## Structure

- `system/`
- `program/`
- `axis/`
- `interpolation/`
- `constraints/`
- `diagnostics/`
- `advanced/`
- `research/`

## Naming

- Kebab-case only (e.g. `cycle-start.svg`, `time-scaling.svg`).
- Semantic naming first.

## Usage

Web:

```html
<img src="icons/system/cycle-start.svg" alt="cycle-start" />
```

Qt:

```cpp
QIcon icon(QStringLiteral("icons/system/cycle-start.svg"));
```

Tip: SVG paths use `currentColor` for line artwork, so icon line color can follow host UI color.

## OMNI-CNC brand layer

The canonical configuration ID and resource directory are `omni`.
Packaged upgrades install the new platform templates while preserving the existing
`active.json` selection and machine identity. For manually managed configuration
roots, update legacy `mega` values in `ui.theme`, `ui.icon_set` and `ui.brand` to
`omni` before using this release. Legacy resource aliases are not installed.
The displayed brand is OMNI-CNC: primary `#00A6B2`, highlight `#43D3D9`,
gradient `#087F8C → #00A6B2 → #43D3D9`. Logo and application icon use an
O-shaped machining orbit. Generic icon brand strokes use the teal palette.
Status, safety actions and constraint icons retain their original semantic colors.
Qt control palettes, Web backgrounds/panels/text and all status tokens stay unchanged;
Web brand text alone uses the brand color. Do not replace gold globally.

### Functional glyphs

OMNI-CNC glyph revision 1.1 keeps the 64 × 64 badge, background, border,
resource names and existing UI bindings. Shapes must communicate the action
at 16–32 px without depending on the small footer text:

- Cycle start, feed hold and stop use a solid play triangle, two pause bars
  and a solid square. E-stop uses a mushroom actuator, distinct from stop.
- Drive enable/disable share a drive module silhouette with a check/slash;
  these are action illustrations, not authoritative readiness indicators.
- Power uses a broken ring and vertical stem; reset uses one bounded return
  arrow. AUTO uses a program with play, MDI a command prompt, JOG four arrows,
  and return-to-reference a target with an incoming arrow.
- Signed jog arrows explicitly label X+/X−, Y+/Y− and Z+/Z−. Spindle CW/CCW
  use mirrored arrow geometry; spindle itself uses a tool-holder silhouette.
- Open uses a folder, save a disk, upload/download opposed transfer arrows,
  restart a document with a return arrow, run-from-line a row pointer, and
  single step a play triangle followed by a vertical bar.
- Kinematics uses an articulated linkage, TCP a tool tip with a crosshair,
  tool orientation a tilted tool, and work offset two displaced origins.
  Feedrate uses a gauge; rapid uses double chevrons; parameters use sliders.

Alarm/status and constraint artwork remains unchanged by the glyph revision.
The glyphs do not define machine-axis conventions or spindle viewing direction;
existing command labels, Core contracts and machine configuration remain authoritative.

### Cross-theme consistency

The same 37 functional glyphs are used by `omni`, `keniu` and `xiaobai` in
revision 1.1. Resource names and command bindings stay stable. Keniu retains
its existing per-function stroke colors, badge gradients and footer labels.
Xiaobai retains its per-function gradients, navy outlines, white solids and
shadows; existing enclosing badges are reused. Former standalone glyphs use
Xiaobai's existing rounded-card convention so the new symbols fit cleanly.
Signed jog labels remain explicit in each theme. Brand logos and application
icons are not shared across themes. Alarm/status and constraint icons retain
their existing theme artwork.

### Qt control sizing

Qt profiles allocate 20–24 px for main navigation and 22–26 px for mode/panel
icons. Ordinary push/tool buttons use the profile mode-icon size by default;
explicit 28–30 px action sizes remain in use. The icon loader renders the
intermediate sizes directly rather than shrinking a neighboring raster size.
Tab minimum content widths avoid unnecessary gaps around short labels; Qt
continues to own icon/text ordering and native spacing. The operation E-stop
action lives in a layout-backed bottom-right tab corner so its fixed width is
reserved before the tab bar lays out or scrolls its tabs.
