# data 配置结构

`active.json` 是唯一运行入口。DEB 首次安装从 `active_default.json` 生成并交付 `active.json`，默认选择 `5axis_generic_x86`、机床编号 `OMNI-001`、`SIM` 模式、英文界面（所选平台 `x86_generic` 的 `ui.language` 为 `en_US`）；升级保留现场已有的 `active.json`。Guardian 发现尚未生成 `active.json` 时只启动系统配置工具，不启动 CNC 运行栈。系统配置工具以 `active_default.json` 创建 `active.json` 后，才可启动 Core。Core 通过 `MachineConfigCatalogRepository` 读取并校验配置图，不再支持旧的 `data/config/*` 集中式目录或旧的平铺 machine profile 写回路径。

加载顺序：

1. `active.json`: 当前 `preset`、现场 `machine_id` 和执行后端 `backend`。
2. `presets/<name>.json`: 组合 `platform` 和 `machine`。
3. `platforms/<platform>.json`: 控制器平台能力、UI/RT 默认值、运行端点、调度参数。界面语言沿用其中的 `ui.language`（`en_US` / `zh_CN`）；配置工具修改此字段，重启 HMI 后生效。详见 [界面多语言契约](../docs/architecture/ui_localization.md)。
4. `machines/<machine>/kinematics.json`: 该机器型号的运动学模型、轴语义、回零策略和名义几何参数。
5. `machines/<machine>/build.json`: 机器硬件构建、伺服、主轴、限位和静态工艺能力。
6. `machines/<machine>/runtime_defaults.json`: 新机或状态缺失时使用的运行默认值；运行中的权威副本位于状态目录。

通用 `x86_generic` 平台要求至少 4 个逻辑 CPU，使用 CPU 0～3，默认分辨率为
1920×1080，界面控制与渲染周期为 33ms。`sched.minimum_cpu_count` 是启动最低要求；
公共调度器在启动工作线程前检查全部启用的进程和线程 CPU 配置。实际 CPU 数不足，
或任一 `cpu_affinity` 编号超出实际 CPU 范围时，输出错误并以非零状态退出，禁止自动改绑。
7. `machines/<machine>/ethercat.xml`: EtherCAT 拓扑和 PDO 映射，当前不使用 JSON Schema。
8. `machines/<machine>/io.json`: 面板、门锁、冷却、排屑、照明、模拟量和手轮 IO。
9. `machines/<machine>/tooling.json`: 刀具和刀库配置种子；寿命、使用记录和作业历史位于状态目录。
10. `machines/<machine>/mcodes.json`: MCode manifest、绑定和执行策略。
11. `machines/<machine>/vision.json`: 相机设备、安装标定、采集 profile、同步阈值和周期策略。
12. `machines/<machine>/sim.json`: 当前机器的 SIM 后端轴模型、IO 初值和故障注入。

相机内参标定图像位于 `machines/<machine>/calib/images/`，产物位于
`machines/<machine>/calib/intrinsics.json`，使用 `camera_intrinsics.schema.json` 校验。

覆盖边界：

- `platforms/` 描述控制器所在计算平台，不放具体机器几何。
- `machines/<name>/kinematics.json` 归属于机器配置包，描述名义运动学、轴语义和回零策略，
  不放 EtherCAT 从站和现场 IO 点位。
- 单台实机的运动学标定存放在状态目录的
  `machines/<machine_id>/calibration.json`，只允许覆盖 `kinematics.parameters` 和
  `kinematics.calibration`。文件不存在时使用机器名义几何；文件存在但契约非法时 Core 拒绝启动。
  通用设置向导不修改该文件；标定流程应按 `machine_calibration.schema.json` 原子生成它。
- `machines/<name>/build.json` 是机器静态事实，修改后通常需要重启 Core。
- `machines/<name>/runtime_defaults.json` 只提供运行默认值。Core 在运行中只更新
  `state/machines/<name>/state.json`：开发模式对应 `.runtime/state/machines/<name>/state.json`，
  deb 模式对应 `/var/lib/keniucnc/machines/<name>/state.json`。
- `machines/<name>/tooling.json` 保存刀具定义和刀库绑定。Core 首次加载时把旧文件中的寿命、
  使用记录和作业历史迁入同层级状态文件，之后动态更新不再写入 `data/`。
- `machines/<name>/io.json` 是现场接线契约；每个启用的物理 pin 只能绑定一个功能。
- `machines/<name>/sim.json` 只描述该机器的仿真行为；轴拓扑和逻辑轴到执行器的绑定仍以 `build.json` 为唯一事实源。
- `presets/` 只组合引用，不复制被引用文件内容。

Schema：

- JSON 文件的契约位于 `data/schema/*.schema.json`。
- `active.json` 使用 `active.schema.json`。
- `presets/*.json` 使用 `preset.schema.json`。
- `platforms/*.json` 使用 `platform.schema.json`。
- `machines/<name>/kinematics.json` 使用 `kinematics.schema.json`。
- 状态目录中的 `machines/<machine_id>/calibration.json` 使用 `machine_calibration.schema.json`。
- `machines/<name>/build.json` 使用 `machine_build.schema.json`。
- `machines/<name>/runtime_defaults.json` 是首次启动的运行默认值，使用
  `machine_runtime_defaults.schema.json`；Core 生成的真实运行状态仍写入状态目录中的 `state.json`。
- `machines/<name>/io.json` 使用 `machine_io.schema.json`。
- `machines/<name>/tooling.json` 使用 `machine_tooling.schema.json`。
- `machines/<name>/mcodes.json` 使用 `machine_mcodes.schema.json`。
- `machines/<name>/vision.json` 使用 `machine_vision.schema.json`。
- `machines/<name>/sim.json` 使用 `machine_sim.schema.json`。

旋转轴几何误差：

- XYZA 转台、AC/BC 摆头、固定 B 摆头和 AC/BC 双转台使用
  `kinematics.parameters.rotary_axes.<a|b|c>.direction/center`。
- `direction` 是 XYZ 单位方向向量，无量纲；`center` 是 XYZ 轴线参考点，单位 mm。
  摆头参考中性滑枕坐标系；双转台参考原有 `table.pivot`，填写相对它的轴中心偏差。
- 现有 XYZA 转台、BC 摆头、固定 B 摆头及两份 AC 转台配置已显式列出名义方向与零偏差。
  这些数值不是实测标定结果。实机辨识值写入状态目录的 `calibration.json`，重启 Core 生效。
- XYZA 使用 `a`，AC 摆头使用 `a/c`，BC 转台使用 `b/c`。各构型由现有 TCP 模式
  选择联动补偿或轴坐标运动；旋转顺序及校验契约见
  [旋转轴线几何](../docs/architecture/rotary_pair_geometry.md)。

Web 页面布局由平台 `ui.web_interface` 指定（`classic` / `modern`），通过初始化配置工具选择，
运行栈重新启动后生效。缺字段按旧版契约使用 `classic`，显式非法值拒绝加载。
该字段独立于 Qt/Web 品牌主题；共用该平台的方案具有相同选择。
