# IO 端口映射

> 机型：通用六轴机器人机型。配置真值以同目录 `io.json` 为准。

## 当前状态

该机型当前没有启用机器 IO：

- `inputs`：空
- `outputs`：空
- `analog_inputs`：空
- `analog_outputs`：空
- `axis_inputs`：空
- `actuator_inputs`：空
- `mpg.enabled`：`false`

因此 DI-01～DI-16、DO-01～DO-16、AI、AO 和手轮编码器目前均未分配业务功能。不得参照其他机型的映射直接接线；启用前应先在本目录 `io.json` 中建立本机型专属配置，并同步更新本文。

`tooling.json` 提供固定工具工位拓扑示例。该机型没有可直接用于铣削 H 表对刀的 Z 直线轴，因此示例使用 `touch_off_policy=DISABLED` 且 `tool_setter.enabled=false`。
