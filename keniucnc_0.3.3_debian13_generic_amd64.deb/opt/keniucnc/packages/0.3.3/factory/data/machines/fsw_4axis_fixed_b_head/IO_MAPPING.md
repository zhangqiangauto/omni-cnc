# 搅拌摩擦焊机 IO 与待标定参数

> 机型：XYZC 四轴固定 B 角摆头。配置真值以同目录 `io.json`、`ethercat.xml`、`build.json` 和 `kinematics.json` 为准。

## 暂定倍福模块

EtherCAT 顺序为四套汇川 SV660N、CTB 主轴驱动、EK1100 耦合器及以下 E-bus 端子：

| 从站 | 模块 | 用途 |
|---|---|---|
| `cabinet-di-a` | EL1008 | 安全链与面板按钮，8 路 DI |
| `cabinet-di-b` | EL1008 | 夹具、冷却、润滑及液压状态，8 路 DI |
| `axis-di-a` | EL1008 | X/Y/Z 回零与硬限位，8 路 DI |
| `axis-di-b` | EL1008 | Z 负限位、C 回零/索引及预留，8 路 DI |
| `cabinet-do-a` | EL2008 | 指示灯、蜂鸣器、驱动接触器、润滑与照明，8 路 DO |
| `cabinet-do-b` | EL2008 | 工装夹紧、工艺冷却及预留，8 路 DO |
| `process-ai` | EL3104 | 轴向力、主轴转矩、工具温度、液压压力，4 路 ±10 V AI |

EK1100 采用 `VID=0x00000002`、`PID=0x044C2C52` 的通用无 PDO 声明；实际采购修订号和现场扫描身份必须在投产前复核。

## 数字输入

| 端口 | 功能 |
|---|---|
| `cabinet-di-a/DI-1` | 急停硬件链状态，仅监视，不能替代安全继电器 |
| `cabinet-di-a/DI-2` | 防护门关闭 |
| `cabinet-di-a/DI-3` | 循环启动 |
| `cabinet-di-a/DI-4` | 进给保持 |
| `cabinet-di-a/DI-5` | 循环停止 |
| `cabinet-di-a/DI-6` | 程序复位 |
| `cabinet-di-a/DI-7` | `drives_disable_switch` 驱动 STOP 按钮；有效时禁止驱动使能 |
| `cabinet-di-a/DI-8` | 对刀/探测输入；标定前不得启用自动对刀 |
| `cabinet-di-b/DI-1` | 工装夹紧到位 |
| `cabinet-di-b/DI-2` | 主轴冷却流量正常 |
| `cabinet-di-b/DI-3` | 润滑液位正常 |
| `cabinet-di-b/DI-4` | 液压压力正常 |
| `axis-di-a/DI-1..3` | X 回零、正限位、负限位 |
| `axis-di-a/DI-4..6` | Y 回零、正限位、负限位 |
| `axis-di-a/DI-7..8` | Z 回零、正限位 |
| `axis-di-b/DI-1` | Z 负限位 |
| `axis-di-b/DI-2..3` | C 回零、索引 |

DI 当前按 NPN/低电平有效配置。传感器类型、常闭/常开逻辑和安全链极性必须结合电气图复核。

`drives_disable_switch` 是驱动 STOP 输入，采用 `DRIVES_ENABLE_INHIBIT` 动作，由 Core 处理按下禁用、松开恢复使能。

## 数字输出

| 端口 | 功能 | 故障/停机状态 |
|---|---|---|
| `cabinet-do-a/DO-1` | 运行灯 | OFF |
| `cabinet-do-a/DO-2` | 报警灯 | 故障时 ON |
| `cabinet-do-a/DO-3` | 保持灯 | OFF |
| `cabinet-do-a/DO-4` | 急停灯 | 故障时 ON |
| `cabinet-do-a/DO-5` | 蜂鸣器 | 故障时 ON |
| `cabinet-do-a/DO-6` | 驱动接触器命令 | OFF |
| `cabinet-do-a/DO-7` | 润滑泵 | OFF |
| `cabinet-do-a/DO-8` | 工作灯 | OFF |
| `cabinet-do-b/DO-1` | 工装夹紧 | OFF |
| `cabinet-do-b/DO-2` | 工艺冷却 | OFF |

DO 当前按 PNP 配置。工装夹紧和冷却的断电安全方向需要在气液压原理图确定后修改。

## 模拟量

EL3104 的四个通道目前只发布 `RAW` 值，没有在 HMI 或 IO 层计算工艺事实：

- AI-1：轴向力原始值。
- AI-2：主轴转矩原始值。
- AI-3：工具温度原始值。
- AI-4：液压压力原始值。

量程、变送器制式和工程单位确定后，应在 Core 配置中更新比例与偏置，再由 HMI 展示 Core 发布的换算结果。

## 投产前必须确认

- 固定 B 机械角度、刀长、TCP 偏置和 C 旋转中心。
- X/Y/Z 丝杆导程、电子齿轮比、方向、零点及软限位；C 减速比和编码器多圈处理。当前 C 按 360° 周期轴及 `MODULO_S32=26214` 暂定，需用驱动器实际一圈计数替换。
- CTB `PID=0x00010004`、PDO、0x6502 支持模式、速度单位及 `command_scale`；当前按 0.01 rpm/count 暂定为 6000 count/(r/s)。
- CTB 插补周期 SDO、看门狗及 `sync0Shift=4500 ns` 是否与实际 ESI 和拓扑一致。
- EL3104 输入接线模式与全部 DI/DO 极性。
- 安全回路、主轴冷却、夹具状态和工艺许可必须由 Core/Guardian 的正式联锁逻辑接管后才能投产。

`drives_disable_switch` 是 STOP 接点：电气类型保持 NPN；Core 将接点的运行许可状态反转为停止有效状态。按下禁用驱动，松开提交恢复使能意图；控制与 IO 指示灯使用同一停止有效状态。
