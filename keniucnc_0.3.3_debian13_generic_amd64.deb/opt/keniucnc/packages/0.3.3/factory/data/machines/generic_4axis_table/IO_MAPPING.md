# IO 端口映射

> 机型：通用四轴转台机型。配置真值以同目录 `io.json` 为准。

## 当前状态

该机型当前没有启用机器 IO：

- `inputs`：空
- `outputs`：空
- `analog_inputs`：空
- `analog_outputs`：空
- `axis_inputs`：空
- `actuator_inputs`：空
- `mpg.enabled`：`false`

因此 DI-01～DI-16、DO-01～DO-16、AI、AO 和手轮编码器目前均未分配业务功能。不得参照其他机型的映射直接接线；启用前应先在本目录 `io.json` 中建立本机型专属配置，并同步更新本文。

`tooling.json` 提供固定排刀位与 Z 轴对刀参数示例，但 `tool_setter.enabled=false`。配置实际 `PROBE_TOUCH` 输入并完成基准坐标标定前，Core 会拒绝自动对刀。
