# IO 端口映射

> 本文说明当前机型的 IO 用途，配置真值以同目录 `io.json` 为准。Core 逻辑只依赖 IO 名称和角色，不依赖物理槽位；`pin` 仅是当前机床的部署映射。

## 数字输入（DI）

| 端口 | 功能 | Core 语义 |
|---|---|---|
| DI-01 | 手轮 X 轴选择 | MPG 轴选 X |
| DI-02 | 手轮 Y 轴选择 | MPG 轴选 Y |
| DI-03 | 手轮 Z 轴选择 | MPG 轴选 Z |
| DI-04 | 手轮 A 轴选择 | MPG 轴选 A |
| DI-05 | 手轮 C 轴选择 | MPG 轴选 C |
| DI-06 | 手轮引导 | AUTO GUIDE 选择输入 |
| DI-07 | 固定式对刀仪探针 | `PROBE_TOUCH`；NPN、低电平有效，示例接线投产前必须复核 |
| DI-08 | 手轮倍率选择位 0 | `scale_index` bit 0 |
| DI-09 | 手轮倍率选择位 1 | `scale_index` bit 1 |
| DI-10 | `drives_disable_switch`（驱动 STOP 按钮） | `DRIVES_ENABLE_SWITCH` / `DRIVES_ENABLE_INHIBIT` |
| DI-11 | 循环停止 | `CYCLE_STOP` / `RUN_STOP_REQUEST` |
| DI-12 | 急停链状态 | `ESTOP_CHAIN` |
| DI-13 | 冷却液开关 | IO ON/OFF 设置冷却液 ON/OFF |
| DI-14 | 循环启动 | `CYCLE_START` / `RUN_START_REQUEST` |
| DI-15 | 暂停/恢复 | `FEED_HOLD`，ON 请求 Hold，OFF 请求 Resume |
| DI-16 | 防护门状态 | `DOOR_GUARD` |

DI 输入当前按 NPN、低电平有效解释。`drives_disable_switch` 按下时 Core 禁用驱动并禁止使能，松开时提交恢复使能意图；驱动故障锁存时不得绕过显式复位流程。`estop_button` 仅用于读取硬件急停安全链状态，不能替代安全继电器或硬接线安全回路。`tool_setter_probe` 由 Servo 直接锁存触发沿及同周期 Z 轴位置，不得再绑定普通业务动作。

`cycle_stop_button` 为点动输入，与 UI `STOP` 共用平滑停止命令；`pause_button` 为保持输入，有效时 Hold、释放时 Resume；`cycle_start_button` 为点动输入，与 UI 运行共用 Cycle Start 角色，Hold 状态下按下则 Resume。
示例 `tooling.json` 保持 `tool_setter.enabled=false`；确认 DI-07 极性并标定 `reference_position_mm` 后才能启用。

## MPG

- 编码器计数：`Encoder-In`
- 倍率索引：`DI-08 + 2 × DI-09`（这里使用经过 NPN 极性转换后的逻辑值）
- 基准倍率：`base_multiplier=1`；倍率表：`0.01 / 0.1 / 1.0 / 1.0`。`count_scale=1` 时，X1 档每个编码器脉冲为 `0.01 mm = 10 um`。
- 手轮使能按钮是 COM 公共端开关，没有独立 IO 端口；按下时轴选和倍率线路才实际导通。
- Core 在轴档由任一可靠活动轴选、在 GUIDE 档由 DI-06 派生 COM 按下状态；只有唯一轴选可作为 JOG 目标，多轴冲突时 AUTO 仍保持零进给。
- AUTO 运行时：COM 松开使用普通程序进给；COM 按住且非 GUIDE 时临时保持零进给；COM 按住且 DI-06 有效时由手轮正向转动速度控制程序进给，手轮静止或反向转动时进给为 0。松开 COM 自动恢复，不进入 Planner 持久 Hold。
- 语义轴由当前机型的逻辑轴名称解析；不存在的 A/C 轴选不会映射到错误的逻辑轴。

## 数字输出（DO）

| 端口 | 功能 | Core 绑定 |
|---|---|---|
| DO-01 | 循环运行灯 | `STATE_RUN` |
| DO-02 | 报警灯 | `ALARM_ACTIVE` |
| DO-03 | 暂停灯 | `STATE_HOLD` |
| DO-04 | 急停灯 | `STATE_ESTOP` |
| DO-05～DO-10 | 未分配 | — |
| DO-11 | 冷却液 | `COOLANT_FLOOD` |
| DO-12 | 未分配 | — |
| DO-13 | 排屑器 | `CHIP_CONVEYOR` |
| DO-14 | 工作灯 | `WORK_LIGHT` |
| DO-15～DO-16 | 未分配 | — |

数字输出当前按 PNP 配置。

## 模拟量

| 端口 | 功能 | 换算 |
|---|---|---|
| AI-01 | 主轴压力传感器 | scale=1，offset=0 |
| AO-01 | 通用模拟输出 1 | scale=1，offset=0 |
| AO-02 | 通用模拟输出 2 | scale=1，offset=0 |

## PWM 输出

| PDO 别名 | 功能 | 换算 |
|---|---|---|
| `@IO-Module/PWM-Freq-1` | PWM 1 频率原始值 | scale=1，offset=0，U32 |
| `@IO-Module/PWM-Freq-2` | PWM 2 频率原始值 | scale=1，offset=0，U32 |
| `@IO-Module/PWM-Prop-1` | PWM 1 占空比原始值 | scale=1，offset=0，U32 |
| `@IO-Module/PWM-Prop-2` | PWM 2 占空比原始值 | scale=1，offset=0，U32 |

`drives_disable_switch` 是 STOP 接点：电气类型保持 NPN；Core 将接点的运行许可状态反转为停止有效状态。按下禁用驱动，松开提交恢复使能意图；控制与 IO 指示灯使用同一停止有效状态。
