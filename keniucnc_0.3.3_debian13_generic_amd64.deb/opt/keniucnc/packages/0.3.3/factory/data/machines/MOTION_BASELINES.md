# 通用五轴与铝型材双 Y 三轴运动基准

2026-10-25：以下参数是样例规划基准，不是经实机辨识的机械性能或加工精度保证。

## 单位与生效边界

- `build.json/process_constraints` 的 `auto_feed`、`mdi_feed`、`rapid_feed` 单位为 mm/min；Core 加载时转换为 mm/s。
- `process_constraints.max_acc/max_jerk` 是进给方向约束，单位为 mm/s²、mm/s³；每个实际轴仍需分别满足 `servo_axis_configs[].limits`。
- 直线轴速度、加速度、jerk 单位为 mm/s、mm/s²、mm/s³；回转轴对应为 °/s、°/s²、°/s³。
- 当前 Core 对非快移取 AUTO 与 MDI 进给上限的较小值，因此这两项设为相同值。
- `contour_error` 是规划平滑容差（mm），不是实测轮廓误差；`transition_orientation_tolerance_deg` 是独立的姿态过渡容差（°）。

## 通用五轴

适用于 `generic_5axis_cradle` 和 `generic_5axis_head`。

| 参数 | 值 |
|---|---:|
| AUTO / MDI 进给上限 | 10000 mm/min |
| 快移进给上限 | 60000 mm/min |
| 进给方向加速度 / jerk | 6000 mm/s² / 50000 mm/s³ |
| XYZ 轴速度 / 加速度 / jerk | 1000 mm/s / 6000 mm/s² / 50000 mm/s³ |
| 刀尖规划平滑容差 | 0.005 mm |
| 姿态过渡容差 | 0.01° |
| A 或 B、C 轴速度 / 加速度 / jerk | 保留 180°/s / 720°/s² / 7200°/s³ |

这对应高档五轴的算法测试量级。没有实机回转轴惯量与驱动能力数据，因此保留原回转轴约束，不能按直线轴比例提高。`sim.json` 的 XYZ 速度和加速度同步调整；仿真模型不提供机械共振、切削变形或实机精度验证。

参考：[HERMLE C32 技术数据](https://www.hermle.de/fileadmin/website/5_NEWS-UND-MEDIA/5_2_Mediathek/Technische_Daten/Englisch/hermle_technical_data_c32_en.pdf)列出 40–60 m/min 快移及 6–10 m/s² 加速度；[HEIDENHAIN 编程手册，第399页](https://content.heidenhain.de/doku/tnc_guide/pdf_files/TNC640/34059x-09/diniso/892909-27.pdf)列出高精度精加工 0.002–0.006 mm 的规划容差。jerk 50 m/s³ 与姿态容差 0.01° 是本样例的工程测试选值，不是上述厂商的统一指标。

## 铝型材双 Y 三轴

适用于 `generic_3axis_dual_y`。依据用户确认的铝合金结构，以及现有机械记录中的 4080U 型材、MGN12 导轨、长 SFU1204 丝杆，采用保守的初始整定值；没有根据材料名称推算固有频率或承载能力。

| 参数 | 值 |
|---|---:|
| AUTO / MDI 进给上限 | 1500 mm/min |
| 快移进给上限 | 3000 mm/min |
| 进给方向加速度 / jerk | 300 mm/s² / 2000 mm/s³ |
| X、Y 轴速度 / 加速度 / jerk | 50 mm/s / 300 mm/s² / 2000 mm/s³ |
| Z 轴速度 / 加速度 / jerk | 20 mm/s / 150 mm/s² / 1000 mm/s³ |
| 规划平滑容差 | 保留 0.02 mm |

XY 最高速度对应 4 mm 导程、1:1 直连丝杆约 750 rpm；这是限速选值，不代表已验证的丝杆临界转速。Z 因垂直负载与现有位置比例仍待实测确认而进一步降速。20 μm 是平滑偏差预算，不宣称本机具有 20 μm 加工精度。仿真轴速度、加速度与这些轴约束一致。

实机后续依据负载下跟随误差、反向振动、双 Y 偏斜和丝杆运行表现逐步整定。现有驱动跟随误差与龙门偏斜阈值不属于规划容差，不应通过本次容差值直接换算或替代。

## 使用范围

本次只更新版本库中的样例。已生成的现场配置、运行时覆盖或已加载配置可能保留旧值；选择/应用样例并重新加载后，应检查 Core 实际发布的生效参数。部署到实际机床前仍需依据机型重新整定，尤其不能直接把通用五轴仿真基准当作现场验收参数。
