#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

usage() {
  cat <<'EOF'
Usage: ./scripts/setup_env.sh [options]

Options:
  --deb-install    Check/install runtime dependencies for a KeniuCNC DEB installation
  --skip-install   Detect and report the platform, but skip system dependency installation
  --skip-runtime   Skip runtime directory preparation
  --with-ethercat  Install IgH EtherCAT packages via scripts/subscript/install_ethercat_igh.sh
  --ethercat-repo-target <name>
                   EtherLab repo profile: debian12 | debian13 | ubuntu2204 | ubuntu2404 | ubuntu2604
                   Auto-detected from /etc/os-release if omitted.
  --ethercat-repo-url <URL>
                   Override EtherLab repo URL
  --ethercat-master-mac <MAC>
                   Configure MASTER0_DEVICE in /etc/ethercat.conf
  -h, --help       Show this help message
EOF
}

SKIP_INSTALL=0
SKIP_RUNTIME=0
DEB_INSTALL=0
WITH_ETHERCAT=0
ETHERCAT_REPO_TARGET=""
ETHERCAT_REPO_URL=""
ETHERCAT_MASTER_MAC=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --deb-install)
      DEB_INSTALL=1
      shift
      ;;
    --skip-install)
      SKIP_INSTALL=1
      shift
      ;;
    --skip-runtime)
      SKIP_RUNTIME=1
      shift
      ;;
    --with-ethercat)
      WITH_ETHERCAT=1
      shift
      ;;
    --ethercat-repo-target)
      if [[ $# -lt 2 ]]; then
        echo "Missing value for --ethercat-repo-target" >&2
        exit 1
      fi
      ETHERCAT_REPO_TARGET="$2"
      shift 2
      ;;
    --ethercat-repo-url)
      if [[ $# -lt 2 ]]; then
        echo "Missing value for --ethercat-repo-url" >&2
        exit 1
      fi
      ETHERCAT_REPO_URL="$2"
      shift 2
      ;;
    --ethercat-master-mac)
      if [[ $# -lt 2 ]]; then
        echo "Missing value for --ethercat-master-mac" >&2
        exit 1
      fi
      ETHERCAT_MASTER_MAC="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ "${DEB_INSTALL}" -eq 1 && "${WITH_ETHERCAT}" -eq 1 ]]; then
  echo "--deb-install never installs IgH EtherCAT dependencies; install them manually." >&2
  exit 2
fi

log() {
  printf '[setup_env] %s\n' "$*"
}

run_as_root() {
  if [[ "${EUID}" -eq 0 ]]; then
    "$@"
  elif command -v sudo >/dev/null 2>&1; then
    sudo "$@"
  else
    log "Need root privileges, but sudo is not available."
    exit 1
  fi
}

detect_platform() {
  local system_name
  system_name="$(uname -s)"

  if [[ "${system_name}" == "Linux" && -f /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    OS_ID="${ID}"
    OS_VERSION_ID="${VERSION_ID}"
    OS_PRETTY="${PRETTY_NAME:-${ID} ${VERSION_ID}}"
  elif [[ "${system_name}" == "Darwin" ]]; then
    OS_ID="macos"
    OS_VERSION_ID="$(sw_vers -productVersion 2>/dev/null || printf 'unknown')"
    OS_PRETTY="macOS ${OS_VERSION_ID}"
  else
    OS_ID="$(printf '%s' "${system_name}" | tr '[:upper:]' '[:lower:]')"
    OS_VERSION_ID="unknown"
    OS_PRETTY="${system_name} (version unknown)"
  fi

  OS_ARCH="$(uname -m)"
  if command -v dpkg >/dev/null 2>&1; then
    DEB_ARCH="$(dpkg --print-architecture)"
  else
    DEB_ARCH="unknown"
  fi
  OS_KERNEL="$(uname -r)"

  log "Operating system: ${OS_PRETTY}"
  log "Hardware architecture: ${OS_ARCH} (Debian architecture: ${DEB_ARCH}) | kernel: ${OS_KERNEL}"

}

require_supported_apt_platform() {
  case "${OS_ID}" in
    debian|ubuntu) ;;
    *)
      log "ERROR: Unsupported operating system '${OS_ID}'. Supported systems: Debian and Ubuntu."
      exit 1
      ;;
  esac

  if ! command -v apt-get >/dev/null 2>&1; then
    log "ERROR: apt-get is required to install dependencies on ${OS_PRETTY}."
    exit 1
  fi
}

resolve_ethercat_target() {
  # Keep user-specified target if already set
  if [[ -n "${ETHERCAT_REPO_TARGET}" ]]; then
    return
  fi

  case "${OS_ID}:${OS_VERSION_ID}" in
    debian:12|debian:12.*) ETHERCAT_REPO_TARGET="debian12" ;;
    debian:13|debian:13.*) ETHERCAT_REPO_TARGET="debian13" ;;
    ubuntu:22.04)          ETHERCAT_REPO_TARGET="ubuntu2204" ;;
    ubuntu:24.04)          ETHERCAT_REPO_TARGET="ubuntu2404" ;;
    ubuntu:26.04)          ETHERCAT_REPO_TARGET="ubuntu2604" ;;
    *)
      log "WARNING: Cannot auto-detect EtherCAT repo target for ${OS_ID} ${OS_VERSION_ID}."
      log "Use --ethercat-repo-target to specify manually: debian12|debian13|ubuntu2204|ubuntu2404|ubuntu2604"
      ;;
  esac

  if [[ -n "${ETHERCAT_REPO_TARGET}" ]]; then
    log "EtherCAT repo target auto-detected: ${ETHERCAT_REPO_TARGET}"
  fi
}

install_with_apt() {
  local build_pkgs=(
    build-essential
    ca-certificates
    cmake
    dpkg-dev
    git
    gpg
    ninja-build
    pkg-config
    wget
  )
  local development_pkgs=(
    nlohmann-json3-dev
    libboost-all-dev
    libeigen3-dev
    libexpat1-dev
    libgrpc++-dev
    libjpeg-dev
    liblog4cplus-dev
    libmosquitto-dev
    libopencv-dev
    libpng-dev
    libssl-dev
    libsqlite3-dev
    libudev-dev
    libzmq3-dev
    qt6-base-dev
    qt6-declarative-dev
    qt6-declarative-dev-tools
    qt6-l10n-tools
  )
  local runtime_tool_pkgs=(
    stress-ng
  )
  local qt_optional_pkgs=()

  log "Refreshing apt package metadata..."
  run_as_root apt-get update

  # Package names for these Qt6 modules differ between supported Debian and
  # Ubuntu releases.  Each module is required by the configured build.
  qt_optional_pkgs+=("$(resolve_apt_package qt6-svg-dev libqt6svg6-dev)")
  qt_optional_pkgs+=("$(resolve_apt_package qt6-websockets-dev libqt6websockets6-dev)")
  qt_optional_pkgs+=("$(resolve_apt_package qt6-shadertools-dev libqt6shadertools6-dev)")

  log "Installing build tools, development libraries, and runtime tools via apt..."
  run_as_root apt-get install -y \
    "${build_pkgs[@]}" \
    "${development_pkgs[@]}" \
    "${qt_optional_pkgs[@]}" \
    "${runtime_tool_pkgs[@]}"
}

resolve_apt_package() {
  local candidate
  for candidate in "$@"; do
    if apt-cache show "${candidate}" >/dev/null 2>&1; then
      printf '%s\n' "${candidate}"
      return
    fi
  done

  log "ERROR: Required package is unavailable. Tried: $*"
  exit 1
}

install_dependencies() {
  require_supported_apt_platform
  install_with_apt
}

is_deb_package_installed() {
  dpkg-query -W -f='${db:Status-Abbrev}' "$1" 2>/dev/null | grep -q '^ii '
}

install_deb_runtime_dependencies() {
  local runtime_pkgs=(
    curl
    libmosquitto1
    libsqlite3-0
    libudev1
    qml6-module-qtqml-models
    qml6-module-qtqml-workerscript
    qml6-module-qtquick
    sqlite3
    util-linux
  )
  local missing_pkgs=()
  local package

  require_supported_apt_platform
  if ! command -v dpkg-query >/dev/null 2>&1; then
    log "ERROR: dpkg-query is required to check DEB runtime dependencies."
    exit 1
  fi

  for package in "${runtime_pkgs[@]}"; do
    if ! is_deb_package_installed "${package}"; then
      missing_pkgs+=("${package}")
    fi
  done

  if [[ "${#missing_pkgs[@]}" -eq 0 ]]; then
    log "All explicit DEB runtime dependencies are installed."
    return
  fi

  log "Installing missing DEB runtime dependencies: ${missing_pkgs[*]}"
  run_as_root apt-get update
  run_as_root env DEBIAN_FRONTEND=noninteractive apt-get install -y "${missing_pkgs[@]}"
}

check_igh_ethercat_dependencies() {
  local igh_pkgs=(
    ethercat-master
    libethercat-dev
  )
  local missing_pkgs=()
  local package

  for package in "${igh_pkgs[@]}"; do
    if ! is_deb_package_installed "${package}"; then
      missing_pkgs+=("${package}")
    fi
  done

  if [[ "${#missing_pkgs[@]}" -eq 0 ]]; then
    log "IgH EtherCAT dependencies detected."
    return
  fi

  # A field controller may use an IgH build installed from source. Such an
  # installation is intentionally absent from dpkg, but exposes the same CLI,
  # development header, and runtime library required by KeniuCNC.
  if command -v ethercat >/dev/null 2>&1 &&
      ethercat version >/dev/null 2>&1 &&
      { [[ -r /usr/include/ecrt.h ]] || [[ -r /usr/local/include/ecrt.h ]] ||
        { command -v pkg-config >/dev/null 2>&1 && pkg-config --exists libethercat; }; } &&
      { ldconfig -p 2>/dev/null | grep -q 'libethercat\.so' ||
        [[ -e /usr/lib/libethercat.so ]] || [[ -e /usr/local/lib/libethercat.so ]]; }; then
    log "IgH EtherCAT source installation detected (not registered in dpkg)."
    return
  fi

  log "WARNING: IgH EtherCAT dependencies are missing: ${missing_pkgs[*]}"
  log "WARNING: They are not installed automatically. Install and configure IgH EtherCAT manually before using the fieldbus."
}

install_ethercat_dependencies() {
  if [[ "${WITH_ETHERCAT}" -eq 0 ]]; then
    log "Skip IgH EtherCAT package installation. Use --with-ethercat to install it."
    return
  fi

  local args=()
  if [[ -n "${ETHERCAT_REPO_TARGET}" ]]; then
    args+=(--repo-target "${ETHERCAT_REPO_TARGET}")
  fi
  if [[ -n "${ETHERCAT_REPO_URL}" ]]; then
    args+=(--repo-url "${ETHERCAT_REPO_URL}")
  fi
  if [[ -n "${ETHERCAT_MASTER_MAC}" ]]; then
    args+=(--master-mac "${ETHERCAT_MASTER_MAC}")
  fi

  log "Installing IgH EtherCAT dependencies with repo target: ${ETHERCAT_REPO_TARGET:-custom URL}"
  "${ROOT_DIR}/scripts/subscript/install_ethercat_igh.sh" "${args[@]}"
}

prepare_runtime_dirs() {
  local dirs=(
    "${ROOT_DIR}/.runtime/state"
    "${ROOT_DIR}/log"
    /tmp/keniucnc/cache
    /tmp/keniucnc/run
  )
  mkdir -p "${dirs[@]}"
}

main() {
  log "Project root: ${ROOT_DIR}"

  detect_platform

  if [[ "${DEB_INSTALL}" -eq 1 ]]; then
    install_deb_runtime_dependencies
    check_igh_ethercat_dependencies
    log "DEB dependency check complete."
    return
  fi

  if [[ "${SKIP_INSTALL}" -eq 0 ]]; then
    resolve_ethercat_target
    install_ethercat_dependencies
    install_dependencies
  else
    log "Skip dependency installation."
  fi

  if [[ "${SKIP_RUNTIME}" -eq 0 ]]; then
    # Source launches use the same hardware identity access contract as DEB.
    run_as_root install -m 0644 "${ROOT_DIR}/packaging/tmpfiles/keniucnc-device-identity.conf" /usr/lib/tmpfiles.d/keniucnc-device-identity.conf
    run_as_root systemd-tmpfiles --create /usr/lib/tmpfiles.d/keniucnc-device-identity.conf
    prepare_runtime_dirs
    log "Prepared development runtime directories."
  else
    log "Skip runtime directory setup."
  fi

  cat <<EOF

Environment setup complete.
Next:
  ./scripts/build.sh
  ./scripts/run.sh all
EOF
}

main "$@"
